<?php

if (!defined('ABSPATH')) exit;

class gdCPTCore {
    function __construct() {
        $this->_actions_wpany();

        if (GDTAXTOOLS_WPV < 31) { $this->_actions_wp30(); }
        if (GDTAXTOOLS_WPV > 30) { $this->_actions_wp31(); }
        if (GDTAXTOOLS_WPV > 31) { $this->_actions_wp32(); }

        if (gdtt_get('bbpress_active') == 1) {
            include(GDTAXTOOLS_PATH.'code/bbpress.php');
        }
    }

    // WordPress ANY //
    private function _actions_wpany() {
        add_filter('single_template', array(&$this, 'post_single_template'));
        add_filter('pre_ozh_yourls_tweet', array(&$this, 'pre_ozh_yourls_tweet'), 10, 4);

        if (gdtt_get('metabox_preload_select') == 1) {
            add_filter('setup_theme', array(&$this, 'preload_select'));
        }

        if (gdtt_get('tpl_expand_single') == 1) {
            add_filter('single_template', array(&$this, 'expand_single_template'));
        }
        if (gdtt_get('tpl_expand_date') == 1) {
            add_filter('date_template', array(&$this, 'expand_date_template'));
        }
        if (gdtt_get('special_cpt_home_page') == 1) {
            add_filter('pre_get_posts', array(&$this, 'expand_home_page'));
        }
        if (gdtt_get('special_cpt_rss_feed') == 1) {
            add_filter('pre_get_posts', array(&$this, 'expand_feed_results'));
        }
        if (gdtt_get('special_cpt_s2_notify') == 1) {
            add_filter('s2_post_types', array(&$this, 'expand_s2_post_types'));
        }
    }

    public function preload_select() {
        require_once(GDTAXTOOLS_PATH.'code/internal/data.php');
    }

    private function _expand_query($query, $cpt_enhanced, $filter_key, $default = 'post') {
        if (empty($cpt_enhanced)) return $query;

        $additional_post_types = isset($query->query_vars['post_type']) ? (array)$query->query_vars['post_type'] : array();
        $push_post = empty($additional_post_types);
        $additional_post_types = array_merge($additional_post_types, $cpt_enhanced);

        if ($push_post) {
            array_push($additional_post_types, $default);
        }

        $additional_post_types = apply_filters('gdcpt_expand_'.$filter_key.'_query_post_types', $additional_post_types);
        $query->set('post_type', $additional_post_types);
        return $query;
    }

    public function expand_home_page($query) {
        if ((is_home()) && (!isset($query->query_vars['suppress_filters']) || false == $query->query_vars['suppress_filters'])) {
            $cpts = gdtt_sf_list('home_page');
            $query = $this->_expand_query($query, $cpts, 'home');
        }
        return $query;
    }

    public function expand_feed_results($query) {
        if ($query->is_feed && !isset($query->query['post_type'])) {
            $cpts = gdtt_sf_list('rss_feed');
            $query = $this->_expand_query($query, $cpts, 'feed');
        }
        return $query;
    }

    public function expand_single_template($template) {
        global $wp_query;
        $object = $wp_query->get_queried_object();

        $templates = array(
            'single-'.$object->post_type.'-'.$object->ID.'.php',
            'single-'.$object->post_type.'-'.$object->post_name.'.php',
            'single-'.$object->post_type.'.php',
            'single-'.$object->ID.'.php',
            'single-'.$object->post_name.'.php',
            'single.php',
            'index.php');

        return locate_template($templates);
    }

    public function expand_date_template($template) {
        global $wp_query, $wp_rewrite;
        $rewrite_active = $wp_rewrite->using_permalinks();
        $post_type = $year = isset($wp_query->query['post_type']) ? $wp_query->query['post_type'] : '';
        $prefix = $post_type != '' ? 'archive-'.$post_type : '';

        $templates = array();
        if (is_year()) {
            $year = isset($wp_query->query['year']) ? $wp_query->query['year'] : substr($wp_query->query['m'], 0, 4);
            if ($post_type != '' && gdtt_get('tpl_expand_date_cpt') == 1) {
                $templates = array(
                    $prefix.'-year-'.$year.'.php',
                    $prefix.'-'.$year.'.php',
                    $prefix.'-year.php');
            }
            $templates = array_merge($templates, array(
                'date-year-'.$year.'.php',
                'date-'.$year.'.php',
                'date-year.php'));
        }

        if (is_month()) {
            if ($rewrite_active) {
                $month = $wp_query->query['monthnum'];
                $year = $wp_query->query['year'];
            } else {
                $month = substr($wp_query->query['m'], 4, 2);
                $year = substr($wp_query->query['m'], 0, 4);
            }
            if ($post_type != '' && gdtt_get('tpl_expand_date_cpt') == 1) {
                $templates = array(
                    $prefix.'-month-'.$month.'.php',
                    $prefix.'-month-'.$year.'-'.$month.'.php',
                    $prefix.'-'.$month.'.php',
                    $prefix.'-'.$year.'-'.$month.'.php',
                    $prefix.'-month.php');
            }
            $templates = array_merge($templates, array(
                'date-month-'.$month.'.php',
                'date-month-'.$year.'-'.$month.'.php',
                'date-'.$month.'.php',
                'date-'.$year.'-'.$month.'.php',
                'date-month.php'));
        }

        if (is_day()) {
            if ($rewrite_active) {
                $day = $wp_query->query['day'];
                $month = $wp_query->query['monthnum'];
                $year = $wp_query->query['year'];
            } else {
                $day = substr($wp_query->query['m'], 6, 2);
                $month = substr($wp_query->query['m'], 4, 2);
                $year = substr($wp_query->query['m'], 0, 4);
            }
            if ($post_type != '' && gdtt_get('tpl_expand_date_cpt') == 1) {
                $templates = array(
                    $prefix.'-day-'.$year.'-'.$month.'-'.$day.'.php',
                    $prefix.'-day-'.$day.'.php',
                    $prefix.'-'.$year.'-'.$month.'-'.$day.'.php',
                    $prefix.'-day.php');
            }
            $templates = array_merge($templates, array(
                'date-day-'.$year.'-'.$month.'-'.$day.'.php',
                'date-day-'.$day.'.php',
                'date-'.$year.'-'.$month.'-'.$day.'.php',
                'date-day.php'));
        }

        if ($post_type != '' && gdtt_get('tpl_expand_date_cpt_priority') == 1) {
            $templates[] = $prefix.'.php';
        }

        array_push($templates, 'date.php', 'archive.php', 'index.php');

        return locate_template($templates);
    }

    public function expand_s2_post_types($post_types) {
        $cpts = gdtt_sf_list('s2_notify');
        if (!empty($cpts)) {
            if (is_array($post_types) && !empty($post_types)) {
                $post_types = array_merge($post_types, $cpts);
            } else {
                $post_types = $cpts;
            }
        }
        return $post_types;
    }

    public function pre_ozh_yourls_tweet($tweet, $url, $title, $id) {
        global $gdtt;
        $post_type = get_post_type((int)$id);
        if (isset($gdtt->sf['yourls'][$post_type]) && $gdtt->sf['yourls'][$post_type] != '') {
            $tweet = $gdtt->sf['yourls'][$post_type];
        }
        return $tweet;
    }

    public function post_single_template($template) {
        global $post;
        $cpt = $post->post_type;
        if (gdtt_sf($cpt, 'post_template')) {
            $tpl = get_post_meta($post->ID, '_wp_post_template', true);
            if (!empty($tpl) && file_exists(TEMPLATEPATH.'/'.$tpl)) {
                $template = TEMPLATEPATH.'/'.$tpl;
            }
        }
        return $template;
    }

    // WordPress 3.0 //
    private function _actions_wp30() {
        if (gdtt_get('cpt_advanced_rewrite') == 1) {
            add_action('template_redirect', array(&$this, 'wp30_template_redirect'));
            add_action('generate_rewrite_rules', array(&$this, 'wp30_rewrite_rules'));
            add_action('parse_query', array(&$this, 'wp30_parse_query'), 100);
            add_action('wp_head', array(&$this, 'wp30_feed_links'), 2);
        }

        if (gdtt_get('tpl_expand_archive') == 1) {
            add_filter('archive_template', array(&$this, 'wp30_archive_template'));
        }
    }

    public function wp30_template_redirect() {
        if (gdtt_is_archive_custom_post_type()) {
            $post_type = gdtt_is_valid_rewrite_post_type(get_query_var('post_type'));

            $templates = array('type-'.$post_type->name.'.php');
            if (isset($post_type->rewrite['slug'])) {
                $templates[] = 'type-'.$post_type->rewrite['slug'].'.php';
            }
            array_push($templates, 'type.php', 'arhive.php', 'index.php');
            locate_template($templates, true);
            die();
        }
    }

    public function wp30_rewrite_rules($wp_rewrite) {
        $post_types = gdtt_valid_rewrite_post_types();

        foreach ($post_types as $type => $post_type) {
            $slug = $post_type->rewrite['slug'];

            $rules = array(
                $slug.'/?$' => 'index.php?post_type='.$type,
                $slug.'/page/?([0-9]{1,})/?$' => 'index.php?post_type='.$type.'&paged='.$wp_rewrite->preg_index(1),
                $slug.'/feed/(feed|rdf|rss|rss2|atom)/?$' => 'index.php?post_type='.$type.'&feed='.$wp_rewrite->preg_index(1),
                $slug.'/(feed|rdf|rss|rss2|atom)/?$' => 'index.php?post_type='.$type.'&feed='.$wp_rewrite->preg_index(1)
            );

            $wp_rewrite->rules = array_merge($rules, $wp_rewrite->rules);
        }
    }

    public function wp30_parse_query($wp_query) {
        if (!isset($wp_query->query_vars['post_type'])) return;
        $post_type = $wp_query->query_vars['post_type'];

        if (get_query_var('name') || is_robots() || is_feed() || 
            is_tax() || is_category() || is_tag() || is_trackback() ||
            !gdtt_is_valid_rewrite_post_type($post_type)) return;

        add_filter('body_class', array(&$this, 'wp30_post_type_body_classes'));
        $wp_query->is_home = false;
        $wp_query->is_archive_custom_post_type = true;
    }

    public function wp30_post_type_body_classes($classes) {
        $classes[] = 'custom-post-type-archive';
        $classes[] = 'custom-post-type-'.get_query_var('post_type').'-archive';
        return $classes;
    }

    public function wp30_feed_links() {
        if (!current_theme_supports('automatic-feed-links')) return;
        $post_type = gdtt_is_valid_rewrite_post_type(get_query_var('post_type'));
        if (!$post_type) return;
        echo '<link rel="alternate" type="'.feed_content_type().'" title="'.esc_attr(get_bloginfo('name').' &raquo; '.$post_type->label.' Feed').'" href="'.gdtt_cpt_feed_link($post_type)."\" />\n";
    }

    public function wp30_archive_template($templates) {
        $post_type = get_query_var('post_type');

        if ($post_type != '') {
            $post_type = gdtt_is_valid_rewrite_post_type(get_query_var('post_type'));

            if ($post_type) {
                $tpls = array('type-'.$post_type->name.'.php');
                if (isset($post_type->rewrite['slug'])) {
                    $tpls[] = 'type-'.$post_type->rewrite['slug'].'.php';
                }
                $tpls[] = 'type.php';
                $templates = array_merge($tpls, (array)$templates);
            }
        }

        return locate_template($templates);
    }

    // WordPress 3.1 //
    private function _actions_wp31() {
        if (gdtt_get('tpl_expand_archives') == 1) {
            add_filter('archive_template', array(&$this, 'expand_archives_template'));
        }
    }

    public function expand_archives_template($templates) {
        $post_type = get_query_var('post_type');

        if ($post_type) {
            $tpls = array('type-'.$post_type.'.php', 
                          'archive-'.$post_type.'.php',
                          'type.php',
                          'archive.php');
            $templates = array_merge($tpls, (array)$templates);
        }

        return locate_template($templates);
    }

    // WordPress 3.2 //
    private function _actions_wp32() {
        if (gdtt_get('special_cpt_gd_star_rating') == 1) {
            add_action('gdsr_register_ratings', array(&$this, 'expand_rating_types'));
        }
    }

    public function expand_rating_types() {
        $cpts = gdtt_sf_list('gd_star_rating');

        foreach ($cpts as $cpt) {
            $post_type = get_post_type_object($cpt);
            gdsr_register_rating_object($cpt, array(
                'method' => 'inherit',
                'inherit' => 'post',
                'override' => array('name' => 'cpt_'.$cpt, 'post_type' => $cpt),
                'extend' => array('title' => __("Post Type", "gd-taxonomies-tools").': '.$post_type->labels->singular_name)
            ));
        }
    }
}

?>