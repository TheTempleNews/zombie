<?php

if (!defined('ABSPATH')) exit;

class gdCPTAdmin_AJAX {
    function __construct() {
        add_action("wp_ajax_gdtt_meta_search_tags", array(&$this, "meta_search_tags"));

        add_action("wp_ajax_gd_cpt_tinymce_check", array(&$this, "ajax_check_term"));
        add_action("wp_ajax_gd_cpt_tinymce_search", array(&$this, "ajax_search_term"));

        add_action("wp_ajax_gd_cpt_dettach_image", array(&$this, "ajax_detach_term_image"));
        add_action("wp_ajax_gd_cpt_attach_image", array(&$this, "ajax_attach_term_image"));

        add_action("wp_ajax_gd_cpt_save_caps", array(&$this, "ajax_save_caps"));

        add_action("wp_ajax_gd_cpt_meta_add_field", array(&$this, "ajax_add_custom_field"));
        add_action("wp_ajax_gd_cpt_meta_delete_field", array(&$this, "ajax_delete_custom_field"));
        add_action("wp_ajax_gd_cpt_meta_add_metabox", array(&$this, "ajax_add_metabox"));
        add_action("wp_ajax_gd_cpt_meta_delete_metabox", array(&$this, "ajax_delete_metabox"));
        add_action("wp_ajax_gd_cpt_meta_attach_metabox", array(&$this, "ajax_attach_metabox"));

        add_action("wp_ajax_gd_cpt_save_settings", array(&$this, "ajax_save_settings"));
    }

    function is_term_valid($term, $check_empty = false) {
        if (trim($term) == "" && $check_empty) return false;
        return strtolower($term) == sanitize_title_with_dashes($term);
    }

    function save_yourls_options($type, $link = false, $auto = false) {
        $wp_ozh_yourls = get_option("ozh_yourls");
        $wp_ozh_yourls["generate_on_".$type] = $link ? 1 : 0;
        $wp_ozh_yourls["tweet_on_".$type] = $auto ? 1 : 0;

        update_option("ozh_yourls", $wp_ozh_yourls);
    }

    function find_custompost_pos($id) {
        global $gdtt;
        $found = -1;
        for ($i = 0; $i < count($gdtt->p); $i++) {
            if (intval($gdtt->p[$i]["id"]) == $id) {
                $found = $i;
                break;
            }
        }

        return $found;
    }

    function find_taxonomy_pos($id) {
        global $gdtt; 
        $found = -1;
        for ($i = 0; $i < count($gdtt->t); $i++) {
            if (intval($gdtt->t[$i]["id"]) == $id) {
                $found = $i;
                break;
            }
        }

        return $found;
    }

    function add_cpt_caps($name) {
        if ($name == "post") return;

        $caps = get_option("gd-taxonomy-tools-caps");
        if (!is_array($caps)) {
            $caps = array("cpt" => array(), "tax" => array());
        }

        if (!isset($caps["cpt"][$name])) {
            $caps["cpt"][$name] = new gdtt_Caps($name);
        }

        update_option("gd-taxonomy-tools-caps", $caps);
    }

    function add_tax_caps($name) {
        if ($name == "categories") return;

        $caps = get_option("gd-taxonomy-tools-caps");
        if (!is_array($caps)) {
            $caps = array("cpt" => array(), "tax" => array());
        }

        if (!isset($caps["tax"][$name])) {
            $caps["tax"][$name] = new gdtt_Caps($name, "tax");
        }

        update_option("gd-taxonomy-tools-caps", $caps);
    }

    function meta_search_tags() {
        global $gdtt;

        check_ajax_referer("gdcptools");
        $tags = array("tags" => array());

        $api = stripslashes($_POST["api"]);
        $content = stripslashes($_POST["content"]);
        $title = stripslashes($_POST["title"]);

        require_once(GDTAXTOOLS_PATH."gdr2/gdr2.seo.php");
        $gdr2_seo_core = new gdr2_SEO();

        switch ($api) {
            default:
            case "internal":
                $list = (array)$gdr2_seo_core->get_tags_from_internal($title, $content);
                if (count($list) > $gdtt->o["tagger_internal_limit"]) {
                    $list = array_slice($list, 0, $gdtt->o["tagger_internal_limit"]);
                }
                $tags["tags"] = $list;
                break;
            case "yahoo":
                $tags["tags"] = (array)$gdr2_seo_core->get_tags_from_yahoo($title, $content, 60, $gdtt->o["tagger_yahoo_api_id"]);
                break;
            case "alchemy":
                $tags["tags"] = (array)$gdr2_seo_core->get_tags_from_alchemy($title, $content, 60, $gdtt->o["tagger_alchemy_api_key"]);
                break;
            case "opencalais":
                $tags["tags"] = (array)$gdr2_seo_core->get_tags_from_opencalais($title, $content, 60, $gdtt->o["tagger_opencalais_api_key"]);
                break;
            case "zemanta":
                $tags["tags"] = (array)$gdr2_seo_core->get_tags_from_zemanta($title, $content, 60, $gdtt->o["tagger_zemanta_api_key"]);
                break;
            case "tagthe":
                $tags["tags"] = (array)$gdr2_seo_core->get_tags_from_tagthe($title, $content, 60);
                break;
        }

        $response = json_encode($tags);
        die($response);
    }

    function ajax_search_term() {
        global $wp_taxonomies, $gdtt;

        $post = $_REQUEST;
        $terms = get_terms($post["tax"], array("hide_empty" => false, "search" => $post["term"], "number" => $gdtt->o["tinymce_search_limit"]));

        if (count($terms) == 0) {
            die("{ \"status\": \"ok\", \"result\": \"notfound\" }");
        } else {
            $result = sprintf("{ \"status\": \"ok\", \"result\": \"found\", \"taxonomy\": \"%s\"", $post["tax"]);
            $tx = array();
            foreach ($terms as $term) {
                $tx[] = sprintf("{ \"permalink\": \"%s\", \"termname\": \"%s\", \"termslug\": \"%s\" }",
                    get_term_link($term, $post["tax"]), $term->name, $term->slug);
            }
            $result.= ", \"terms\": [".join(", ", $tx)."] }";
            die($result);
        }
    }

    function ajax_check_term() {
        global $wp_taxonomies;

        $post = $_REQUEST;
        $create = isset($post["autocreate"]) ? $post["autocreate"] : $post["create"];
        $term = get_term_by("name", $post["term"], $post["tax"]);

        if (!$term) {
            if ($create == 1) {
                $term = wp_insert_term($post["term"], $post["tax"]);
                $term = get_term($term["term_id"], $post["tax"]);
            } else {
                die("{ \"status\": \"ok\", \"result\": \"notfound\" }");
            }
        }

        die(sprintf("{ \"status\": \"ok\", \"result\": \"ok\", \"taxonomy\": \"%s\", \"permalink\": \"%s\", \"termname\": \"%s\", \"termslug\": \"%s\" }",
            $post["tax"], get_term_link($term, $post["tax"]), $term->name, $term->slug));
    }

    function ajax_detach_term_image() {
        check_ajax_referer("gd-cpt-tools");

        $taxonomy = $_POST["taxonomy"];
        $term_id = $_POST["term_id"];

        gdtt_term_dettach_image($taxonomy, $term_id);

        die("{\"status\": \"ok\"}");
    }

    function ajax_attach_term_image() {
        check_ajax_referer("gd-cpt-tools");

        $taxonomy = $_POST["taxonomy"];
        $term_id = $_POST["term_id"];
        $image_id = $_POST["image_id"];

        gdtt_term_attach_image($taxonomy, $term_id, $image_id);
        $image = gdtt_get_term_image($taxonomy, $term_id, array(64, 64));
        $image_url = gdtt_get_term_image($taxonomy, $term_id, "large", "url");
        $image = str_replace("\"", "'", $image);

        die("{\"status\": \"ok\", \"image\": \"".$image."\", \"preview\": \"".$image_url."\"}");
    }

    function ajax_save_caps() {
        check_ajax_referer("gd-cpt-tools");

        $default = array(
            "cpt" => array("edit_post", "edit_posts", "edit_private_posts", "edit_published_posts", "edit_others_posts", "publish_posts", "read_post", "read_private_posts", "delete_post", "delete_posts", "delete_published_posts", "delete_private_posts", "delete_others_posts"),
            "tax" => array("manage_terms", "edit_terms", "delete_terms", "assign_terms")
        );

        $mode = $_POST["mode"];
        $data = $_POST[$mode];

        $caps = get_option("gd-taxonomy-tools-caps");
        $caps[$mode][$data["info"]["name"]]->caps[$data["info"]["role"]] = array_keys($data["caps"]);
        $caps[$mode][$data["info"]["name"]]->active[$data["info"]["role"]] = isset($data["info"]["active"]);
        update_option("gd-taxonomy-tools-caps", $caps);

        $caps_it = $caps[$mode][$data["info"]["name"]]->get_caps($data["info"]["role"], $default[$mode]);
        $caps_al = $caps[$mode][$data["info"]["name"]]->make_caps($default[$mode]);

        $role_it = get_role($data["info"]["role"]);

        foreach ($caps_al as $cap) $role_it->remove_cap($cap);
        if ($caps[$mode][$data["info"]["name"]]->is_active($data["info"]["role"])) {
            foreach ($caps_it as $cap) $role_it->add_cap($cap);
        }

        die(json_encode($caps));
    }

    function ajax_delete_custom_field() {
        global $gdtt;

        check_ajax_referer("gd-cpt-tools");
        $result = array("status" => "ok", "delete" => "no");
        $code = $_POST["code"];

        if ($_POST["data"] == "1") {
            gdtt_Meta::delete_custom_field_data($code);
        }
        if ($_POST["definition"] == "1") {
            if (isset($gdtt->m["fields"][$code])) {
                unset($gdtt->m["fields"][$code]);
                update_option("gd-taxonomy-tools-meta", $gdtt->m);
                $result["del_row"] = "yes";
            }
        }

        die(json_encode(new gdrClass($result)));
    }

    function ajax_delete_metabox() {
        global $gdtt;

        check_ajax_referer("gd-cpt-tools");
        $result = array("status" => "ok", "delete" => "no");
        $code = $_POST["code"];

        if ($_POST["definition"] == "1") {
            if (isset($gdtt->m["boxes"][$code])) {
                unset($gdtt->m["boxes"][$code]);
                if (isset($gdtt->m["map"][$code])) {
                    unset($gdtt->m["map"][$code]);
                }
                update_option("gd-taxonomy-tools-meta", $gdtt->m);
                $result["del_row"] = "yes";
            }
        }

        die(json_encode(new gdrClass($result)));
    }

    function ajax_attach_metabox() {
        global $gdtt;

        check_ajax_referer("gd-cpt-tools");
        $result = array("status" => "ok");

        $code = $_POST["code"];
        $post_types = array_unique((array)$_POST["post_types"]);
        $gdtt->m["map"][$code] = $post_types;
        update_option("gd-taxonomy-tools-meta", $gdtt->m);

        $result["map"] = $post_types;
        die(json_encode(new gdrClass($result)));
    }

    function ajax_add_metabox() {
        global $gdtt;

        check_ajax_referer("gd-cpt-tools");
        $result = array("status" => "ok");

        $box = gdr2_array_map("stripslashes", $_POST);
        $box = gdr2_array_map("strip_tags", $box);
        $box = gdr2_array_map("trim", $box);
        $box["code"] = gdr2_sanitize_full($box["code"]);
        $box["fields"] = (array)$_POST["fields"];

        if ($gdtt->o["metabox_unique_fields"] == 1) {
            $box["fields"] = array_unique($box["fields"]);
        }

        if ($box["method"] == "edit") {
            $gdtt->m["boxes"][$box["code"]] = new gdttMetaBox($box);
            update_option("gd-taxonomy-tools-meta", $gdtt->m);
        } else {
            if ($box["code"] != "__none__" && !in_array($box["code"], array_keys($gdtt->m["boxes"]))) {
                $gdtt->m["boxes"][$box["code"]] = new gdttMetaBox($box);
                $gdtt->m["map"][$box["code"]] = array();
                update_option("gd-taxonomy-tools-meta", $gdtt->m);
            } else {
                $result["status"] = "error";
                $result["error"] = __("Meta box with this code already exists.", "gd-taxonomies-tools");
            }
        }

        $result["box"] = $gdtt->m["boxes"][$box["code"]];
        $result["map"] = $gdtt->m["map"][$box["code"]];
        die(json_encode(new gdrClass($result)));
    }

    function ajax_add_custom_field() {
        global $gdtt;

        check_ajax_referer("gd-cpt-tools");
        $result = array("status" => "ok");

        $field = gdr2_array_map("stripslashes", $_POST);
        $field = gdr2_array_map("strip_tags", $field);
        $field = gdr2_array_map("trim", $field);
        $field["code"] = gdr2_sanitize_full($field["code"]);

        if ($field["method"] == "edit") {
            $gdtt->m["fields"][$field["code"]] = new gdttCustomField($field);
            update_option("gd-taxonomy-tools-meta", $gdtt->m);
            $gdtt->m["fields"][$field["code"]]->counter = gdtt_Meta::count_custom_field_posts($field["code"]);
        } else {
            if ($field["code"] != "__none__" && !in_array($field["code"], array_keys($gdtt->m["fields"]))) {
                $gdtt->m["fields"][$field["code"]] = new gdttCustomField($field);
                update_option("gd-taxonomy-tools-meta", $gdtt->m);
                $gdtt->m["fields"][$field["code"]]->counter = 0;
            } else {
                $result["status"] = "error";
                $result["error"] = __("Field with this code already exists.", "gd-taxonomies-tools");
            }
        }

        $result["field"] = $gdtt->m["fields"][$field["code"]];
        die(json_encode(new gdrClass($result)));
    }

    function save_settings_cpt_simple($cpt) {
        global $gdtt;

        $cpt["supports"] = isset($cpt["supports"]) ? array_keys($cpt["supports"]) : array();
	$cpt["taxonomies"] = isset($cpt["taxonomies"]) ? array_keys($cpt["taxonomies"]) : array();
	$cpt["special"] = isset($cpt["enhanced"]) ? array_keys($cpt["enhanced"]) : array();

        if (isset($cpt["enhanced"])) {
            unset($cpt["enhanced"]);
        }

        $post_type = get_post_type_object($cpt["name"]);

        if (isset($gdtt->nn_p["full"][$cpt["name"]])) {
            $cpt_full = $gdtt->nn_p["full"][$cpt["name"]];
        } else {
            $cpt_full = gdtt_get_override_post_type($cpt["name"], $post_type);
        }

        $cpt_full["active"] = $cpt["active"];
        $cpt_full["supports"] = $cpt["supports"];
	$cpt_full["taxonomies"] = $cpt["taxonomies"];
	$cpt_full["special"] = $cpt["special"];

        $gdtt->nn_p["full"][$cpt["name"]] = $cpt_full;
	$gdtt->nn_p["status"][$cpt["name"]] = $cpt["active"];
	$gdtt->nn_p["simple"][$cpt["name"]] = $cpt;

	update_option("gd-taxonomy-tools-nn-cpt", $gdtt->nn_p);

        $gdtt->unset_cache("cpt", $cpt["name"]);
        return new gdrClass(array("status" => "ok"));
    }

    function save_settings_tax_simple($tax) {
        global $gdtt;

	$post_types = isset($tax["post_types"]) ? array_keys($tax["post_types"]) : array();
        $tax["domain"] = join(",", $post_types);
        $tax["metabox"] = trim(strip_tags($tax["metabox"]));
        $tax["supports"] = isset($tax["supports"]) ? array_keys($tax["supports"]) : array();
	$tax["special"] = isset($tax["enhanced"]) ? array_keys($tax["enhanced"]) : array();

        if (isset($tax["enhanced"])) {
            unset($tax["enhanced"]);
        }

        $tax_type = get_taxonomy($tax["name"]);
        if (isset($gdtt->nn_t["full"][$tax["name"]])) {
            $tax_full = $gdtt->nn_t["full"][$tax["name"]];
        } else {
            $tax_full = gdtt_get_override_taxonomy($tax["name"], $tax_type);
        }

        $tax_full["active"] = $tax["active"];
        $tax_full["supports"] = $tax["supports"];
        $tax_full["metabox"] = $tax["metabox"];
        $tax_full["domain"] = $tax["domain"];
        $tax_full["special"] = $tax["special"];

        $gdtt->nn_t["full"][$tax["name"]] = $tax_full;
        $gdtt->nn_t["status"][$tax["name"]] = $tax["active"];
        $gdtt->nn_t["simple"][$tax["name"]] = $tax;

        update_option("gd-taxonomy-tools-nn-tax", $gdtt->nn_t);

        $gdtt->unset_cache("tax", $tax["name"]);
        return new gdrClass(array("status" => "ok"));
    }

    function save_settings_cpt_full($cpt, $editable = true) {
        global $gdtt;

        $errors = $blocks = array();
        $result = array('status' => 'ok');

        $cpt['id'] = intval($cpt['id']);
        if ($cpt['id'] > -1) {
            $cpt['active'] = isset($cpt['active']) ? 1 : 0;
        }

        $cpt['hierarchy'] = isset($cpt['hierarchy']) ? 'yes' : 'no';
        $cpt['publicly_queryable'] = isset($cpt['publicly_queryable']) ? 'yes' : 'no';
        $cpt['rewrite_feeds'] = isset($cpt['rewrite_feeds']) ? 'yes' : 'no';
        $cpt['rewrite_pages'] = isset($cpt['rewrite_pages']) ? 'yes' : 'no';
        $cpt['rewrite_front'] = isset($cpt['rewrite_front']) ? 'yes' : 'no';
        $cpt['public'] = isset($cpt['public']) ? 'yes' : 'no';
        $cpt['ui'] = isset($cpt['ui']) ? 'yes' : 'no';
        $cpt['exclude_from_search'] = isset($cpt['exclude_from_search']) ? 'yes' : 'no';
        $cpt['nav_menus'] = isset($cpt['nav_menus']) ? 'yes' : 'no';
        $cpt['show_in_menu'] = isset($cpt['show_in_menu']) ? 'yes' : 'no';
        $cpt['can_export'] = isset($cpt['can_export']) ? 'yes' : 'no';

        $cpt['yourls_active'] = isset($cpt['yourls_active']) ? 'yes' : 'no';
        $cpt['yourls_active_link'] = isset($cpt['yourls_active_link']) ? 'yes' : 'no';
        $cpt['yourls_active_auto'] = isset($cpt['yourls_active_auto']) ? 'yes' : 'no';
        $cpt['yourls_active_tweet'] = trim(strip_tags($cpt['yourls_active_tweet']));

        $cpt['archive_slug'] = trim(strip_tags($cpt['archive_slug']));
        $cpt['rewrite_slug'] = trim(strip_tags($cpt['rewrite_slug']));
        $cpt['query_slug'] = trim(strip_tags($cpt['query_slug']));
        $cpt['description'] = trim(strip_tags($cpt['description']));
        $cpt['caps_type'] = trim(strip_tags($cpt['caps_type']));
        $cpt['edit_link'] = trim(strip_tags($cpt['edit_link']));

        if ($cpt['edit_link'] == '') {
            $cpt['edit_link'] = 'post.php?post=%d';
        }

        if (!isset($cpt['icon'])) {
            $cpt['icon'] = '';
        }

        $cpt['intersections_partial'] = isset($cpt['intersections_partial']) ? 'yes' : 'no';
        if (isset($cpt['intersections_structure'])) {
            $cpt['intersections_structure'] = trim(strip_tags($cpt['intersections_structure']));
            $cpt['intersections_structure'] = str_replace(' ', '-', $cpt['intersections_structure']);
            if ($cpt['intersections_structure'] == '') {
                if ($cpt['intersections'] == 'max') $cpt['intersections'] = 'yes';
                if ($cpt['intersections'] == 'adv') $cpt['intersections'] = 'no';
            }
        } else {
            $cpt['intersections_structure'] = '';
        }

        $cpt['date_archives'] = isset($cpt['date_archives']) ? 'yes' : 'no';
        $cpt['permalinks_active'] = isset($cpt['permalinks_active']) ? 'yes' : 'no';
        if (isset($cpt['permalinks_structure'])) {
            $cpt['permalinks_structure'] = trim(strip_tags($cpt['permalinks_structure']));
            $cpt['permalinks_structure'] = str_replace(' ', '-', $cpt['permalinks_structure']);
            if ($cpt['permalinks_structure'] == '') {
                $cpt['permalinks_active'] = 'no';
            }
        } else {
            $cpt['permalinks_structure'] = '';
        }

        $this->add_cpt_caps($cpt['caps_type']);

        $cpt['caps'] = isset($cpt['caps']) ? $cpt['caps'] : $gdtt->post_type_caps;
        $cpt['supports'] = isset($cpt['supports']) ? array_keys($cpt['supports']) : array();
	$cpt['taxonomies'] = isset($cpt['taxonomies']) ? array_keys($cpt['taxonomies']) : array();
	$cpt['special'] = isset($cpt['enhanced']) ? array_keys($cpt['enhanced']) : array();
        if (isset($cpt['enhanced'])) unset($cpt['enhanced']);

        if ($editable) {
            $cpt["name"] = trim(strtolower(sanitize_user($cpt["name"], true)));
            if (empty($cpt["name"])) {
                $errors[] = array("cpt_name", __("Name is required.", "gd-taxonomies-tools"));
            } else if (!$this->is_term_valid($cpt["name"])) {
                $errors[] = array("cpt_name", __("Name you used is not valid.", "gd-taxonomies-tools"));
            } else if (in_array($cpt["name"], $gdtt->reserved_names)) {
                $errors[] = array("cpt_name", __("Name you used is reserved.", "gd-taxonomies-tools"));
            }
            if (!empty($errors)) {
                $blocks[] = array(".gdr2-panel-basics .gdr2-group-name");
            }
        }
        foreach ($cpt["labels"] as $key => $label) {
            $cpt["labels"][$key] = trim($label);
            if ($cpt["labels"][$key] === "") {
                $error = array("cpt_labels_".$key, __("Label value is required.", "gd-taxonomies-tools"));
                if ($key != "name" && $key != "singular_name") {
                    $error[1].= " ".__("You can use Auto Fill button to get this value.", "gd-taxonomies-tools");
                    $blocks[] = array(".gdr2-panel-basics .gdr2-group-labels_expanded");
                } else {
                    $blocks[] = array(".gdr2-panel-basics .gdr2-group-labels_basic");
                }
                $errors[] = $error;
            }
        }

        if (empty($errors)) {
            if ($cpt["yourls_active"] == "yes") {
                $this->save_yourls_options($cpt["name"], 
                        $cpt["yourls_active_link"] == "yes", 
                        $cpt["yourls_active_auto"] == "yes");
            }
            if ($cpt["id"] == 0) {
                $gdtt->o["cpt_internal"] = (int)$gdtt->o["cpt_internal"] + 1;
                $cpt["id"] = $gdtt->o["cpt_internal"];
                $gdtt->p[] = $cpt;
                $result["id"] = $cpt["id"];

                update_option("gd-taxonomy-tools", $gdtt->o);
                update_option("gd-taxonomy-tools-cpt", $gdtt->p);
            } else if ($cpt["id"] == -1) {
                $gdtt->nn_p["full"][$cpt["name"]] = $cpt;
                $gdtt->nn_p["status"][$cpt["name"]] = $cpt["active"];
                $gdtt->nn_p["simple"][$cpt["name"]] = array("active" => $cpt["active"],
                    "name" => $cpt["name"], "special" => $cpt["special"],
                    "taxonomies" => $cpt["taxonomies"], "supports" => $cpt["supports"]
                );

                update_option("gd-taxonomy-tools-nn-cpt", $gdtt->nn_p);
            } else {
                $id = $this->find_custompost_pos($cpt["id"]);
                if ($id > -1) {
                    $gdtt->p[$id] = $cpt;

                    update_option("gd-taxonomy-tools-cpt", $gdtt->p);
                }
            }

            $gdtt->o["force_rules_flush"] = 1;
            update_option("gd-taxonomy-tools", $gdtt->o);
        } else {
            $result["status"] = "error";
            $result["errors"] = $errors;
            $result["groups"] = $blocks;
        }

        $gdtt->unset_cache("cpt", $cpt["name"]);
        return new gdrClass($result);
    }

    function save_settings_tax_full($tax, $editable = true) {
        global $gdtt;

        $errors = $blocks = array();
        $result = array("status" => "ok");

        $tax["id"] = intval($tax["id"]);
        if ($tax["id"] > -1) {
            $cpt["active"] = isset($tax["active"]) ? 1 : 0;
        }

        $post_types = isset($tax["post_types"]) ? array_keys($tax["post_types"]) : array();
        $tax["domain"] = join(",", $post_types);
        $tax["supports"] = isset($tax["supports"]) ? array_keys($tax["supports"]) : array();
	$tax["special"] = isset($tax["enhanced"]) ? array_keys($tax["enhanced"]) : array();
        if (isset($tax["enhanced"])) unset($tax["enhanced"]);

        $tax["description"] = trim(strip_tags($tax["description"]));

        $tax["query"] = trim(strip_tags($tax["query"]));
        $tax["query_custom"] = trim(strip_tags($tax["query_custom"]));
        $tax["rewrite"] = trim(strip_tags($tax["rewrite"]));
        $tax["rewrite_custom"] = trim(strip_tags($tax["rewrite_custom"]));
        $tax["caps_type"] = trim(strip_tags($tax["caps_type"]));
        $tax["metabox"] = trim(strip_tags($tax["metabox"]));

        $this->add_tax_caps($tax["caps_type"]);

        $tax["hierarchy"] = isset($tax["hierarchy"]) ? "yes" : "no";
        $tax["rewrite_hierarchy"] = isset($tax["rewrite_hierarchy"]) ? "yes" : "no";
        $tax["rewrite_front"] = isset($tax["rewrite_front"]) ? "yes" : "no";
        $tax["public"] = isset($tax["public"]) ? "yes" : "no";
        $tax["ui"] = isset($tax["ui"]) ? "yes" : "no";
        $tax["cloud"] = isset($tax["cloud"]) ? "yes" : "no";
        $tax["nav_menus"] = isset($tax["nav_menus"]) ? "yes" : "no";

        if ($editable) {
            $tax["name"] = trim(strtolower(sanitize_user($tax["name"], true)));
            if (empty($tax["name"])) {
                $errors[] = array("tax_name", __("Name is required.", "gd-taxonomies-tools"));
            } else if (!$this->is_term_valid($tax["name"])) {
                $errors[] = array("tax_name", __("Name you used is not valid.", "gd-taxonomies-tools"));
            } else if (in_array($tax["name"], $gdtt->reserved_names)) {
                $errors[] = array("tax_name", __("Name you used is reserved.", "gd-taxonomies-tools"));
            }
            if (!empty($errors)) {
                $blocks[] = array(".gdr2-panel-basics .gdr2-group-name");
            }
        }
        foreach ($tax["labels"] as $key => $label) {
            $tax["labels"][$key] = trim($label);
            if ($tax["labels"][$key] === "") {
                $error = array("tax_labels_".$key, __("Label value is required.", "gd-taxonomies-tools"));
                if ($key != "name" && $key != "singular_name") {
                    $error[1].= " ".__("You can use Auto Fill button to get this value.", "gd-taxonomies-tools");
                    $blocks[] = array(".gdr2-panel-basics .gdr2-group-labels_expanded");
                } else {
                    $blocks[] = array(".gdr2-panel-basics .gdr2-group-labels_basic");
                }
                $errors[] = $error;
            }
        }

        if (empty($errors)) {
            if ($tax["id"] == 0) {
                $gdtt->o["tax_internal"] = (int)$gdtt->o["tax_internal"] + 1;
                $tax["id"] = $gdtt->o["tax_internal"];
                $gdtt->t[] = $tax;
                $result["id"] = $tax["id"];

                update_option("gd-taxonomy-tools", $gdtt->o);
                update_option("gd-taxonomy-tools-tax", $gdtt->t);
            } else if ($tax["id"] == -1) {
                $gdtt->nn_t["full"][$tax["name"]] = $tax;
                $gdtt->nn_t["status"][$tax["name"]] = $tax["active"];
                $gdtt->nn_t["simple"][$tax["name"]] = array(
                    "active" => $tax["active"], "metabox" => $tax["metabox"],
                    "name" => $tax["name"], "special" => $tax["special"], 
                    "domain" => $tax["domain"]);

                update_option("gd-taxonomy-tools-nn-tax", $gdtt->nn_t);
            } else {
                $id = $this->find_taxonomy_pos($tax["id"]);
                if ($id > -1) {
                    $gdtt->t[$id] = $tax;

                    update_option("gd-taxonomy-tools-tax", $gdtt->t);
                }
            }

            $gdtt->o["force_rules_flush"] = 1;
            update_option("gd-taxonomy-tools", $gdtt->o);
        } else {
            $result["status"] = "error";
            $result["errors"] = $errors;
            $result["groups"] = $blocks;
        }

        $gdtt->unset_cache("tax", $tax["name"]);
        return new gdrClass($result);
    }

    function ajax_save_settings() {
        check_ajax_referer("gd-cpt-tools");

        $data = $_POST;
        $resp = null;
        switch ($data["gdr2_action"]) {
            case "cpt-simple":
                $resp = $this->save_settings_cpt_simple($data["cpt"]);
                break;
            case "tax-simple":
                $resp = $this->save_settings_tax_simple($data["tax"]);
                break;
            case "cpt-full":
                $resp = $this->save_settings_cpt_full($data["cpt"], $data["gdr2_editable"] == "yes");
                break;
            case "tax-full":
                $resp = $this->save_settings_tax_full($data["tax"], $data["gdr2_editable"] == "yes");
                break;
            default:
                break;
        }

        die(json_encode($resp));
    }
}

?>