<?php

class gdCPTShortcodes extends gdr2_Shortcodes {
    public function init() {
        $this->shortcodes = array(
            'cpt_field' => array(
                'name' => __("Custom Field Value", "gd-taxonomies-tools"),
                'atts' => array('code' => '', 'post' => 0, 'image' => 'url', 'tag' => '', 'label' => true, 'class' => '', 'style' => '', 'term' => 'name', 'target' => '', 'rel' => '', 'raw' => false)
            ),
            'cpt_termlink' => array(
                'name' => __("Link to taxonomy term", "gd-taxonomies-tools"),
                'atts' => array('tax' => 'post_tag', 'term' => '', 'target' => '', 'rel' => ''),
                'alias' => array('termlink')
            )
        );
    }

    public function shortcode_cpt_field($atts) {
        global $gdtt, $post;
        $atts = $this->atts('cpt_field', $atts);

        $field_name = $atts['code'];
        if ($atts['post'] == 0) $atts['post'] = $post->ID;
        $field = isset($gdtt->m['fields'][$field_name]) ? $gdtt->m['fields'][$field_name] : new gdrClass(array('type' => gdttCustomType::TEXT));
        $value = get_post_meta($atts['post'], $field_name, true);

        return $gdtt->prepare_cpt_field($field, $value, $atts);
    }

    public function shortcode_cpt_termlink($atts, $content = '') {
        $atts = $this->atts('cpt_termlink', $atts);

        $term_link = get_term_link($atts['term'], $atts['tax']);
        if (is_string($term_link)) {
            if ($content == '') {
                $term = &get_term($atts['term'], $atts['tax']);
                $content = $term->name;
            }

            return sprintf('<a href="%s"%s%s>%s</a>',
                    get_term_link($atts['term'], $atts['tax']),
                    $atts['target'] != '' ? ' target="'.$atts['target'].'"' : '',
                    $atts['rel'] != '' ? ' rel="'.$atts['rel'].'"' : '',
                    $content);
        }

        return $content;
    }
}

global $gdtt_shortcodes;
$gdtt_shortcodes = new gdCPTShortcodes();

?>