<?php

if (!defined('ABSPATH')) exit;

$gdcpt_log = new gdr2_Log(GDTAXTOOLS_LOG_PATH);

function gdt_dump($val) {
    global $gdcpt_log;
    $gdcpt_log->sdump($val);
}

function gdt_log($val) {
    global $gdcpt_log;
    $gdcpt_log->slog($val);
}

function gdtt_valid_rewrite_post_types() {
    $options = array("public" => true, "_builtin" => false);
    $post_types = get_post_types($options, "objects");
    $found = array();
    foreach ($post_types as $post_type => $object) {
        if (isset($object->rewrite['slug']) && !empty($object->rewrite['slug'])) {
            $found[$post_type] = $object;
        }
    }
    return $found;
}

function gdtt_is_valid_rewrite_post_type($post_type) {
    if (is_array($post_type)) {
        if (count($post_type) != 1) {
            return false;
        }
        $post_type = $post_type[0];
    }
    $post_type = get_post_type_object($post_type);
    if (!is_null($post_type) &&
        $post_type->_builtin == false &&
        $post_type->public == true &&
        isset($post_type->rewrite['slug']) &&
        !empty($post_type->rewrite['slug']) &&
        $post_type->hierarchical == false ) {
            return $post_type;
    }
    return false;
}

function gdtt_render_taxonomies($tax = "") {
    global $wp_taxonomies;
    foreach ($wp_taxonomies as $taxonomy => $cnt) {
        $current = $tax == $taxonomy ? ' selected="selected"' : '';
        echo "\t<option value='".$taxonomy."'".$current.">".$cnt->label."</option>\r\n";
    }
}

function gdtt_render_post_types($post_type = "") {
    $wp_post_types = gdtt_get_public_post_types(true);

    echo "\t<option value=''>".__("All post types", "gd-taxonomies-tools")."</option>\r\n";
    foreach ($wp_post_types as $t => $cpt) {
        $current = $t == $post_type ? ' selected="selected"' : '';
        echo "\t<option value='".$t."'".$current.">".$cpt->label."</option>\r\n";
    }
}

function gdtt_render_alert($title, $content) {
    ?>
    <div class="ui-widget">
        <div class="ui-state-error ui-corner-all" style="padding: 0pt 0.7em; margin: 10px 0;">
            <p>
                <span style="float: left; margin-right: 0.3em;" class="ui-icon ui-icon-alert"></span>
                <strong><?php echo $title; ?>:</strong> <?php echo $content; ?>
            </p>
        </div>
    </div>
    <?php
}

function gdtt_render_notice($title, $content) {
    ?>
    <div class="ui-widget">
        <div class="ui-state-highlight ui-corner-all" style="padding: 0pt 0.7em; margin: 10px 0;">
            <p>
                <span style="float: left; margin-right: 0.3em;" class="ui-icon ui-icon-info"></span>
                <strong><?php echo $title; ?>:</strong> <?php echo $content; ?>
            </p>
        </div>
    </div>
    <?php
}

function gdtt_generate_custom_posts_options($cpt) {
    $cpt["description"] = !isset($cpt["description"]) ? "" : $cpt["description"];
    $cpt["rewrite_slug"] = !isset($cpt["rewrite_slug"]) ? "" : $cpt["rewrite_slug"];
    $cpt["query_slug"] = !isset($cpt["query_slug"]) ? "" : $cpt["query_slug"];
    $cpt["rewrite_feeds"] = !isset($cpt["rewrite_feeds"]) ? "yes" : $cpt["rewrite_feeds"];
    $cpt["rewrite_pages"] = !isset($cpt["rewrite_pages"]) ? "yes" : $cpt["rewrite_pages"];
    $cpt["show_in_menu"] = !isset($cpt["show_in_menu"]) ? "yes" : $cpt["show_in_menu"];

    $caps = $labels = array();

    $rewrite = $cpt["rewrite"] == "no" ? false : true;
    if ($rewrite) {
        $rewrite = array("slug" => $cpt["rewrite"] == "yes_custom" ? $cpt["rewrite_slug"] : $cpt["name"],
                         "with_front" => $cpt["rewrite_front"] == "yes",
                         "feeds" => $cpt["rewrite_feeds"] == "yes",
                         "pages" => $cpt["rewrite_pages"] == "yes");
    }

    $query_var = false;
    if ($cpt["query"] != "no") {
        $query_var = true;
        if ($cpt["query"] == "yes_custom" && $cpt["query_slug"] != "") {
            $query_var = $cpt["query_slug"];
        }
    }

    $archive = false;
    if ($cpt["archive"] != "no") {
        $archive = true;
        if ($cpt["archive"] == "yes_custom" && $cpt["archive_slug"] != "") {
            $archive = $cpt["archive_slug"];
        }
    }

    if (!isset($cpt["labels"])) {
        $labels = array("name" => $cpt["label"], "singular_name" => $cpt["label_singular"]);
    } else {
        $labels = $cpt["labels"];
    }

    if (isset($cpt["caps"])) {
        $caps = $cpt["caps"];
    }

    $cpt["public"] = $cpt["public"] == "yes";
    $cpt["menu_position"] = !isset($cpt["menu_position"]) ? "__auto__" : $cpt["menu_position"];
    $cpt["ui"] = !isset($cpt["ui"]) ? $cpt["public"] : $cpt["ui"] == "yes";
    $cpt["nav_menus"] = !isset($cpt["nav_menus"]) ? $cpt["public"] : $cpt["nav_menus"] == "yes";
    $cpt["can_export"] = !isset($cpt["can_export"]) ? $cpt["public"] : $cpt["can_export"] == "yes";
    $cpt["publicly_queryable"] = !isset($cpt["publicly_queryable"]) ? $cpt["public"] : $cpt["publicly_queryable"] == "yes";
    $cpt["exclude_from_search"] = !isset($cpt["exclude_from_search"]) ? !$cpt["public"] : $cpt["exclude_from_search"] == "yes";

    $options = array(
        "labels" => $labels,
        "publicly_queryable" => $cpt["publicly_queryable"],
        "exclude_from_search" => $cpt["exclude_from_search"],
        "capability_type" => $cpt["caps_type"],
        "hierarchical" => $cpt["hierarchy"] == "yes",
        "public" => $cpt["public"],
        "rewrite" => $rewrite,
        "show_in_menu" => $cpt["show_in_menu"] == "yes",
        "has_archive" => $archive,
        "query_var" => $query_var,
        "supports" => (array)$cpt["supports"],
        "taxonomies" => (array)$cpt["taxonomies"],
        "show_ui" => $cpt["ui"],
        "can_export" => $cpt["can_export"],
        "show_in_nav_menus" => $cpt["nav_menus"],
        "_edit_link" => $cpt["edit_link"]
    );

    if ($cpt["menu_icon"] != "") {
        $options["menu_icon"] = $cpt["menu_icon"];
    }

    if ($cpt["description"] != "") {
        $options["description"] = $cpt["description"];
    }

    if (!in_array($cpt["menu_position"], array("__auto__", "__block__"))) {
        $options["menu_position"] = intval($cpt["menu_position"]);
    }

    if ($cpt["capabilites"] != "type") {
        $options["map_meta_cap"] = true;
        $options["capabilities"] = array_values($caps);
    }

    return $options;
}

function gdtt_generate_custom_taxonomies_options($tax) {
    $rewrite = $query_var = true;
    if ($tax["rewrite"] == "no") {
        $rewrite = false;
    } else {
        $tax["rewrite_hierarchy"] = !isset($tax["rewrite_hierarchy"]) ? "auto" : $tax["rewrite_hierarchy"];
        $tax["with_front"] = !isset($tax["rewrite_front"]) ? "yes" : $tax["rewrite_front"];
        $rewrite = array("hierarchical" => $tax["rewrite_hierarchy"] != "no",
                         "with_front" => $tax["with_front"] == "yes");
        if ($tax["rewrite"] == "yes_name") {
            $rewrite["slug"] = $tax["name"];
        } else {
            $rewrite["slug"] = $tax["rewrite_custom"];
        }
    }
    if ($tax["query"] == "no") $query_var = false;
    if ($tax["query"] == "yes_custom") $query_var = $tax["query_custom"];

    $tax["public"] = !isset($tax["public"]) ? true : ($tax["public"] == "yes");
    $tax["ui"] = !isset($tax["ui"]) ? $tax["public"] : ($tax["ui"] == "yes");
    $tax["nav_menus"] = !isset($tax["nav_menus"]) ? $tax["public"] : $tax["nav_menus"] == "yes";
    $tax["cloud"] = !isset($tax["cloud"]) ? $tax["public"] : $tax["cloud"] == "yes";

    if (!isset($tax["labels"])) {
        $labels = array("name" => $tax["label"], "singular_name" => $tax["label_singular"]);
    } else {
        $labels = $tax["labels"];
        $labels["parent_item_colon"] = $labels["parent_item"].":";
    }

    if (!isset($tax["caps"])) {
        $caps = array();
    } else {
        $caps = $tax["caps"];
    }

    $options = array(
        "hierarchical" => $tax["hierarchy"] == "yes",
        "rewrite" => $rewrite,
        "query_var" => $query_var,
        "public" => $tax["public"],
        "show_ui" => $tax["ui"],
        "show_tagcloud" => $tax["cloud"],
        "labels" => $labels,
        "capabilities" => $caps,
        "show_in_nav_menus" => $tax["nav_menus"]
    );

    return $options;
}

function gdtt_custom_post_templates() {
    $themes = get_themes();
    $theme = get_current_theme();
    $templates = $themes[$theme]['Template Files'];
    $post_templates = array("__default__" => __("Default", "gd-taxonomies-tools"));

    $base = array(trailingslashit(get_template_directory()), trailingslashit(get_stylesheet_directory()));

    foreach ((array)$templates as $template) {
        $template = WP_CONTENT_DIR . str_replace(WP_CONTENT_DIR, '', $template);
        $basename = str_replace($base, '', $template);

        if (false !== strpos($basename, '/')) continue;

        $template_data = implode('', file( $template ));

        $name = '';
        if (preg_match( '|Post Template:(.*)$|mi', $template_data, $name)) {
            $name = _cleanup_header_comment($name[1]);
        }

        if (!empty($name)) {
            if(basename($template) != basename(__FILE__)) {
                $post_templates[$basename] = trim($name);
            }
        }
    }

    return $post_templates;
}

function gdtt_embed_richeditor($ids) {
    global $editing;
    if (!($editing && user_can_richedit())) return; ?>
    <script type="text/javascript">
        /* <![CDATA[ */
        jQuery(document).ready(function() {
        <?php foreach ($ids as $id) { ?>
            jQuery("#<?php echo $id; ?>").addClass("mceEditor");
            jQuery("#<?php echo $id; ?>").wrap('<div id="<?php echo $id; ?>editorcontainer" class="gdtt-editorcontainer"></div>'); 
            tinyMCE.execCommand("mceAddControl", false, "<?php echo $id; ?>");
        <?php } ?>
        });
        /* ]]> */
    </script>
<?php }

function gdtt_get_override_post_type($cpt_name, $post_type) {
    $cpt = array("active" => "no", "name" => $cpt_name, "taxonomies" => $post_type->taxonomies,
        "caps" => (array)$post_type->cap, "labels" => (array)$post_type->labels,
        "id" => -1, "publicly_queryable" => $post_type->publicly_queryable ? "yes" : "no",
        "exclude_from_search" => $post_type->exclude_from_search ? "yes" : "no",
        "description" => $post_type->description, "caps_type" => $post_type->capability_type,
        "capabilites" => "type", "hierarchy" => $post_type->hierarchical ? "yes" : "no",
        "public" => $post_type->public ? "yes" : "no", "label" => $post_type->label,
        "ui" => $post_type->show_ui ? "yes" : "no", "rewrite" => $post_type->rewrite ? "yes" : "no",
        "rewrite_slug" => "", "can_export" => $post_type->can_export ? "yes" : "no",
        "edit_link" => $post_type->_edit_link, "query" => $post_type->query_var ? "yes" : "no",
        "nav_menus" => $post_type->show_in_nav_menus ? "yes" : "no", 
        "supports" => gdtt_get_post_type_features($cpt_name), "special" => array()
    );
    return $cpt;
}

function gdtt_get_override_taxonomy($tax_name, $tax_type) {
    $tax = array("hierarchy" => $tax_type->hierarchical ? "yes" : "no",
        "description" => $tax_type->description, "rewrite_front" => "yes",
        "caps_type" => "categories", "caps" => (array)$tax_type->cap, 
        "labels" => (array)$tax_type->labels, "domain" => $tax_type->object_type, 
        "label" => $tax_type->label, "rewrite_hierarchy" => "auto",
        "active" => "no", "nav_menus" => $tax_type->show_in_nav_menus ? "yes" : "no",
        "public" => $tax_type->public ? "yes" : "no", "rewrite" => "yes",
        "ui" => $tax_type->show_ui ? "yes" : "no", "rewrite_custom" => "",
        "cloud" => $tax_type->show_tagcloud ? "yes" : "no", "id" => -1,
        "query" => "yes", "query_custom" => "", "name" => $tax_name, 
        "special" => array(), "metabox" => "auto"
    );
    if (is_bool($tax_type->query_var)) {
        $tax["query"] = $tax_type->query_var ? "yes" : "no";
    } else {
        $tax["query"] = "yes_custom";
        $tax["query_custom"] = $tax_type->query_var;
    }
    if (is_bool($tax_type->rewrite)) {
        $tax["rewrite"] = $tax_type->rewrite ? "yes" : "no";
    } else {
        $tax["rewrite"] = "yes_custom";
        $tax["rewrite_custom"] = $tax_type->rewrite["slug"];
    }
    return $tax;
}

function gdtt_update_custom_fields() {
    global $gdtt;

    foreach ($gdtt->m['fields'] as $key => $property) {
        if ($property->type == 'radio') {
            $property->type = 'select';
            $property->selection = 'radio';
        }

        if ($property->type == 'checkbox') {
            $property->type = 'select';
            $property->selection = 'checkbox';
        }

        if ($property->type == 'select') {
            $values = array();

            foreach ($property->assoc_values as $key => $value) {
                $values[] = $key."|".$value;
            }

            $property->assoc_values = $values;
        }
    }
}

?>