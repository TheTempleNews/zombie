<?php

if (!defined('ABSPATH')) exit;

class gdCPTCore_bbPress {
    var $meta_values = array();

    function __construct() {
        add_action('bbp_theme_before_topic_form_title', array(&$this, 'bbpress_reply_form'));
        add_action('bbp_theme_after_reply_form_content', array(&$this, 'bbpress_reply_form'));
        add_action('bbp_theme_after_reply_form_tags', array(&$this, 'bbpress_reply_form'));
        add_action('bbp_theme_before_reply_form_submit_wrapper', array(&$this, 'bbpress_reply_form'));

        add_action('bbp_theme_before_topic_form_title', array(&$this, 'bbpress_topic_form'));
        add_action('bbp_theme_after_topic_form_title', array(&$this, 'bbpress_topic_form'));
        add_action('bbp_theme_after_topic_form_content', array(&$this, 'bbpress_topic_form'));
        add_action('bbp_theme_after_topic_form_tags', array(&$this, 'bbpress_topic_form'));
        add_action('bbp_theme_before_topic_form_submit_wrapper', array(&$this, 'bbpress_topic_form'));

        add_action('bbp_edit_reply_pre_extras', array(&$this, 'bbpress_reply_save'));
        add_action('bbp_edit_topic_pre_extras', array(&$this, 'bbpress_topic_save'));
        add_action('bbp_new_reply_pre_extras', array(&$this, 'bbpress_reply_save'));
        add_action('bbp_new_topic_pre_extras', array(&$this, 'bbpress_topic_save'));

        add_action('bbp_edit_reply', array(&$this, 'bbpress_reply_insert'));
        add_action('bbp_edit_topic', array(&$this, 'bbpress_topic_insert'));
        add_action('bbp_new_reply', array(&$this, 'bbpress_reply_insert'));
        add_action('bbp_new_topic', array(&$this, 'bbpress_topic_insert'));

        if (gdtt_get('bbpress_embed_js') == 1) {
            wp_enqueue_script('gdcpt-jquery', GDTAXTOOLS_URL.'js/bbpress.js', array('jquery'), false, true);
        }

        if (gdtt_get('bbpress_embed_css') == 1) {
            wp_enqueue_style('gdcpt-css', GDTAXTOOLS_URL.'css/bbpress.css');
        }

        if (gdtt_get('bbpress_embed_active') == 1) {
            add_action('bbp_get_reply_content', array(&$this, 'bbpress_reply_embed'), 10, 2);
            add_action('bbp_get_topic_content', array(&$this, 'bbpress_topic_embed'), 10, 2);
        }
    }

    private function _bbpress_form($code = 'topic', $id = 0) {
        global $gdtt;
        $forum_id = bbp_get_forum_id();
        $filter = current_filter();

        $override = $gdtt->bbpress_forum_settings($forum_id, true);
        $metabox = $override[$code];
        $location = $override['location_'.$code];

        if ($metabox == '__default__' || $metabox == '__parent__') {
            $metabox = gdtt_get('bbpress_metabox_'.$code);
        }
        if ($location == '__default__' || $location == '__parent__') {
            $location = gdtt_get('bbpress_metabox_location_'.$code);
        }

        if ($metabox != '__none__' && $filter == $location) {
            if (isset($gdtt->m['boxes'][$metabox])) {
                gdtt_update_custom_fields();
                $meta = $gdtt->m['boxes'][$metabox];

                $_ID = 'gdtt_box_'.$meta->code.'_';
                $_NAME = 'gdtt_box['.$meta->code.'][';
                $_F = $gdtt->m['fields'];
                $fromdb_values = $id > 0 ? $gdtt->meta_box_current_values($id, $meta->code) : array();
                $posted_values = isset($_POST['gdtt_box'][$meta->code]) ? $_POST['gdtt_box'][$meta->code] : $fromdb_values;

                include(GDTAXTOOLS_PATH.'forms/bbpress/embed_form.php');
            }
        }
    }

    private function _bbpress_insert($id, $code = 'topic') {
        if (is_array($this->meta_values) && !empty($this->meta_values)) {
            foreach ($this->meta_values as $key => $value) {
                add_post_meta($id, $key, $value);
            }
        }
    }

    private function _bbpress_save($code = 'topic') {
        global $gdtt;
        $forum_id = bbp_get_forum_id();

        $override = $gdtt->bbpress_forum_settings($forum_id, true);
        $metabox = $override[$code];
        if ($metabox == '__default__') {
            $metabox = gdtt_get('bbpress_metabox_'.$code);
        }

        if ($metabox != '__none__') {
            if (isset($gdtt->m['boxes'][$metabox]) && isset($_POST['gdtt_box'][$metabox])) {
                $meta = $gdtt->m['boxes'][$metabox];
                $data = $_POST['gdtt_box'][$meta->code];
                $_ID = 'gdtt_box_'.$meta->code.'_';

                $done = $values = array();
                foreach ($meta->fields as $f) {
                    $field = $gdtt->m['fields'][$f];
                    if (!isset($done[$f])) { $done[$f] = 0; } else { $done[$f]++; }
                    
                    $new = null;
                    $ok = true;
                    switch ($field->type) {
                        default:
                        case gdttCustomType::TEXT:
                        case gdttCustomType::NUMBER:
                        case gdttCustomType::SELECT:
                        case gdttCustomType::SELECT_RADIO:
                        case gdttCustomType::IMAGE:
                        case gdttCustomType::DATE:
                            $new = trim(strip_tags($data[$f][$done[$f]]));
                            $ok = $new != '';
                            break;
                        case gdttCustomType::SELECT_CHECKS:
                            $new = (array)$data[$f][$done[$f]];
                            break;
                        case gdttCustomType::COLOR:
                            $new = trim(strip_tags($data[$f][$done[$f]]));
                            $new = substr(trim(str_replace('#', '', $new)), 0, 6);
                            $ok = $new != '';
                            break;
                        case gdttCustomType::BOOLEAN:
                            $new = isset($data[$f][$done[$f]]) ? 1 : 0;
                            break;
                        case gdttCustomType::LISTING:
                            $new = trim(strip_tags($data[$done[$f]]));
                            $new = gdr2_split_textarea($new);
                            $ok = !empty($new);
                            break;
                        case gdttCustomType::HTML:
                        case gdttCustomType::EDITOR:
                            $new = stripslashes(htmlentities($data[$f][$done[$f]], ENT_QUOTES, GDR2_CHARSET));
                            $ok = $new != '';
                            break;
                    }

                    $this->meta_values[$f] = $new;

                    if ($field->required && !$ok) {
                        bbp_add_error($_ID.$field->code."_".$done[$f], '<strong>'.__("ERROR", "gd-taxonomies-tools").'</strong>: '.$field->name." ".__("cannot be empty.", "gd-taxonomies-tools"));
                    }
                }

                if (!bbp_has_errors()) {
                    $this->meta_values = array();
                }
            }
        }
    }

    private function _bbpress_embed($content, $id, $code = 'topic') {
        global $gdtt, $user_ID;
        $forum_id = bbp_get_forum_id();

        $code = bbp_is_topic($id) ? 'topic' : 'reply';
        $show = gdtt_get('bbpress_embed_anyone') == 1;

        if (!$show) {
            $post = get_post($id);
            $show = gdtt_get('bbpress_embed_author') == 1 && $post->post_author == $user_ID;

            if (!$show && is_user_logged_in()) {
                global $current_user;
                if (is_array($current_user->roles)) {
                    $value = (array)gdtt_get('bbpress_embed_author');
                    $matched = array_intersect($current_user->roles, $value);
                    $show = !empty($matched);
                }
            }
        }

        if ($show) {
            $override = $gdtt->bbpress_forum_settings($forum_id, true);
            $metabox = $override[$code];
            if ($metabox == '__default__') {
                $metabox = gdtt_get('bbpress_metabox_'.$code);
            }

            if ($metabox != "__none__") {
                if (isset($gdtt->m['boxes'][$metabox])) {
                    $meta = $gdtt->m['boxes'][$metabox];
                    $values = $gdtt->meta_box_current_values($id, $metabox);

                    $content.= '<div class="bbp-gdtt-fields">';
                    $content.= apply_filters('gdcpt_bbpress_embed_before', "", $id, $code);
                    foreach ($values as $key => $value) {
                        $atts = array('class' => 'gdtt-field gdtt-field-'.$key);
                        $field = isset($gdtt->m['fields'][$key]) ? $gdtt->m['fields'][$key] : new gdrClass(array('type' => gdttCustomType::TEXT));
                        $content.= $gdtt->prepare_cpt_field($field, $value[0], $atts);
                    }
                    $content.= apply_filters('gdcpt_bbpress_embed_before', "", $id, $code);
                    $content.= '</div>';
                }
            }
        }

        return $content;
    }

    public function bbpress_reply_insert($reply_id) {
        $this->_bbpress_insert($reply_id, "reply");
    }

    public function bbpress_topic_insert($topic_id) {
        $this->_bbpress_insert($topic_id, 'topic');
    }

    public function bbpress_reply_save() {
        $this->_bbpress_save('reply');
    }

    public function bbpress_topic_save() {
        $this->_bbpress_save('topic');
    }

    public function bbpress_reply_form() {
        $reply_id = bbp_is_reply_edit() ? bbp_get_reply_id() : 0;
        $this->_bbpress_form('reply', $reply_id);
    }

    public function bbpress_topic_form() {
        $topic_id = bbp_is_topic_edit() ? bbp_get_topic_id() : 0;
        $this->_bbpress_form('topic', $topic_id);
    }

    public function bbpress_reply_embed($content, $id) {
        return $this->_bbpress_embed($content, $id, 'reply');
    }

    public function bbpress_topic_embed($content, $id) {
        return $this->_bbpress_embed($content, $id, 'topic');
    }
}

$gdtt_bbpress = new gdCPTCore_bbPress();

?>