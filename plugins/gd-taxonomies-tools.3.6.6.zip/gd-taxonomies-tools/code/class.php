<?php

if (!defined('ABSPATH')) exit;

class gdCPTTools {
    var $sf = array(
        'tax' => array(),
        'cpt' => array(), 
        'totals' => array('in_menu_block' => array()),
        'intersections' => array(),
        'yourls' => array()
    );

    var $active = array(
        'cpt' => array(), 
        'tax' => array()
    );

    var $plugin_url;
    var $plugin_path;
    var $plugin_base;
    var $wp_version;
    var $edit_tax;
    var $edit_cpt;
    var $imgs;
    var $o;
    var $l;

    var $m;
    var $t;
    var $p;
    var $nn_t;
    var $nn_p;
    var $cf;

    var $cache_modded = false;
    var $menu_items = array();

    var $default_options;
    var $default_taxonomies;
    var $reserved_names;
    var $post_type_caps;
    var $taxonomy_caps;
    var $post_features;
    var $post_features_special;
    var $taxonomy_features_special;

    function __construct($base_path, $base_file) {
        $this->plugin_path = $base_path."/";
        $this->plugin_base = $base_file;

        $gdd = new gdCPTDefaults();
        $this->default_options = $gdd->default_options;
        $this->default_taxonomies = $gdd->default_taxonomies;
        $this->reserved_names = $gdd->reserved_names;
        $this->taxonomy_features_special = $gdd->taxonomy_features_special;
        $this->post_features = $gdd->post_features;
        $this->post_features_special = $gdd->post_features_special;
        $this->post_type_caps = $gdd->post_type_caps;
        $this->taxonomy_caps = $gdd->taxonomy_caps;

        define('GDTAXONOMIESTOOLS_INSTALLED', $this->default_options['version'].' '.$this->default_options['status']);
        define('GDTAXONOMIESTOOLS_VERSION', $this->default_options['version'].'_b'.($this->default_options['build'].'_pro'));

        $this->plugin_path_url();
        $this->install_plugin();
        $this->init_special_features();
        $this->actions_filters();
    }

    function _c() {
        return $this->o['cache_active'] == 1;
    }

    function plugin_path_url() {
        $this->plugin_url = plugins_url('/gd-taxonomies-tools/');

        define('GDTAXTOOLS_URL', $this->plugin_url);
        define('GDTAXTOOLS_PATH', $this->plugin_path);
    }

    function install_plugin() {
        global $wp_version;
        $this->wp_version = substr(str_replace('.', '', $wp_version), 0, 2);
        define('GDTAXTOOLS_WPV', intval($this->wp_version));

        $role = get_role('administrator');
        $role->add_cap('gdcpttools_basic');

        $this->o = get_option('gd-taxonomy-tools');
        $this->m = get_option('gd-taxonomy-tools-meta');
        $this->t = get_option('gd-taxonomy-tools-tax');
        $this->p = get_option('gd-taxonomy-tools-cpt');
        $this->cf = get_option('gd-taxonomy-tools-cache');
        $this->imgs = get_option('gd-taxonomy-tools-im-tax');
        $this->nn_t = get_option('gd-taxonomy-tools-nn-tax');
        $this->nn_p = get_option('gd-taxonomy-tools-nn-cpt');

        if (!is_array($this->t)) {
            $this->t = array();
            update_option('gd-taxonomy-tools-tax', $this->t);
        }

        if (!is_array($this->p)) {
            $this->p = array();
            update_option('gd-taxonomy-tools-cpt', $this->p);
        }

        if (!is_array($this->o)) {
            $this->o = $this->default_options;
            update_option('gd-taxonomy-tools', $this->o);
        } else if ($this->o['build'] != $this->default_options['build'] ||
            $this->o['edition'] != $this->default_options['edition']) {
            $this->o = gdr2_Core::upgrade_settings($this->o, $this->default_options);

            if ($this->o['build'] < 3000) {
                $this->o['force_rules_flush'] = 1;
            }

            $this->o['version'] = $this->default_options['version'];
            $this->o['date'] = $this->default_options['date'];
            $this->o['status'] = $this->default_options['status'];
            $this->o['build'] = $this->default_options['build'];
            $this->o['edition'] = $this->default_options['edition'];

            $this->reindex_and_save();
        }

        if (!is_array($this->cf)) {
            $this->cf = array('tax' => array(), 'cpt' => array());
            update_option('gd-taxonomy-tools-cache', $this->cf);
        }

        if (!is_array($this->nn_t)) {
            $this->nn_t = array('status' => array(), 'full' => array(), 'simple' => array());
            update_option('gd-taxonomy-tools-nn-tax', $this->nn_t);
        }

        if (!is_array($this->nn_p)) {
            $this->nn_p = array('status' => array(), 'full' => array(), 'simple' => array());
            update_option('gd-taxonomy-tools-nn-cpt', $this->nn_p);
        }

        if (!is_array($this->m)) {
            $this->m = array('boxes' => array(), 'fields' => array(), 'map' => array());
            update_option('gd-taxonomy-tools-meta', $this->m);
        }

        if (!is_array($this->imgs)) {
            $this->imgs = array();
            update_option('gd-taxonomy-tools-im-tax', $this->imgs);
        }
    }

    function reindex_and_save() {
        $count_cpt = 0; $count_tax = 0;

        foreach ($this->p as $p) {
            if ((int)$p['id'] > $count_cpt) $count_cpt = (int)$p['id'];
        }
        foreach ($this->t as $p) {
            if ((int)$p['id'] > $count_tax) $count_tax = (int)$p['id'];
        }

        $this->o['cpt_internal'] = $count_cpt;
        $this->o['tax_internal'] = $count_tax;

        update_option('gd-taxonomy-tools', $this->o);
    }
    
    function get($setting) {
        return $this->o[$setting];
    }

    function get_sf($name, $feature, $type = "cpt") {
        return isset($this->sf[$type][$name]) && 
               is_array($this->sf[$type][$name]) && 
               in_array($feature, $this->sf[$type][$name], true);
    }

    function get_sf_list($feature, $type = "cpt") {
        $list = array();
        foreach ($this->sf[$type] as $name => $features) {
            if (is_array($features) && in_array($feature, $features, true)) {
                $list[] = $name;
            }
        }
        return $list;
    }

    function get_defaults_count() {
        return $this->default_taxonomies["wp".GDTAXTOOLS_WPV];
    }

    function get_term_id($term, $taxonomy) {
        if (empty($term)) {
            return false;
        }
        if (is_object($term)) {
            $term = $term->term_id;
        }
        return intval($term);
    }

    function actions_filters() {
        add_action("init", array(&$this, "init"));
        add_action("widgets_init", array(&$this, "widgets_init"));

        add_action("init", array(&$this, "register_custom_posts"), 1);
        add_action("init", array(&$this, "register_custom_taxonomies"), 2);
        add_action("init", array(&$this, "register_for_object_types"), 3);
        add_action("init", array(&$this, "update_special_features"), 4);

        add_action("init", array(&$this, "override_post_types"), 101);
        add_action("init", array(&$this, "override_taxonomies"), 102);
        add_action("init", array(&$this, "override_special_features"), 103);

        add_action("generate_rewrite_rules", array(&$this, "generate_rewrite_rules"));
        add_filter("query_vars", array(&$this, "query_vars"));
        add_action("request", array(&$this, "wp_request"));
        add_filter("post_type_link", array(&$this, "post_type_link"), 10, 4);

        add_action("save_post", array(&$this, "save_custom_meta"), 10, 2);
        add_action("save_post", array(&$this, "save_post_meta"), 1, 2);
        add_filter("presstools_debugger_panels", array(&$this, "debugger_panel"));

        if (is_admin()) {
            add_action("admin_head", array(&$this, "admin_menu_items"));
        }
    }

    function generate_rewrite_rules($wp_rewrite) {
        $rules = array();
        $rewrite = new gdCPTRewrite();

        foreach ($this->p as $cpt) {
            if (!isset($cpt["active"]) || (isset($cpt["active"]) && $cpt["active"] == 1)) {
                if (gdtt_has_archives($cpt["name"])) {
                    if (isset($cpt["date_archives"]) && $cpt["date_archives"] == "yes") {
                        $rules = array_merge($rewrite->generate_date_archives($cpt, $wp_rewrite), $rules);
                    }

                    if (isset($cpt["intersections"])) {
                        if ($cpt["intersections"] == "max" || ($cpt["intersections"] == "adv" && $cpt["intersections_structure"] != "")) {
                            $rules = array_merge($rules, $rewrite->generate_advanced_intersection($cpt, $wp_rewrite));
                        }
                        if ($cpt["intersections"] == "max" || $cpt["intersections"] == "yes") {
                            $rules = array_merge($rewrite->generate_intersection($cpt, $wp_rewrite), $rules);
                        }

                        $rules = array_merge($rewrite->generate_standard_overrides($cpt, $wp_rewrite), $rules);
                    }
                }
            }
        }

        if (!empty($rules)) {
            $wp_rewrite->rules = $rules + $wp_rewrite->rules;
        }

        return $wp_rewrite;
    }

    function query_vars($qv) {
        foreach ($this->p as $cpt) {
            if (!isset($cpt["active"]) || (isset($cpt["active"]) && $cpt["active"] == 1)) {
                $qv[] = "cpt_postid_".$cpt["name"];
            }
        }
        return $qv;
    }

    function wp_request($query_vars) {
        $new_query_vars = array();

        foreach ($query_vars as $key => $value) {
            if (substr($key, 0, 4) == "cpt_") {
                $parts = explode("_", $key, 3);
                switch ($parts[1]) {
                    case "postid":
                        $new_query_vars["post_type"] = $parts[2];
                        $new_query_vars["p"] = $value;
                        break;
                }
            } else {
                $new_query_vars[$key] = $value;
            }
        }

        return $new_query_vars;
    }

    function post_type_link($post_link, $post, $leavename, $sample) {
        $rewritecode = array(
            "%year%", "%monthnum%", "%day%",
            "%hour%", "%minute%", "%second%",
            $leavename ? "" : "%".$post->post_type."%",
            "%post_id%", "%".$post->post_type."_id%");

        $date = explode(" ", date("Y m d H i s", strtotime($post->post_date)));
        $rewritereplace = array(
            $date[0], $date[1], $date[2],
            $date[3], $date[4], $date[5],
            $post->post_name,
            $post->ID, $post->ID);

        if (strpos($post_link, "%author%") !== false) {
            $authordata = get_userdata($post->post_author);
            $rewritecode[] = "%author%";
            $rewritereplace[] = $authordata->user_nicename;
        }

        $taxonomies = get_taxonomies(array("public" => true));
        if ($taxonomies) {
            foreach ($taxonomies as $taxonomy) {
                $t = get_taxonomy($taxonomy);
                $tax = "%".$taxonomy."%";
                if (strpos($post_link, $tax) !== false) {
                    $term = null;
                    $term_slug = "-";
                    $terms = get_the_terms($post->ID, $taxonomy);

                    if ($terms) {
                        usort($terms, "_usort_terms_by_ID");
                        $term = $terms[0];
                        $term_slug = $term->slug;
                    }

                    if (is_object($term) && is_taxonomy_hierarchical($taxonomy) && $t->rewrite["hierarchical"]) {
                        $hierarchical_slugs = array();
                        $ancestors = get_ancestors($term->term_id, $taxonomy);
                        foreach ( (array)$ancestors as $ancestor ) {
				$ancestor_term = get_term($ancestor, $taxonomy);
				$hierarchical_slugs[] = $ancestor_term->slug;
			}
			$hierarchical_slugs = array_reverse($hierarchical_slugs);
			$hierarchical_slugs[] = $term_slug;
                        $term_slug = implode("/", $hierarchical_slugs);
                    }
                    
                    $rewritecode[] = $tax;
                    $rewritereplace[] = $term_slug;
                }
            }
        }

        $post_link = str_replace($rewritecode, $rewritereplace, $post_link);
        $post_link = user_trailingslashit($post_link, "single");

        return $post_link;
    }

    function admin_menu_items() {
        if (!empty($this->menu_items)) {
            global $gdtt_icons;
            $items = $this->menu_items;
            echo '<style type="text/css">';
            foreach ($items as $name => $icon) {
                echo $gdtt_icons->get_css($icon, $name);
            }
            echo '</style>';
        }
    }

    function prepare_cpt_field($field, $value, $atts) {
        $defaults = array('image' => 'img', 'tag' => 'div', 
            'label' => true, 'class' => '', 'style' => '', 
            'term' => 'name', 'target' => '', 'rel' => '', 
            'raw' => false);
        $atts = shortcode_atts($defaults, $atts);

        $content = $value;

        switch ($field->type) {
            case gdttCustomType::SELECT:
                $available = $field->get_select_values();

                if ($field->selection == 'select' || $field->selection == 'radio') {
                    if ($field->selmethod != 'normal') {
                        $content = isset($available[$value]) ? __($available[$value]) : $value;
                    } else {
                        $content = is_null($value) ? '' : __($value);
                    }
                } else {
                    if (!is_null($value) && !empty($value)) {
                        $data = array();

                        foreach ((array)$value as $v) {
                            if ($field->selmethod != 'normal') {
                                $data[] = isset($available[$v]) ? __($available[$v]) : $v;
                            } else {
                                $data[] = __($v);
                            }
                        }

                        $content = '<ul><li>';
                        $content.= join("</li><li>", $data);
                        $content.= '</li></ul>';
                    }
                }
                break;
            case gdttCustomType::RESOLUTION:
                $content = $field->val_resolution($value);
                $content = $content['x'].' x '.$content['y'];
                break;
            case gdttCustomType::LINK:
                $title = $value;

                if (is_email($value)) {
                    $content = 'email:'.$value;
                    $atts['target'] = '';
                } else {
                    if (substr($content, 0, 7) != 'http://' && substr($content, 0, 8) != 'https://') {
                        $content = 'http://'.$content;
                    }
                }
                $content = '<a'.($atts['target'] != '' ? ' target="'.$atts['target'].'"' : '').($atts['rel'] != '' ? ' rel="'.$atts['rel'].'"' : '').' href="'.$content.'">'.$title.'</a>';
                break;
            case gdttCustomType::BOOLEAN:
                $content = $value == 1 ? __("True", "gd-taxonomies-tools") : __("False", "gd-taxonomies-tools");
                break;
            case gdttCustomType::COLOR:
                $content = "#".$value;
                break;
            case gdttCustomType::TERM:
                $term = get_term($value, $field->values);
                switch ($atts["term"]) {
                    default:
                    case "name":
                        $content = $term->name;
                        break;
                    case "id":
                        $content = $value;
                        break;
                    case "slug":
                        $content = $term->slug;
                        break;
                    case "link":
                        $content = '<a href="'.get_term_link($term).'">'.$term->name.'</a>';
                        break;
                }
                break;
            case gdttCustomType::DATE:
                if ($value != "") {
                    $content = date(get_option("date_format"), strtotime($value));
                }
                break;
            case gdttCustomType::HTML:
            case gdttCustomType::EDITOR:
                $content = gdr2_entity_decode($value);

                if (!$atts['raw']) {
                    $content = apply_filters('the_content', $content);
                    $content = str_replace(']]>', ']]&gt;', $content);
                }
                break;
            case gdttCustomType::SELECT_CHECKS:
            case gdttCustomType::LISTING:
                if (!is_null($value) && !empty($value)) {
                    $content = '<ul><li>';
                    $content.= join("</li><li>", (array)$value);
                    $content.= '</li></ul>';
                }
                break;
        }

        if (empty($content)) {
            $content = "/";
        }

        if ($atts["image"] == "img" && $field->type == gdttCustomType::IMAGE) {
            $content = '<img src="'.$content.'" />';
        }
        if ($atts["tag"] != "") {
            $actual = $content;
            $content = '<'.$atts["tag"].($atts["class"] != "" ? ' class="'.$atts["class"].'"' : '').($atts["style"] != "" ? ' style="'.$atts["style"].'"' : '').'>';
            if ($atts["label"]) { $content.= '<label>'.$field->name.':</label><div>'; }
            $content.= $actual;
            if ($atts["label"]) { $content.= '</div>'; }
            $content.= '</'.$atts["tag"].'>';
        }

        $content = apply_filters("gdcpt_cpt_field_content", $content, $value, $field->name, $atts, $field);
        return $content;
    }

    function debugger_panel($panels) {
        require_once(GDTAXTOOLS_PATH."code/internal/debug.php");
        $panels[] = "gdCPTTools";
        return $panels;
    }

    function tax_term_attach_image($taxonomy, $term, $image_id) {
        $term_id = $this->get_term_id($term, $taxonomy);
        if ($term_id !== false) {
            $image_id = intval($image_id);
            $this->imgs[$taxonomy][$term_id] = $image_id;
            update_option("gd-taxonomy-tools-im-tax", $this->imgs);
        }
    }

    function tax_term_dettach_image($taxonomy, $term) {
        if (isset($this->imgs[$taxonomy])) {
            $term_id = $this->get_term_id($term, $taxonomy);
            if ($term_id !== false) {
                if (isset($this->imgs[$taxonomy][$term_id])) {
                    unset($this->imgs[$taxonomy][$term_id]);
                    update_option("gd-taxonomy-tools-im-tax", $this->imgs);
                }
            }
        }
    }

    function tax_get_term_image($taxonomy, $term, $size = "thumbnail", $get = "img") {
        if (isset($this->imgs[$taxonomy])) {
            $term_id = $this->get_term_id($term, $taxonomy);
            if ($term_id !== false) {
                if (isset($this->imgs[$taxonomy][$term_id])) {
                    $attachemnt_id = $this->imgs[$taxonomy][$term_id];
                    switch ($get) {
                        case "id":
                            return $attachemnt_id;
                            break;
                        case "url":
                            $img = wp_get_attachment_image_src($attachemnt_id, $size);
                            return $img[0];
                            break;
                        default:
                        case "img":
                            return wp_get_attachment_image($attachemnt_id, $size);
                            break;
                    }
                }
            }
        }
        return false;
    }

    function override_special_features() {
        foreach ($this->nn_t["status"] as $tax_name => $status) {
            if (taxonomy_exists($tax_name) && $status != "no") {
                $tax = $this->nn_t[$status][$tax_name];
                $this->sf["tax"][$tax["name"]]["hierarchical"] = is_taxonomy_hierarchical($tax["name"]);
                $this->sf["tax"][$tax["name"]]["metabox_name"] = is_taxonomy_hierarchical($tax["name"]) ? $tax["name"].'div' : 'tagsdiv-'.$tax["name"];
                $this->sf["tax"][$tax["name"]]["metabox_code"] = isset($tax["metabox"]) ? $tax["metabox"] : "auto";
            }
        }
    }

    function update_special_features() {
        foreach ($this->sf['tax'] as $name => $data) {
            if (!taxonomy_exists($name)) {
                unset($this->sf["tax"][$name]);
            }
        }

        foreach ($this->sf['cpt'] as $name => $data) {
            if (!post_type_exists($name)) {
                unset($this->sf["cpt"][$name]);
            }
        }

        foreach ($this->t as $tax) {
            if (isset($tax["active"])) {
                $this->sf["tax"][$tax["name"]]["hierarchical"] = is_taxonomy_hierarchical($tax["name"]);
                $this->sf["tax"][$tax["name"]]["metabox_name"] = is_taxonomy_hierarchical($tax["name"]) ? $tax["name"].'div' : 'tagsdiv-'.$tax["name"];
                $this->sf["tax"][$tax["name"]]["metabox_code"] = isset($tax["metabox"]) ? $tax["metabox"] : "auto";
            }
        }
    }

    function init_special_features() {
        foreach ($this->nn_p["status"] as $cpt_name => $status) {
            if ($status != "no") {
                $cpt = $this->nn_p[$status][$cpt_name];
                $this->sf["cpt"][$cpt["name"]] = isset($cpt["special"]) ? $cpt["special"] : array();

                if (isset($cpt["yourls_active"]) && $cpt["yourls_active"] != "no") {
                    if ($cpt["yourls_active_link"] == "yes") { $this->sf["cpt"][$cpt["name"]][] = "yourls_link"; }
                    if ($cpt["yourls_active_auto"] == "yes") { $this->sf["cpt"][$cpt["name"]][] = "yourls_auto"; }

                    $this->sf["yourls"][$cpt["name"]] = $cpt["yourls_active_tweet"];
                }

                if (isset($cpt["menu_position"]) && $cpt["menu_position"] == "__block__") {
                    $this->sf["totals"]["in_menu_block"][] = "edit.php?post_type=".$cpt["name"];
                }
            }
        }

        foreach ($this->p as $cpt) {
            if ($cpt["active"] == 1) {
                $this->sf["cpt"][$cpt["name"]] = isset($cpt["special"]) ? $cpt["special"] : array();
                if (isset($cpt["yourls_active"]) && $cpt["yourls_active"] != "no") {
                    if ($cpt["yourls_active_link"] == "yes") { $this->sf["cpt"][$cpt["name"]][] = "yourls_link"; }
                    if ($cpt["yourls_active_auto"] == "yes") { $this->sf["cpt"][$cpt["name"]][] = "yourls_auto"; }

                    $this->sf["yourls"][$cpt["name"]] = $cpt["yourls_active_tweet"];
                }

                if (isset($cpt["intersections"])) {
                    if ($cpt["intersections"] != "no") {
                        $this->sf["cpt"][$cpt["name"]][] = "intersections";
                    }

                    if ($cpt["intersections"] == "max" || ($cpt["intersections"] == "adv" && $cpt["intersections_structure"] != "")) {
                        $this->sf["intersections"][$cpt["name"]] = $cpt["intersections_structure"];
                    }
                }

                if (isset($cpt["menu_position"]) && $cpt["menu_position"] == "__block__") {
                    $this->sf["totals"]["in_menu_block"][] = "edit.php?post_type=".$cpt["name"];
                }
            }
        }

        foreach ($this->nn_t["status"] as $tax_name => $status) {
            if ($status != "no") {
                $tax = $this->nn_t[$status][$tax_name];
                $this->sf["tax"][$tax["name"]] = $tax["special"];
            }
        }
        foreach ($this->t as $tax) {
            if (isset($tax["active"])) {
                $this->sf["tax"][$tax["name"]] = isset($tax["special"]) ? $tax["special"] : array();
            }
        }
    }

    function bbpress_forum_settings($forum_id, $deep = false, $args = array()) {
        $default = array( "topic" => "__parent__", "reply" => "__parent__",
            "location_topic" => "__parent__", "location_reply" => "__parent__");
        if (!gdr2_post_has_parent($forum_id)) {
            $default = array( "topic" => "__default__", "reply" => "__default__",
                "location_topic" => "__default__", "location_reply" => "__default__");
        }

        $data = get_post_meta($forum_id, "_gdtt_bbpress_forum_settings", true);
        $data = $data == "" ? array() : (array)$data;
        $data = wp_parse_args($data, $default);

        if (!empty($args)) {
            $data = wp_parse_args($args, $data);
        }

        if ($deep && gdr2_post_has_parent($forum_id)) {
            $args = array();
            $drill = false;
            foreach ($data as $key => $value) {
                if ($value != "__parent__") {
                    $args[$key] = $value;
                } else {
                    $drill = true;
                }
            }
            if ($drill) {
                $parent_id = gdr2_get_post_parent($forum_id);
                $data = $this->bbpress_forum_settings($parent_id, true, $args);
            }
        }

        return $data;
    }

    function meta_box_current_values($post_id, $meta_box_id) {
        $values = $current = array();
        $meta = $this->m["boxes"][$meta_box_id];
        $fields = array_unique($meta->fields);
        foreach ($fields as $f) {
            $current[$f] = (array)get_post_meta($post_id, $f, false);
        }
        $fields = $meta->fields;
        sort($fields, SORT_STRING);

        $repeat = array_count_values($fields);
        foreach ($repeat as $key => $count) {
            $i = 0;
            while ($count > 0) {
                $values[$key][] = isset($current[$key][$i]) ? $current[$key][$i] : null;
                $count--;
                $i++;
            }
        }
        return $values;
    }

    function save_custom_meta($post_id, $post) {
        if (isset($_POST["gdtt_bbpress_meta"])) {
            $data = $_POST["gdtt_bbpress_meta"];
            wp_verify_nonce($data["nonce"], "gdcptbbpress");

            $post_id = $post->ID;
            $_id = wp_is_post_revision($post);
            $post_id = $_id === false ? $post_id : $_id;

            unset($data["nonce"]);
            update_post_meta($post_id, "_gdtt_bbpress_forum_settings", $data);
        }

        if (isset($_POST["gdtt_box"])) {
            gdtt_update_custom_fields();

            $post_id = $post->ID;
            $_id = wp_is_post_revision($post);
            $post_id = $_id === false ? $post_id : $_id;

            $boxes = $_POST["gdtt_box"];
            foreach ($boxes as $meta_code => $data) {
                wp_verify_nonce($data["__nonce__"], "gdcpttools");

                unset($data["__nonce__"]);
                $meta = $this->m["boxes"][$meta_code];
                $defaults = $this->meta_box_current_values($post_id, $meta->code);

                $done = array();
                foreach ($meta->fields as $f) {
                    $field = $this->m["fields"][$f];
                    if (!isset($done[$f])) { $done[$f] = 0; } else { $done[$f]++; }

                    $new = null;
                    $set = false;
                    $old = $defaults[$f][$done[$f]];
                    switch ($field->type) {
                        default:
                        case gdttCustomType::TEXT:
                        case gdttCustomType::NUMBER:
                        case gdttCustomType::IMAGE:
                        case gdttCustomType::DATE:
                        case gdttCustomType::LINK:
                            $new = trim(strip_tags($data[$f][$done[$f]]));
                            $set = $new !== "";
                            break;
                        case gdttCustomType::RESOLUTION:
                            $new = (array)$data[$f][$done[$f]];
                            $set = $new['x'] != '' || $new['y'] != '';
                            break;
                        case gdttCustomType::TERM:
                            $new = trim(strip_tags($data[$f][$done[$f]]));
                            $set = $new !== "";
                            break;
                        case gdttCustomType::COLOR:
                            $new = trim(strip_tags($data[$f][$done[$f]]));
                            $new = substr(trim(str_replace("#", "", $new)), 0, 6);
                            $set = $new !== "";
                            break;
                        case gdttCustomType::BOOLEAN:
                            $new = isset($data[$f][$done[$f]]) ? 1 : 0;
                            $set = $new == 1;
                            break;
                        case gdttCustomType::LISTING:
                            $new = trim(strip_tags($data[$done[$f]]));
                            $new = gdr2_split_textarea($new);
                            $set = !empty($new);
                            break;
                        case gdttCustomType::HTML:
                        case gdttCustomType::EDITOR:
                            $new = stripslashes(htmlentities($data[$f][$done[$f]], ENT_QUOTES, GDR2_CHARSET));
                            $set = $new !== "";
                            break;
                        case gdttCustomType::SELECT:
                            if ($field->selection == 'select' || $field->selection == 'radio') {
                                $new = trim(strip_tags($data[$f][$done[$f]]));
                                $set = $new !== "";
                            } else {
                                $new = (array)$data[$f][$done[$f]];
                                $set = !empty($new);
                            }
                            break;
                    }

                    $new = apply_filters('gdcpt_value_custom_field_'.$f, $new, $field, $meta);

                    if (is_null($old) && $set) {
                        add_post_meta($post_id, $f, $new);
                    } else {
                        if ($set || (!$set && $this->o["metabox_remove_empty"] == 0)) {
                            update_post_meta($post_id, $f, $new, $old);
                        } else {
                            delete_post_meta($post_id, $f, $old);
                        }
                    }

                    do_action('gdcpt_saved_custom_field_'.$f, $new, $field, $meta);
                }
            }
        }
    }

    function save_post_meta($post_id, $post) {
        if (isset($_POST["cpt_post_noonce"]) && wp_verify_nonce($_POST["cpt_post_noonce"], "gdcpttools")) {
            $tpl = $_POST["cpt_post_templates"];
            if ($tpl == "__default__") {
                delete_post_meta($post->ID, "_wp_post_template");
            } else {
                update_post_meta($post->ID, "_wp_post_template", $tpl);
            }
        }

        if ($post->post_type != "revision" && isset($_POST["cpt_postype_noonce"]) && wp_verify_nonce($_POST["cpt_postype_noonce"], "gdcpttools")) {
            $post_type = $_POST["cpt_post_type"];
            if ($post->post_type != $post_type) {
                global $wpdb;
                $wpdb->update($wpdb->posts, array('post_type' => $post_type), array('ID' => $post_id));
            }
        }
    }

    function unset_cache($type, $name) {
        if (isset($this->cf[$type][$name])) {
            unset($this->cf[$type][$name]);
        }
        update_option("gd-taxonomy-tools-cache", $this->cf);
    }

    function register_custom_posts() {
        global $wp_rewrite;

        $permalink_index = GDTAXTOOLS_WPV < 34 ? 0 : 'struct';
        foreach ($this->p as $cpt) {
            if (!isset($cpt["active"]) || (isset($cpt["active"]) && $cpt["active"] == 1)) {
                if ($this->_c() && isset($this->cf["cpt"][$cpt["name"]]) && !empty($this->cf["cpt"][$cpt["name"]])) {
                    $options = $this->cf["cpt"][$cpt["name"]];
                } else {
                    $options = gdtt_generate_custom_posts_options($cpt);
                    $options = apply_filters("gdcpt_register_post_type", $options, $cpt["name"]);
                    $options = apply_filters("gdcpt_register_post_type_".$cpt["name"], $options);

                    if ($this->_c()) {
                        $this->cf["cpt"][$cpt["name"]] = $options;
                        $this->cache_modded = true;
                    }
                }

                $this->active["cpt"][] = $cpt["name"];
                register_post_type($cpt["name"], $options);
                $wp_rewrite->add_rewrite_tag("%".$cpt["name"]."_id%", "([0-9]+)", "cpt_postid_".$cpt["name"]."=");

                if (isset($cpt["permalinks_active"]) && $cpt["permalinks_active"] == "yes") {
                    $wp_rewrite->extra_permastructs[$cpt["name"]][$permalink_index] = $cpt["permalinks_structure"];
                }

                if (isset($cpt["icon"]) && !is_null($cpt["icon"]) && !empty($cpt["icon"]) && $cpt["menu_icon"] == "") {
                    $this->menu_items[$cpt["name"]] = $cpt["icon"];
                }
            }
        }
    }

    function register_for_object_types() {
        foreach ($this->t as $tax) {
            if (isset($tax["active"])) {
                $domains = explode(",", $tax["domain"]);
                foreach ($domains as $post_type) {
                    register_taxonomy_for_object_type($tax["name"], $post_type);
                }
            }
        }
        foreach ($this->p as $cpt) {
            if (!isset($cpt["active"]) || (isset($cpt["active"]) && $cpt["active"] == 1)) {
                if (is_array($cpt["taxonomies"])) {
                    foreach ($cpt["taxonomies"] as $tax) {
                        register_taxonomy_for_object_type($tax, $cpt["name"]);
                    }
                }
            }
        }
    }

    function register_custom_taxonomies() {
        foreach ($this->t as $tax) {
            if (isset($tax["active"])) {
                $domains = explode(",", $tax["domain"]);
                if ($this->_c() && isset($this->cf["tax"][$tax["name"]]) && !empty($this->cf["tax"][$tax["name"]])) {
                    $options = $this->cf["tax"][$tax["name"]];
                } else {
                    $options = gdtt_generate_custom_taxonomies_options($tax);
                    $options = apply_filters("gdcpt_register_taxonomy", $options, $tax["name"]);
                    $options = apply_filters("gdcpt_register_taxonomy_".$tax["name"], $options);
                    if ($this->_c()) {
                        $this->cf["tax"][$tax["name"]] = $options;
                        $this->cache_modded = true;
                    }
                }
                $this->active["tax"][] = $tax["name"];
                register_taxonomy($tax["name"], $domains, $options);
            }
        }
    }

    function apply_override_posttypes_taxonomies($post_type, $taxonomies) {
        foreach ($taxonomies as $taxonomy) {
            register_taxonomy_for_object_type($taxonomy, $post_type);
        }
    }

    function apply_override_posttypes_features($post_type, $features) {
        $all = array_keys($this->post_features);

        foreach ($all as $feat) {
            if (in_array($feat, $features, true)) {
                add_post_type_support($post_type, $feat);
            } else {
                remove_post_type_support($post_type, $feat);
            }
        }
    }

    function override_post_types() {
        foreach ($this->nn_p["status"] as $cpt_name => $status) {
            if ($status != "no" && post_type_exists($cpt_name)) {
                $cpt = $this->nn_p[$status][$cpt_name];

                if ($status == "full") {
                    $options = gdtt_generate_custom_posts_options($cpt);
                    $options["_builtin"] = $cpt["name"] == "post" || $cpt["name"] == "page" || $cpt["name"] == "attachment";
                    register_post_type($cpt["name"], $options);
                } else if ($status == "simple") {
                    $this->apply_override_posttypes_features($cpt_name, $cpt["supports"]);
                    $this->apply_override_posttypes_taxonomies($cpt_name, $cpt["taxonomies"]);
                }
            }
        }
    }

    function override_taxonomies() {
        foreach ($this->nn_t["status"] as $tax_name => $status) {
            if ($status != "no" && taxonomy_exists($tax_name)) {
                $tax = $this->nn_t[$status][$tax_name];
                $domains = explode(",", $tax["domain"]);

                if ($status == "full") {
                    $options = gdtt_generate_custom_taxonomies_options($tax);
                    $options["_builtin"] = $tax["name"] == "category" || $tax["name"] == "post_tag";

                    register_taxonomy($tax["name"], $domains, $options);
                } else if ($status == "simple") {
                    global $wp_taxonomies;

                    if (isset($wp_taxonomies[$tax_name])) {
                        $wp_taxonomies[$tax_name]->object_type = $domains;
                    }
                }
            }
        }
    }

    function list_names_tax() {
        $found = array();
        foreach ($this->t as $tax) {
            $found[] = $tax["name"];
        }
        return $found;
    }

    function list_names_cpt() {
        $found = array();
        foreach ($this->p as $cpt) {
            $found[] = $cpt["name"];
        }
        return $found;
    }

    function prepare_inactive_cpt() {
        $found = array();
        foreach ($this->p as $cpt) {
            if (isset($cpt["active"]) && $cpt["active"] == 0) {
                $found[$cpt["name"]] = new gdtt_CustomPost($cpt);
            }
        }
        return $found;
    }

    function prepare_inactive_tax() {
        $found = array();
        foreach ($this->t as $tax) {
            if (!isset($tax["active"])) {
                $found[$tax["name"]] = new gdtt_Taxonomy($tax);
            }
        }
        return $found;
    }

    function init() {
        $this->l = get_locale();
        if(!empty($this->l)) {
            $moFile = GDTAXTOOLS_PATH."languages/gd-taxonomies-tools-".$this->l.".mo";
            if (@file_exists($moFile) && is_readable($moFile)) load_textdomain("gd-taxonomies-tools", $moFile);
        }

        if ($this->o["force_rules_flush"] == 1) {
            global $wp_rewrite;
            $wp_rewrite->flush_rules();

            if (function_exists('gdsr_rebuild_ratings')) {
                gdsr_rebuild_ratings();
            }

            $this->o["force_rules_flush"] = 0;
            update_option("gd-taxonomy-tools", $this->o);
        }
    }

    function widgets_init() {
        register_widget("gdttTermsCloud");
        register_widget("gdttTermsList");
        register_widget("gdttPostTypesList");
    }
}

?>