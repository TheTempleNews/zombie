/*jslint regexp: true, nomen: true, undef: true, sloppy: true, eqeq: true, vars: true, white: true, plusplus: true, maxerr: 50, indent: 4 */

jQuery(document).ready(function() {
    jQuery("a").each(function() {
        var href = jQuery(this).attr('href');
        var is_gdtt = href.indexOf('gdtt_term');
        if (is_gdtt == -1 && href != "#") {
            var qs = href.indexOf('?') == -1 ? "?" : "&";
            href+= qs + 'gdtt_term=' + gdttMedia.term;
            href+= '&gdtt_tax=' + gdttMedia.taxonomy;
            jQuery(this).attr('href', href);
        }
    });

    jQuery(".gtc-attach").live("click", function() {
        var image_id = jQuery(this).attr("rel");

        jQuery.ajax({
            url: ajaxurl,
            type: "POST",
            dataType: 'json',
            cache: false,
            data: {'action': 'gd_cpt_attach_image',
                   '_ajax_nonce': gdttMedia.nonce,
                   'image_id': image_id,
                   'term_id': gdttMedia.term,
                   'taxonomy': gdttMedia.taxonomy
            },
            success: function(json) {
                if (json.status == 'ok') {
                    self.parent.gdtt_attach_image(gdttMedia.term, json.image, json.preview);
                }
                self.parent.tb_remove();
            }
        });
    });

    jQuery("td.savesend").remove();
});
