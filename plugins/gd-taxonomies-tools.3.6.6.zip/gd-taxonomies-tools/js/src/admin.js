/*jslint regexp: true, nomen: true, undef: true, sloppy: true, eqeq: true, vars: true, white: true, plusplus: true, maxerr: 50, indent: 4 */

function ucfirst(str) { 
    return str.substr(0, 1).toUpperCase() + str.substr(1); 
}

var gdCPTAdmin = {
    tmp: {
        settings_toggle: [],
        form_mediaupload_function: null,
        custom_field_editor: "new",
        custom_field_to_delete: null,
        custom_fields_count: 0,
        custom_fields: { },
        meta_box_editor: "new",
        meta_box_to_delete: null,
        meta_boxes_count: 0,
        meta_boxes: { },
        post_types: { },
        post_types_map: { }
    },
    tpl: {
        cfe_row: "", mbe_row: ""
    },
    tpl_render: function(tpl, obj) {
        var result = tpl;
        var i;
        jQuery.each(obj, function(idx, val){
            var code = "%" + idx.toUpperCase() + "%";
            if (idx == "required") {
                val = val ? gdCPTTools.yes : gdCPTTools.no;
            }
            for (i = 0; i < 32; i++) {result = result.replace(code, val);}
        });
        return result;
    },
    caps: {
        list: {
            cpt: ["edit_post", "edit_posts", "edit_private_posts", "edit_published_posts", "edit_others_posts", "publish_posts", "read_post", "read_private_posts", "delete_post", "delete_posts", "delete_private_posts", "delete_published_posts", "delete_others_posts"],
            tax: ["manage_terms", "edit_terms", "delete_terms", "assign_terms"]
        },
        init: function() {
            jQuery("#cpt_show").click(function(){gdCPTAdmin.caps.load("cpt");});
            jQuery("#tax_show").click(function(){gdCPTAdmin.caps.load("tax");});

            jQuery("#gdcpt-caps-form-cpt, #gdcpt-caps-form-tax").submit(function() {
                jQuery(this).ajaxSubmit({
                    beforeSubmit: function() {jQuery("#gdr2dialogsave").dialog("open");},
                    success: function(json) {
                        cpt_rules = json;
                        jQuery("#gdr2dialogsave").dialog("close");
                    },
                    dataType: "json",
                    url: "admin-ajax.php?action=gd_cpt_save_caps&_ajax_nonce=" + gdCPTTools.nonce
                });
                return false;
            });
        },
        load: function(what) {
            jQuery("#editor-" + what).show().find(".gdr2-control-bool input").removeAttr('checked');
            var i;
            var rule = jQuery("#" + what + "_rule").val();
            var role = jQuery("#" + what + "_role").val();
            jQuery("#" + what + "_info_name").val(rule);
            jQuery("#" + what + "_info_role").val(role);

            if (cpt_rules[what][rule].active[role]) {
                jQuery("#" + what + "_info_active").attr("checked", "checked");
            }

            for (i = 0; i < gdCPTAdmin.caps.list[what].length; i++) {
                var desc = what == "cpt" ? gdCPTAdmin.caps.list[what][i].replace(/post/, rule) :
                                           gdCPTAdmin.caps.list[what][i].replace(/terms/, rule);
                jQuery("#gdr2-el-" + what + "_caps_" + gdCPTAdmin.caps.list[what][i] + " span").attr("qtip-content", desc);
                if (jQuery.inArray(gdCPTAdmin.caps.list[what][i], cpt_rules[what][rule].caps[role]) > -1) {
                    jQuery("#" + what + "_caps_" + gdCPTAdmin.caps.list[what][i]).attr("checked", "checked");
                }
            }
        }
    },
    editor: {
        update_fields_select: function() {
            jQuery("#gdtt-metabasic select").removeOption(/./);
            jQuery("#gdtt-metabasic select").addOption("__none__", gdCPTTools.txt_select_field);

            jQuery.each(gdCPTAdmin.tmp.custom_fields, function(idx, val){
                jQuery("#gdtt-metabasic select").addOption(idx, val.name);
            });
        },
        load_meta_box: function(code) {
            jQuery("#gdtt-mbe-code").attr("readonly", true).val(code);
            jQuery("#gdtt-mbe-name").val(gdCPTAdmin.tmp.meta_boxes[code].name);
            jQuery("#gdtt-mbe-location").val(gdCPTAdmin.tmp.meta_boxes[code].location);
            jQuery("#gdtt-mbe-description").val(gdCPTAdmin.tmp.meta_boxes[code].description);

            var i;
            var fields = gdCPTAdmin.tmp.meta_boxes[code].fields;
            jQuery("#gdtt-metafields").html("");
            for (i = 0; i < fields.length; i++) {
                var item = jQuery("#gdtt-metabasic li").clone().show();
                item.find("select").val(fields[i]);
                jQuery("#gdtt-metafields").append(item);
            }
            jQuery("#gdtt-metafields li:first .gdr2-metafield-buttons div:last").hide();
            gdCPTAdmin.editor.fields_dnd();
        },
        init: function() {
            jQuery("#gdttcfdelete").next().append('<div id="gdtt-cfd-infopane" class="ui-dialog-infopane"></div>');
            jQuery("#gdttmbdelete").next().append('<div id="gdtt-mbd-infopane" class="ui-dialog-infopane"></div>');
            jQuery("#gdttmbptypes").next().append('<div id="gdtt-mbp-infopane" class="ui-dialog-infopane"></div>');
            jQuery("#gdttcfedit").next().append('<div id="gdtt-cfe-infopane" class="ui-dialog-infopane"></div>');
            jQuery("#gdttmbedit").next().append('<div id="gdtt-mbe-infopane" class="ui-dialog-infopane"></div>');

            jQuery(".gdtt-mbo-edit").live("click", function(){
                gdCPTAdmin.tmp.meta_box_editor = "edit";
                var to_edit = jQuery(this).attr("href").substr(1);

                gdCPTAdmin.editor.load_meta_box(to_edit);

                jQuery("#gdttmbedit").dialog("open");
                return false;
            });

            jQuery("#gdtt-cfe-selmethod").live("change", function() {
                var method = jQuery(this).val();

                jQuery(".gdtt-select-list").hide();
                jQuery(".gdtt-select-" + method).show();
            });

            jQuery(".gdtt-cfo-copy, .gdtt-cfo-edit").live("click", function() {
                var copy = jQuery(this).hasClass("gdtt-cfo-copy");
                gdCPTAdmin.tmp.custom_field_editor = copy ? "new" : "edit";
                var to_edit = jQuery(this).attr("href").substr(1);

                jQuery("#gdtt-cfe-code").attr("readonly", !copy).val(to_edit);

                jQuery("#gdtt-cfe-type").val(gdCPTAdmin.tmp.custom_fields[to_edit].type);
                jQuery("#gdtt-cfe-name").val(gdCPTAdmin.tmp.custom_fields[to_edit].name);
                jQuery("#gdtt-cfe-selection").val(gdCPTAdmin.tmp.custom_fields[to_edit].selection);
                jQuery("#gdtt-cfe-selmethod").val(gdCPTAdmin.tmp.custom_fields[to_edit].selmethod);
                jQuery("#gdtt-cfe-description").val(gdCPTAdmin.tmp.custom_fields[to_edit].description);
                jQuery("#gdtt-cfe-function").val(gdCPTAdmin.tmp.custom_fields[to_edit].fnc_name);

                jQuery(".gdtt-element-field").hide();
                if (gdCPTAdmin.tmp.custom_fields[to_edit].type == "select") {
                    jQuery(".gdtt-element-values").show();
                    jQuery("#gdtt-cfe-selmethod").trigger("change");
                }

                if (gdCPTAdmin.tmp.custom_fields[to_edit].type == "term") {
                    jQuery(".gdtt-element-taxonomy").show();
                }

                if (gdCPTAdmin.tmp.custom_fields[to_edit].type == "term") {
                    jQuery("#gdtt-cfe-taxname").val(gdCPTAdmin.tmp.custom_fields[to_edit].values);
                    jQuery("#gdtt-cfe-values").val("");
                } else {
                    jQuery("#gdtt-cfe-values").val(gdCPTAdmin.tmp.custom_fields[to_edit].values.join("\n"));
                    jQuery("#gdtt-cfe-assoc-values").val(gdCPTAdmin.tmp.custom_fields[to_edit].assoc_values.join("\n"));
                }

                jQuery("#gdtt-cfe-required").removeAttr("checked");

                if (gdCPTAdmin.tmp.custom_fields[to_edit].required) {
                    jQuery("#gdtt-cfe-required").attr("checked", "checked");
                }

                jQuery("#gdttcfedit").dialog("open");
                return false;
            });
            jQuery(".gdtt-mbo-postypes").live("click", function(){
                gdCPTAdmin.tmp.meta_box_to_delete = jQuery(this).attr("href").substr(1);
                jQuery("#gdtt-ptypesfields").html("");

                if (gdCPTAdmin.tmp.post_types_map.hasOwnProperty(gdCPTAdmin.tmp.meta_box_to_delete) && gdCPTAdmin.tmp.post_types_map[gdCPTAdmin.tmp.meta_box_to_delete].length == 0) {
                    jQuery("#gdtt-ptypesfields").append(jQuery("#gdtt-ptypesbasic li").clone());
                } else {
                    jQuery.each(gdCPTAdmin.tmp.post_types_map[gdCPTAdmin.tmp.meta_box_to_delete], function(idx, val){
                        var row = jQuery("#gdtt-ptypesbasic li").clone();
                        row.find("select").val(val);
                        jQuery("#gdtt-ptypesfields").append(row);
                    });
                }

                jQuery("#gdttmbptypes").dialog("open");
                return false;
            });
            jQuery("#gdtt-ptypesfields li span.ui-icon-minus").live("click", function(){
                jQuery(this).parent().parent().parent().fadeOut("slow", function(){jQuery(this).remove();});
            });
            jQuery("#gdtt-ptypesfields li span.ui-icon-plus").live("click", function(){
                var item = jQuery("#gdtt-ptypesbasic li").clone().hide().fadeIn("slow");
                jQuery(this).parent().parent().parent().after(item);
            });
            jQuery(".gdtt-cfo-delete").live("click", function(){
                gdCPTAdmin.tmp.custom_field_to_delete = jQuery(this).attr("href").substr(1);
                jQuery("#gdttcfdelete").dialog("open");
                return false;
            });
            jQuery(".gdtt-mbo-delete").live("click", function(){
                gdCPTAdmin.tmp.meta_box_to_delete = jQuery(this).attr("href").substr(1);
                jQuery("#gdttmbdelete").dialog("open");
                return false;
            });
            jQuery("#gdtt-metafields li span.ui-icon-minus").live("click", function(){
                jQuery(this).parent().parent().parent().fadeOut("slow", function(){jQuery(this).remove();});
                gdCPTAdmin.editor.fields_dnd();
            });
            jQuery("#gdtt-metafields li span.ui-icon-plus").live("click", function(){
                var item = jQuery("#gdtt-metabasic li").clone().hide().fadeIn("slow");
                jQuery(this).parent().parent().parent().after(item);
                gdCPTAdmin.editor.fields_dnd();
            });
            jQuery("#gdtt-mbe-addnew").click(function(){
                gdCPTAdmin.tmp.meta_box_editor = "new";

                jQuery("#gdtt-mbe-code").attr("readonly", false).val("");
                jQuery("#gdtt-mbe-name").val("");
                jQuery("#gdtt-mbe-location").val("");
                jQuery("#gdtt-mbe-description").val("");
                jQuery("#gdtt-metafields").html("").append(jQuery("#gdtt-metabasic li").clone());
                jQuery("#gdtt-metafields li:first .gdr2-metafield-buttons div:last").hide();

                jQuery("#gdttmbedit").dialog("open");
                return false;
            });
            jQuery("#gdtt-cfe-addnew").click(function(){
                gdCPTAdmin.tmp.custom_field_editor = "new";

                jQuery(".gdtt-element-values").hide();
                jQuery("#gdtt-cfe-type").val("text");
                jQuery("#gdtt-cfe-code").attr("readonly", false).val("");
                jQuery("#gdtt-cfe-name").val("");
                jQuery("#gdtt-cfe-selection").val("select");
                jQuery("#gdtt-cfe-selmethod").val("normal");
                jQuery("#gdtt-cfe-description").val("");
                jQuery("#gdtt-cfe-taxname").val("");
                jQuery("#gdtt-cfe-values").val("");
                jQuery("#gdtt-cfe-assoc-values").val("");
                jQuery("#gdtt-cfe-function").val("__none__");
                jQuery("#gdtt-cfe-required").removeAttr("checked");

                jQuery("#gdttcfedit").dialog("open");
                return false;
            });
            jQuery("#gdtt-cfe-type").change(function(){
                var field = jQuery(this).val();
                jQuery(".gdtt-element-field").hide();
                if (field == "select" || field == "radio" || field == "checkbox") {jQuery(".gdtt-element-values").show();}
                if (field == "term") {jQuery(".gdtt-element-taxonomy").show();}
            });
        },
        fields_dnd: function() {
            jQuery("#gdtt-metafields").sortable({placeholder: "ui-state-highlight", stop: function(event, ui){
                jQuery("#gdtt-metafields li .gdr2-metafield-buttons div").show();
                jQuery("#gdtt-metafields li:first .gdr2-metafield-buttons div:last").hide();
            }});
            jQuery("#gdtt-metafields").disableSelection();
        },
        show_info: function(id, info) {
            jQuery("#" + id).fadeIn().html(info);
        },
        hide_info: function(id) {
            jQuery("#" + id).fadeOut("slow").html("");
        },
        attach_posttypes: function() {
            gdCPTAdmin.editor.hide_info("gdtt-mbp-infopane");
            var metas = {code: gdCPTAdmin.tmp.meta_box_to_delete, post_types: []};
            jQuery("#gdtt-ptypesfields li select").each(function(idx, el){
                var value = jQuery(this).val();
                if (value != "__none__") {metas.post_types[metas.post_types.length] = value;}
            });
            jQuery.ajax({
                success: function(json) {
                    var ptypes = [];
                    jQuery.each(json.map, function(idx, value){
                        var p = gdCPTAdmin.tmp.post_types[value];
                        ptypes[ptypes.length] = p + " (<strong>" + value + "</strong>)";
                    });
                    jQuery(".gdtt-mbrow-" + gdCPTAdmin.tmp.meta_box_to_delete + " .gdtt-post-types").html(ptypes.join("<br/>"));
                    jQuery("#gdttmbptypes").dialog("close");
                }, dataType: "json", data: metas, type: "POST",
                url: "admin-ajax.php?action=gd_cpt_meta_attach_metabox&_ajax_nonce=" + gdCPTTools.nonce
            });
        },
        add_metabox: function() {
            gdCPTAdmin.editor.hide_info("gdtt-mbe-infopane");
            var box = {method:  gdCPTAdmin.tmp.meta_box_editor,
                       code: jQuery("#gdtt-mbe-code").val().trim(),
                       name: jQuery("#gdtt-mbe-name").val().trim(),
                       location: jQuery("#gdtt-mbe-location").val().trim(),
                       description: jQuery("#gdtt-mbe-description").val().trim(),
                       fields: []};
            jQuery("#gdtt-metafields li select").each(function(idx, el){
                var value = jQuery(this).val();
                if (value != "__none__") {box.fields[box.fields.length] = value;}
            });
            if (box.code === "" || box.name === "" || box.fields.length == 0) {
                gdCPTAdmin.editor.show_info("gdtt-mbe-infopane", gdCPTTools.txt_editor_box_missing);
            } else {
                jQuery.ajax({
                    success: function(json) {
                        var first = gdCPTAdmin.tmp.meta_boxes_count == 0;
                        gdCPTAdmin.tmp.meta_boxes[json.box.code] = jQuery.extend(true, {}, json.box);
                        var fields = [];
                        var ptypes = [];
                        jQuery.each(gdCPTAdmin.tmp.meta_boxes[json.box.code].fields, function(idx, value){
                            var f = gdCPTAdmin.tmp.custom_fields[value];
                            fields[fields.length] = f.name + " (<strong>" + f.code + "</strong>: " + ucfirst(f.type) + ")";
                        });
                        jQuery.each(json.map, function(idx, value){
                            var p = gdCPTAdmin.tmp.post_types[value];
                            ptypes[ptypes.length] = p + " (<strong>" + value + "</strong>)";
                        });
                        json.box.post_types = ptypes.join("<br/>");
                        json.box.fields = fields.join("<br/>");
                        var row = gdCPTAdmin.tpl_render(gdCPTAdmin.tpl.mbe_row, json.box);
                        if (gdCPTAdmin.tmp.meta_box_editor == "new") {
                            if (first) {jQuery("#list-boxes").html("");}
                            jQuery("#list-boxes").append(row);
                            gdCPTAdmin.tmp.meta_boxes_count++;
                        } else {
                            jQuery(".gdtt-mbrow-" + json.box.code).replaceWith(row);
                        }
                        jQuery("#gdttmbedit").dialog("close");
                    }, dataType: "json", data: box, type: "POST",
                    url: "admin-ajax.php?action=gd_cpt_meta_add_metabox&_ajax_nonce=" + gdCPTTools.nonce
                });
            }
        },
        delete_metabox: function() {
            var del_data = {code: gdCPTAdmin.tmp.meta_box_to_delete,
                            definition: jQuery('#gdtt-mbe-del-definition').is(":checked") ? "1" : "0"};
            if (del_data.definition == "1") {
                gdCPTAdmin.editor.hide_info("gdtt-mbd-infopane");
                jQuery.ajax({
                    success: function(json) {
                        if (json.del_row == "yes") {
                            gdCPTAdmin.tmp.meta_boxes_count--;
                            jQuery(".gdtt-mbrow-" + gdCPTAdmin.tmp.meta_box_to_delete).fadeOut("slow").remove();
                        }
                        jQuery("#gdttmbdelete").dialog("close");
                    }, dataType: 'json', data: del_data, type: "POST",
                    url: 'admin-ajax.php?action=gd_cpt_meta_delete_metabox&_ajax_nonce=' + gdCPTTools.nonce
                });
            } else {
                gdCPTAdmin.editor.show_info("gdtt-mbd-infopane", gdCPTTools.txt_editor_nothing);
            }
        },
        delete_field: function() {
            var del_data = {code: gdCPTAdmin.tmp.custom_field_to_delete,
                            definition: jQuery('#gdtt-cfe-del-definition').is(":checked") ? "1" : "0", 
                            data: jQuery('#gdtt-cfe-del-postmeta').is(":checked") ? "1" : "0"};
            if (del_data.data == "1" || del_data.definition == "1") {
                gdCPTAdmin.editor.hide_info("gdtt-cfd-infopane");
                jQuery.ajax({
                    success: function(json) {
                        if (json.del_row == "yes") {
                            gdCPTAdmin.tmp.custom_fields_count--;
                            delete gdCPTAdmin.tmp.custom_fields[gdCPTAdmin.tmp.custom_field_to_delete];
                            gdCPTAdmin.editor.update_fields_select();
                            jQuery(".gdtt-cfrow-" + gdCPTAdmin.tmp.custom_field_to_delete).fadeOut("slow").remove();
                        }
                        jQuery("#gdttcfdelete").dialog("close");
                    }, dataType: 'json', data: del_data, type: "POST",
                    url: "admin-ajax.php?action=gd_cpt_meta_delete_field&_ajax_nonce=" + gdCPTTools.nonce
                });
            } else {
                gdCPTAdmin.editor.show_info("gdtt-cfd-infopane", gdCPTTools.txt_editor_nothing);
            }
        },
        add_field: function() {
            gdCPTAdmin.editor.hide_info("gdtt-cfe-infopane");
            var field = {method:  gdCPTAdmin.tmp.custom_field_editor,
                         type: jQuery("#gdtt-cfe-type").val().trim(),
                         code: jQuery("#gdtt-cfe-code").val().trim(),
                         name: jQuery("#gdtt-cfe-name").val().trim(),
                         tax_name: jQuery("#gdtt-cfe-taxname").val().trim(),
                         selection: jQuery("#gdtt-cfe-selection").val().trim(),
                         selmethod: jQuery("#gdtt-cfe-selmethod").val().trim(),
                         fnc_name: jQuery("#gdtt-cfe-function").val().trim(),
                         description: jQuery("#gdtt-cfe-description").val().trim(),
                         values: jQuery("#gdtt-cfe-values").val().trim(),
                         assoc_values: jQuery("#gdtt-cfe-assoc-values").val().trim(),
                         required: jQuery("#gdtt-cfe-required").is(":checked")};
            if (field.code === '' || field.name === '') {
                gdCPTAdmin.editor.show_info("gdtt-cfe-infopane", gdCPTTools.txt_editor_field_missing);
            } else {
                jQuery.ajax({
                    success: function(json) {
                        jQuery("#gdtt-cfe-type").val(json.field.type);
                        jQuery("#gdtt-cfe-code").val(json.field.code);
                        jQuery("#gdtt-cfe-name").val(json.field.name);
                        jQuery("#gdtt-cfe-function").val(json.field.fnc_name);
                        jQuery("#gdtt-cfe-description").val(json.field.description);
                        if (json.field.type != 'term') {
                            jQuery("#gdtt-cfe-values").val(json.field.values.join("\n"));
                        } else {
                            jQuery("#gdtt-cfe-taxname").val(json.field.values);
                        }
                        jQuery("#gdtt-cfe-required").removeAttr("checked");
                        if (json.field.required) {
                            jQuery("#gdtt-cfe-required").attr("checked", "checked");
                        }

                        if (json.status == "error") {
                            gdCPTAdmin.editor.show_info("gdtt-cfe-infopane", json.error);
                        } else {
                            var first = gdCPTAdmin.tmp.custom_fields_count == 0;
                            gdCPTAdmin.tmp.custom_fields[json.field.code] = jQuery.extend(true, {}, json.field);
                            gdCPTAdmin.editor.update_fields_select();
                            if (json.field.type == "boolean") {
                                json.field.values = "true<br/>false";
                            } else if (json.field.type == "function") {
                                json.field.values = "$" + json.field.fnc_name + "()";
                            } else if (json.field.type == "select" || json.field.type == "radio" || json.field.type == "checkbox") {
                                json.field.values = json.field.values.join("<br/>");
                            } else if (json.field.type != "term") { 
                                json.field.values = "/";
                            }
                            json.field.type = ucfirst(json.field.type);
                            var row = gdCPTAdmin.tpl_render(gdCPTAdmin.tpl.cfe_row, json.field);
                            if (gdCPTAdmin.tmp.custom_field_editor == "new") {
                                if (first) {jQuery("#list-fields").html("");}
                                jQuery("#list-fields").append(row);
                                gdCPTAdmin.tmp.custom_fields_count++;
                            } else {
                                jQuery(".gdtt-cfrow-" + json.field.code).replaceWith(row);
                            }
                            jQuery("#gdttcfedit").dialog("close");
                        }
                    }, dataType: "json", data: field, type: "POST",
                    url: "admin-ajax.php?action=gd_cpt_meta_add_field&_ajax_nonce=" + gdCPTTools.nonce
                });
            }
        }
    },
    save_cpt_full: function(cpt, id, name, dialog) {
        var url = jQuery("#" + dialog + " .edit-again").attr("href") + cpt;
        if (cpt === 1) {url+= "&pid=" + id;} else {url+= "&pname=" + name;}
        jQuery("#" + dialog + " .edit-again").attr("href", url);
        jQuery("#gdcpt-settings-form").submit(function() {
            gdCPTAdmin.ajax(dialog);
            return false;
        });
    },
    save_cpt_simple: function(name, dialog) {
        var url = jQuery("#" + dialog + " .edit-again").attr("href");
        jQuery("#" + dialog + " .edit-again").attr("href", url + name);
        jQuery("#gdcpt-settings-form").submit(function() {
            gdCPTAdmin.ajax(dialog);
            return false;
        });
    },
    save_tax_full: function(cpt, id, name, dialog) {
        var url = jQuery("#" + dialog + " .edit-again").attr("href") + cpt;
        if (cpt === 1) {url+= "&tid=" + id;} else {url+= "&tname=" + name;}
        jQuery("#" + dialog + " .edit-again").attr("href", url);
        jQuery("#gdcpt-settings-form").submit(function() {
            gdCPTAdmin.ajax(dialog);
            return false;
        });
    },
    save_tax_simple: function(name, dialog) {
        var url = jQuery("#" + dialog + " .edit-again").attr("href");
        jQuery("#" + dialog + " .edit-again").attr("href", url + name);
        jQuery("#gdcpt-settings-form").submit(function() {
            gdCPTAdmin.ajax(dialog);
            return false;
        });
    },
    ajax: function(dialog) {
        jQuery(".gdr2-element").removeClass("gdr2-error");
        jQuery(".gdr2-panel .gdr2-group h2").css("backgroundColor", "#EEEEEE").css("color", "#222222");
        jQuery(".gdr2-panel .gdr2-group h2 span").hide();

        jQuery("#gdcpt-settings-form").ajaxSubmit({
            beforeSubmit: function() {jQuery("#gdr2dialogsave").dialog("open");},
            success: function(json) {
                jQuery("#gdr2dialogsave").dialog("close");
                if (json.status == "ok") {
                    jQuery("#" + dialog).dialog("open");
                } else {
                    var i;
                    for (i = 0; i < json.groups.length; i++) {
                        jQuery(json.groups[i][0] + " h2").css("backgroundColor", "#FFDADA").css("color", "#C71200");
                        jQuery(json.groups[i][0] + " h2 span").show();
                    }
                    for (i = 0; i < json.errors.length; i++) {
                        jQuery(".gdr2-element-" + json.errors[i][0])
                            .addClass("gdr2-error")
                            .find(".gdr2-description-for-error span")
                            .attr("qtip-content", json.errors[i][1]);
                    }
                    jQuery("#gdr2dialog_error").dialog("open");
                }
            },
            dataType: "json",
            url: "admin-ajax.php?action=gd_cpt_save_settings&_ajax_nonce=" + gdCPTTools.nonce
        });
    },
    init_confirm: function() {
        jQuery("#gdr2dialog_confirm").dialog({bgiframe: true, modal: true, 
               autoResize:true, autoOpen: false, resizable: false, width: 400});

        jQuery(".gdr2_confirm_alert").click(function(e) {
            e.preventDefault();
            var targetUrl = jQuery(this).attr("href");

            jQuery("#gdr2dialog_confirm").dialog({
                buttons: {"OK": function() {window.location.href = targetUrl;},
                           "Cancel": function() {jQuery(this).dialog("close");}}
            });

            jQuery("#gdr2dialog_confirm").dialog("open");
        });
    },
    init: function() {
        jQuery("#tabs").tabs();
        jQuery("input.pressbutton, a.pressbutton").button();
        jQuery(".gdr2-group button.pressbutton").button({
            icons: {
                primary: "ui-icon-disk"
            },
            text: false
        }).click(function(){
            jQuery(this).closest('form').submit();
            return false;
        });
        jQuery(".gdr2-group button.linkbutton").button({
            icons: {
                primary: "ui-icon-extlink"
            },
            text: false
        }).click(function(){
            window.open(jQuery(this).attr('href'), '_blank');
            return false;
        });

        jQuery(".widefat tbody tr").hover(
            function(){jQuery(this).addClass("gdr2-highlight-row");}, 
            function(){jQuery(this).removeClass("gdr2-highlight-row");}
        );

        jQuery("#gdr2dialogsave").dialog({
            bgiframe: true, autoResize:true, autoOpen: false, minHeight: 60, 
            width: 300, modal: true, closeOnEscape: false, resizable: false
        });

        jQuery("#gdr2dialog_cpt_simple, #gdr2dialog_cpt_full, #gdr2dialog_tax_simple, #gdr2dialog_tax_full").dialog({
            bgiframe: true, autoResize:true, autoOpen: false, minHeight: 100, 
            width: 450, modal: true, closeOnEscape: false, resizable: false
        });

        jQuery("#gdr2dialog_error").dialog({
            bgiframe: true, autoResize:true, autoOpen: false, minHeight: 100, 
            width: 300, modal: true, closeOnEscape: false, resizable: false,
            buttons: {"OK": function() {jQuery(this).dialog("close");}}
        });

        jQuery(".gdr2-media-open span").click(function() {
            var gdr2_id = jQuery(this).attr("gdr2-id");
            gdCPTAdmin.tmp.form_mediaupload_function = window.send_to_editor;
            tb_show(gdCPTTools.select_title, "media-upload.php?type=image&amp;TB_iframe=true");
            window.send_to_editor = function(html) {
                var imgurl = jQuery(html).attr("href");
                jQuery("#" + gdr2_id).val(imgurl);
                tb_remove();
                window.send_to_editor = gdCPTAdmin.tmp.form_mediaupload_function;
            };
        });
        jQuery(".gdr2-media-preview span").click(function() {
            var gdr2_id = jQuery(this).attr("gdr2-id");
            var url = jQuery("#" + gdr2_id).val().trim();
            if (url !== "") {
                tb_show(gdCPTTools.preview_title, gdCPTTools.preview_url + "?img=" + encodeURIComponent(url) + "&TB_iframe=true");
            }
        });
    },
    init_toggler: function() {
        jQuery(".gdr2-group-elements-toggle").click(function(){
            var opened = jQuery(this).hasClass("toggle-opened");
            var id = jQuery(this).attr("id").substr(12);
            if (opened) {
                gdCPTAdmin.toggler.groupClose(id);
            } else {
                gdCPTAdmin.toggler.groupOpen(id, true);
            }
            return false;
        });

        var cookie_settings = getCookie(gdCPTTools.cookie_name);
        if (cookie_settings !== null) {
            gdCPTAdmin.tmp.settings_toggle = cookie_settings.split("|");
            var ic;
            for (ic = 0; ic < gdCPTAdmin.tmp.settings_toggle.length; ic++) {
                gdCPTAdmin.toggler.groupOpen(gdCPTAdmin.tmp.settings_toggle[ic], false);
            }
        }
    },
    init_qtip: function() {
        var qtip_info = {
             content: {
                 text: function(api) {return jQuery(this).attr("title");}
             },
             position: {
                 my: "bottom center", at: "top center", adjust: {y: -5}
             },
             style: {
                 widget: true, classes: "ui-tooltip-shadow ui-tooltip-blue"
             }
        };
        var qtip_d4p = {
            content: {
                 title:function(api) {return jQuery(this).attr("qtip-title");},
                 text: function(api) {return jQuery(this).attr("qtip-content");}
             },
             position: {
                 my: "left center", at: "right center", adjust: {x: 10}
             },
             style: {
                 widget: true, classes: "ui-tooltip-shadow ui-tooltip-rounded ui-tooltip-d4p ui-tooltip-red"
             }
        };
        var qtip_data = {
             content: {
                 title: gdCPTTools.txt_qtip_title, button: true,
                 text: function(api) {return jQuery(this).attr("qtip-content");}
             },
             position: {
                 my: "left center", at: "right center", adjust: {x: 10}
             },
             style: {
                 widget: true, classes: "ui-tooltip-shadow ui-tooltip-red"
             }
        };

        var qtip_error = jQuery.extend(true, {}, qtip_data);
        var qtip_info_error = jQuery.extend(true, {}, qtip_info);
        qtip_error.style.classes = "ui-tooltip-shadow ui-tooltip-red";
        qtip_info_error.style.classes = "ui-tooltip-shadow ui-tooltip-red";
        qtip_error.content.title = gdCPTTools.txt_qtip_error;

        jQuery(".gdr2-qtip-info").qtip(qtip_info);
        jQuery(".gdr2-qtip-info-error").qtip(qtip_info_error);
        jQuery(".qtip-d4p-product").qtip(qtip_d4p);
        jQuery(".gdr2-qtip").qtip(qtip_data);
        jQuery(".gdr2-qtip-error").qtip(qtip_error);
    },
    init_checkboxes: function() {
        if (gdCPTTools.ui_enhance == "off") {return;}

        jQuery("input:checkbox:not(.check-no-correcting)").checkbox({cls:"jquery-checkbox", empty:gdCPTTools.url + "gfx/blank.gif"});
        jQuery("input:radio:not(.check-no-correcting)").checkbox({cls:"jquery-radiobox", empty:gdCPTTools.url + "gfx/blank.gif"});
        jQuery("input.switchbox:not(.check-no-correcting)").checkbox({cls:"jquery-switchbox", empty:gdCPTTools.url + "gfx/blank.gif"});
        jQuery("input.switchbox-big:not(.check-no-correcting)").checkbox({cls:"jquery-switchbox-big", empty:gdCPTTools.url + "gfx/blank.gif"});
    },
    toggler: {
        groupOpen: function(id, add_to_cookie) {
            jQuery(".gdr2-group-elements-" + id).slideDown();
            jQuery("#gdr2-toggle-" + id).addClass("toggle-opened");
            jQuery("#gdr2-toggle-" + id).removeClass("toggle-closed");
            if (add_to_cookie) {
                gdCPTAdmin.tmp.settings_toggle[gdCPTAdmin.tmp.settings_toggle.length] = id;
                setCookie(gdCPTTools.cookie_name, gdCPTAdmin.tmp.settings_toggle.join("|"), 365);
            }
        },
        groupClose: function(id) {
            jQuery(".gdr2-group-elements-" + id).slideUp();
            jQuery("#gdr2-toggle-" + id).addClass("toggle-closed");
            jQuery("#gdr2-toggle-" + id).removeClass("toggle-opened");
            gdCPTAdmin.tmp.settings_toggle = jQuery.grep(gdCPTAdmin.tmp.settings_toggle, function(value) {
                return value != id;
            });
            setCookie(gdCPTTools.cookie_name, gdCPTAdmin.tmp.settings_toggle.join("|"), 365);
        }
    }
};

jQuery(document).ready(function() {
    gdCPTAdmin.init_qtip();
    gdCPTAdmin.init_checkboxes();
    gdCPTAdmin.init_toggler();
    gdCPTAdmin.init();
    gdCPTAdmin.init_confirm();
});
