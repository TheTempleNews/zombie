// jQuery Numberic //
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(z($){$.v.t=z(a,b){n(H a===\'16\'){a={C:a}}a=a||{};n(H a.F=="W")a.F=u;q c=(a.C===B)?"":a.C||".";q d=(a.F===u)?u:B;q b=H b=="z"?b:z(){};w s.y("t.C",c).y("t.F",d).y("t.O",b).J($.v.t.J).Q($.v.t.Q).K($.v.t.K)};$.v.t.J=z(e){q a=$.y(s,"t.C");q b=$.y(s,"t.F");q c=e.L?e.L:e.N?e.N:0;n(c==13&&s.18.1e()=="1b"){w u}E n(c==13){w B}q d=B;n((e.A&&c==1i)||(e.A&&c==1m))w u;n((e.A&&c==1p)||(e.A&&c==1t))w u;n((e.A&&c==1v)||(e.A&&c==1x))w u;n((e.A&&c==1z)||(e.A&&c==1a))w u;n((e.A&&c==1g)||(e.A&&c==1o)||(e.1d&&c==X))w u;n(c<1k||c>1r){n(s.x.I("-")!=0&&b&&c==X&&(s.x.G===0||($.v.R(s))===0))w u;n(a&&c==a.Z(0)&&s.x.I(a)!=-1){d=B}n(c!=8&&c!=9&&c!=13&&c!=17&&c!=1s&&c!=1l&&c!=1A&&c!=14){d=B}E{n(H e.L!="W"){n(e.N==e.M&&e.M!=0){d=u;n(e.M==14)d=B}E n(e.N!=0&&e.L===0&&e.M===0){d=u}}}n(a&&c==a.Z(0)){n(s.x.I(a)==-1){d=u}E{d=B}}}E{d=u}w d};$.v.t.Q=z(e){q a=s.x;n(a.G>0){q b=$.v.R(s);q c=$.y(s,"t.C");q d=$.y(s,"t.F");n(c!==""){q f=a.I(c);n(f===0){s.x="0"+a}n(f==1&&a.U(0)=="-"){s.x="-0"+a.D(1)}a=s.x}q g=[0,1,2,3,4,5,6,7,8,9,\'-\',c];q h=a.G;V(q i=h-1;i>=0;i--){q k=a.U(i);n(i!=0&&k=="-"){a=a.D(0,i)+a.D(i+1)}E n(i===0&&!d&&k=="-"){a=a.D(1)}q l=B;V(q j=0;j<g.G;j++){n(k==g[j]){l=u;1h}}n(!l||k==" "){a=a.D(0,i)+a.D(i+1)}}q m=a.I(c);n(m>0){V(q i=h-1;i>m;i--){q k=a.U(i);n(k==c){a=a.D(0,i)+a.D(i+1)}}}s.x=a;$.v.10(s,b)}};$.v.t.K=z(){q a=$.y(s,"t.C");q b=$.y(s,"t.O");q c=s.x;n(c!==""){q d=1w 19("^\\\\d+$|\\\\d*"+a+"\\\\d+");n(!d.1B(c)){b.1F(s)}}};$.v.1n=z(){w s.y("t.C",P).y("t.F",P).y("t.O",P).Y("J",$.v.t.J).Y("K",$.v.t.K)};$.v.R=z(o){n(o.T){q r=1f.1u.1H().1D();r.12(\'S\',o.x.G);n(r.11==\'\')w o.x.G;w o.x.1c(r.11)}E w o.1q};$.v.10=z(o,p){n(H p=="1C")p=[p,p];n(p&&p.1G==1j&&p.G==2){n(o.T){q r=o.T();r.1E(u);r.1J(\'S\',p[0]);r.12(\'S\',p[1]);r.1y()}E n(o.15){o.1I();o.15(p[0],p[1])}}}})(1K);',62,109,'|||||||||||||||||||||||if|||var||this|numeric|true|fn|return|value|data|function|ctrlKey|false|decimal|substring|else|negative|length|typeof|indexOf|keypress|blur|charCode|which|keyCode|callback|null|keyup|getSelectionStart|character|createTextRange|charAt|for|undefined|45|unbind|charCodeAt|setSelection|text|moveEnd||46|setSelectionRange|boolean|35|nodeName|RegExp|90|input|lastIndexOf|shiftKey|toLowerCase|document|118|break|97|Array|48|37|65|removeNumeric|86|120|selectionStart|57|36|88|selection|99|new|67|select|122|39|exec|number|duplicate|collapse|apply|constructor|createRange|focus|moveStart|jQuery'.split('|'),0,{}));

// Color Picker Modded
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(9($){u j=9(){u g={},2X,1N=26,3e,2l=\'<p M="n"><p M="2t"><p><p></p></p></p><p M="21"><p></p></p><p M="2e"></p><p M="1T"></p><p M="36"><W 12="1b" 1d="6" 18="6" /></p><p M="3l 1k"><W 12="1b" 1d="3" 18="3" /><P></P></p><p M="3p 1k"><W 12="1b" 1d="3" 18="3" /><P></P></p><p M="3r 1k"><W 12="1b" 1d="3" 18="3" /><P></P></p><p M="31 1k"><W 12="1b" 1d="3" 18="3" /><P></P></p><p M="3i 1k"><W 12="1b" 1d="3" 18="3" /><P></P></p><p M="3n 1k"><W 12="1b" 1d="3" 18="3" /><P></P></p><p M="2a"></p></p>\',2B={2p:\'1P\',2i:9(){},2F:9(){},2J:9(){},2x:9(){},2H:9(){},z:\'3a\',1p:1h,1X:Q},15=9(a,b){u c=1t(a);$(b).7(\'n\').L.I(1).D(c.r).Y().I(2).D(c.g).Y().I(3).D(c.b).Y()},1n=9(a,b){$(b).7(\'n\').L.I(4).D(a.h).Y().I(5).D(a.s).Y().I(6).D(a.b).Y()},14=9(a,b){$(b).7(\'n\').L.I(0).D(1a(a)).Y()},1x=9(a,b){$(b).7(\'n\').1V.1c(\'24\',\'#\'+1a({h:a.h,s:K,b:K}));$(b).7(\'n\').28.1c({1E:J(S*a.s/K,10),1f:J(S*(K-a.b)/K,10)})},1u=9(a,b){$(b).7(\'n\').2g.1c(\'1f\',J(S-S*a.h/19,10))},1I=9(a,b){$(b).7(\'n\').2n.1c(\'24\',\'#\'+1a(a))},1z=9(a,b){$(b).7(\'n\').2v.1c(\'24\',\'#\'+1a(a))},2D=9(a){u b=a.2Z||a.3g||-1;q((b>1N&&b<=38)||b==32){A Q}u c=$(k).G().G();q(c.7(\'n\').1p===1h){Z.X(k)}},Z=9(a){u b=$(k).G().G(),O;q(k.17.1r.1i(\'2c\')>0){b.7(\'n\').z=O=1C(2j(k.34))}F q(k.17.1r.1i(\'2z\')>0){b.7(\'n\').z=O=1J({h:J(b.7(\'n\').L.I(4).D(),10),s:J(b.7(\'n\').L.I(5).D(),10),b:J(b.7(\'n\').L.I(6).D(),10)})}F{b.7(\'n\').z=O=1w(2r({r:J(b.7(\'n\').L.I(1).D(),10),g:J(b.7(\'n\').L.I(2).D(),10),b:J(b.7(\'n\').L.I(3).D(),10)}))}q(a){15(O,b.x(0));14(O,b.x(0));1n(O,b.x(0))}1x(O,b.x(0));1u(O,b.x(0));1z(O,b.x(0));b.7(\'n\').2x.X(b,[O,1a(O),1t(O)])},1R=9(a){u b=$(k).G().G();b.7(\'n\').L.G().1G(\'1y\')},1A=9(){1N=k.17.1r.1i(\'2c\')>0?3c:26;$(k).G().G().7(\'n\').L.G().1G(\'1y\');$(k).G().1Z(\'1y\')},27=9(a){u b=$(k).G().R(\'W\').1A();u c={1B:$(k).G().1Z(\'2m\'),N:k.17.1r.1i(\'2Y\')>0?19:(k.17.1r.1i(\'2z\')>0?K:U),y:a.1L,1M:b,D:J(b.D(),10),1e:$(k).G().G().7(\'n\').1p};$(C).H(\'1l\',c,1O);$(C).H(\'1j\',c,1U)},1U=9(a){a.7.1M.D(B.N(0,B.V(a.7.N,J(a.7.D+a.1L-a.7.y,10))));q(a.7.1e){Z.X(a.7.1M.x(0),[1h])}A Q},1O=9(a){Z.X(a.7.1M.x(0),[1h]);a.7.1B.1G(\'2m\').R(\'W\').1A();$(C).13(\'1l\',1O);$(C).13(\'1j\',1U);A Q},2f=9(a){u b={E:$(k).G(),y:$(k).1Q().1f};b.1e=b.E.7(\'n\').1p;$(C).H(\'1l\',b,1Y);$(C).H(\'1j\',b,20)},20=9(a){Z.X(a.7.E.7(\'n\').L.I(4).D(J(19*(S-B.N(0,B.V(S,(a.1L-a.7.y))))/S,10)).x(0),[a.7.1e]);A Q},1Y=9(a){15(a.7.E.7(\'n\').z,a.7.E.x(0));14(a.7.E.7(\'n\').z,a.7.E.x(0));$(C).13(\'1l\',1Y);$(C).13(\'1j\',20);A Q},2u=9(a){u b={E:$(k).G(),22:$(k).1Q()};b.1e=b.E.7(\'n\').1p;$(C).H(\'1l\',b,23);$(C).H(\'1j\',b,25)},25=9(a){Z.X(a.7.E.7(\'n\').L.I(6).D(J(K*(S-B.N(0,B.V(S,(a.1L-a.7.22.1f))))/S,10)).Y().I(5).D(J(K*(B.N(0,B.V(S,(a.33-a.7.22.1E))))/S,10)).x(0),[a.7.1e]);A Q},23=9(a){15(a.7.E.7(\'n\').z,a.7.E.x(0));14(a.7.E.7(\'n\').z,a.7.E.x(0));$(C).13(\'1l\',23);$(C).13(\'1j\',25);A Q},2b=9(a){$(k).1Z(\'1y\')},2O=9(a){$(k).1G(\'1y\')},2C=9(a){u b=$(k).G();u c=b.7(\'n\').z;b.7(\'n\').1F=c;1I(c,b.x(0));b.7(\'n\').2H(c,1a(c),1t(c),b.7(\'n\').1B)},1m=9(a){u b=$(\'#\'+$(k).7(\'11\'));b.7(\'n\').2F.X(k,[b.x(0)]);u c=$(k).1Q();u d=2q();u e=c.1f+k.2R;u f=c.1E;q(e+2K>d.t+d.h){e-=k.2R+2K}q(f+2W>d.l+d.w){f-=2W}b.1c({1E:f+\'2T\',1f:e+\'2T\'});q(b.7(\'n\').2i.X(k,[b.x(0)])!==Q){b.1m()}$(C).H(\'1q\',{E:b},1v);A Q},1v=9(a){q(!2G(a.7.E.x(0),a.37,a.7.E.x(0))){q(a.7.E.7(\'n\').2J.X(k,[a.7.E.x(0)])!==Q){a.7.E.1v()}$(C).13(\'1q\',1v)}},2G=9(a,b,c){q(a==b){A 1h}q(a.2y){A a.2y(b)}q(a.2M){A!!(a.2M(b)&16)}u d=b.17;3b(d&&d!=c){q(d==a){A 1h}d=d.17}A Q},2q=9(){u m=C.3f==\'3j\';A{l:1K.30||(m?C.1D.29:C.1o.29),t:1K.3q||(m?C.1D.2E:C.1o.2E),w:1K.3z||(m?C.1D.2o:C.1o.2o),h:1K.3h||(m?C.1D.2V:C.1o.2V)}},1J=9(a){A{h:B.V(19,B.N(0,a.h)),s:B.V(K,B.N(0,a.s)),b:B.V(K,B.N(0,a.b))}},2r=9(a){A{r:B.V(U,B.N(0,a.r)),g:B.V(U,B.N(0,a.g)),b:B.V(U,B.N(0,a.b))}},2j=9(a){u b=6-a.2P;q(b>0){u o=[];3v(u i=0;i<b;i++){o.2h(\'0\')}o.2h(a);a=o.2L(\'\')}A a},2S=9(a){a=J(((a.1i(\'#\')>-1)?a.39(1):a),16);A{r:a>>16,g:(a&3t)>>8,b:(a&3E)}},1C=9(a){A 1w(2S(a))},1w=9(a){u b={h:0,s:0,b:0};u c=B.V(a.r,a.g,a.b);u d=B.N(a.r,a.g,a.b);u e=d-c;b.b=d;q(d!==0){}b.s=d!==0?U*e/d:0;q(b.s!==0){q(a.r==d){b.h=(a.g-a.b)/e}F q(a.g==d){b.h=2+(a.b-a.r)/e}F{b.h=4+(a.r-a.g)/e}}F{b.h=-1}b.h*=1H;q(b.h<0){b.h+=19}b.s*=K/U;b.b*=K/U;A b},1t=9(a){u b={};u h=B.1g(a.h);u s=B.1g(a.s*U/K);u v=B.1g(a.b*U/K);q(s===0){b.r=b.g=b.b=v}F{u c=v;u d=(U-s)*v/U;u e=(c-d)*(h%1H)/1H;q(h===19)h=0;q(h<1H){b.r=c;b.b=d;b.g=d+e}F q(h<3m){b.g=c;b.b=d;b.r=c-e}F q(h<3x){b.g=c;b.r=d;b.b=d+e}F q(h<3G){b.b=c;b.r=d;b.g=c-e}F q(h<3C){b.b=c;b.g=d;b.r=d+e}F q(h<19){b.r=c;b.g=d;b.b=c-e}F{b.r=0;b.g=0;b.b=0}}A{r:B.1g(b.r),g:B.1g(b.g),b:B.1g(b.b)}},2w=9(c){u d=[c.r.1S(16),c.g.1S(16),c.b.1S(16)];$.1s(d,9(a,b){q(b.2P==1){d[a]=\'0\'+b}});A d.2L(\'\')},1a=9(a){A 2w(1t(a))},2d=9(){u a=$(k).G();u b=a.7(\'n\').1F;a.7(\'n\').z=b;15(b,a.x(0));14(b,a.x(0));1n(b,a.x(0));1x(b,a.x(0));1u(b,a.x(0));1z(b,a.x(0))};A{2I:9(d){d=$.1W({},2B,d||{});q(2Q d.z==\'2U\'){d.z=1C(d.z)}F q(d.z.r!==T&&d.z.g!==T&&d.z.b!==T){d.z=1w(d.z)}F q(d.z.h!==T&&d.z.s!==T&&d.z.b!==T){d.z=1J(d.z)}F{A k}A k.1s(9(){q(!$(k).7(\'11\')){u a=$.1W({},d);a.1F=d.z;u b=\'35\'+J(B.3s()*3A);$(k).7(\'11\',b);u c=$(2l).3k(\'3D\',b);q(a.1X){c.2s(k).1m()}F{c.2s(C.1o)}a.L=c.R(\'W\').H(\'3w\',2D).H(\'Z\',Z).H(\'1R\',1R).H(\'1A\',1A);c.R(\'P\').H(\'1q\',27).Y().R(\'>p.1T\').H(\'1P\',2d);a.1V=c.R(\'p.2t\').H(\'1q\',2u);a.28=a.1V.R(\'p p\');a.1B=k;a.2g=c.R(\'p.21 p\');c.R(\'p.21\').H(\'1q\',2f);a.2v=c.R(\'p.2e\');a.2n=c.R(\'p.1T\');c.7(\'n\',a);c.R(\'p.2a\').H(\'3d\',2b).H(\'3B\',2O).H(\'1P\',2C);15(a.z,c.x(0));1n(a.z,c.x(0));14(a.z,c.x(0));1u(a.z,c.x(0));1x(a.z,c.x(0));1I(a.z,c.x(0));1z(a.z,c.x(0));q(a.1X){c.1c({3J:\'3u\',3L:\'3H\'})}F{$(k).H(a.2p,1m)}}})},2k:9(){A k.1s(9(){q($(k).7(\'11\')){1m.X(k)}})},2A:9(){A k.1s(9(){q($(k).7(\'11\')){$(\'#\'+$(k).7(\'11\')).1v()}})},2N:9(b){q(2Q b==\'2U\'){b=1C(b)}F q(b.r!==T&&b.g!==T&&b.b!==T){b=1w(b)}F q(b.h!==T&&b.s!==T&&b.b!==T){b=1J(b)}F{A k}A k.1s(9(){q($(k).7(\'11\')){u a=$(\'#\'+$(k).7(\'11\'));a.7(\'n\').z=b;a.7(\'n\').1F=b;15(b,a.x(0));1n(b,a.x(0));14(b,a.x(0));1u(b,a.x(0));1x(b,a.x(0));1I(b,a.x(0));1z(b,a.x(0))}})}}}();$.3o.1W({3y:j.2I,3F:j.2A,3I:j.2k,3K:j.2N})})(3M)',62,235,'|||||||data||function|||||||||||this|||colorpicker||div|if||||var|||get||color|return|Math|document|val|cal|else|parent|bind|eq|parseInt|100|fields|class|max|col|span|false|find|150|undefined|255|min|input|apply|end|change||colorpickerId|type|unbind|fillHexFields|fillRGBFields||parentNode|size|360|HSBToHex|text|css|maxlength|preview|top|round|true|indexOf|mousemove|colorpicker_field|mouseup|show|fillHSBFields|body|livePreview|mousedown|className|each|HSBToRGB|setHue|hide|RGBToHSB|setSelector|colorpicker_focus|setNewColor|focus|el|HexToHSB|documentElement|left|origColor|removeClass|60|setCurrentColor|fixHSB|window|pageY|field|charMin|upIncrement|click|offset|blur|toString|colorpicker_current_color|moveIncrement|selector|extend|flat|upHue|addClass|moveHue|colorpicker_hue|pos|upSelector|backgroundColor|moveSelector|65|downIncrement|selectorIndic|scrollLeft|colorpicker_submit|enterSubmit|_hex|restoreOriginal|colorpicker_new_color|downHue|hue|push|onShow|fixHex|showPicker|tpl|colorpicker_slider|currentColor|clientWidth|eventName|getViewport|fixRGB|appendTo|colorpicker_color|downSelector|newColor|RGBToHex|onChange|contains|_hsb|hidePicker|defaults|clickSubmit|keyDown|scrollTop|onBeforeShow|isChildOf|onSubmit|init|onHide|176|join|compareDocumentPosition|setColor|leaveSubmit|length|typeof|offsetHeight|HexToRGB|px|string|clientHeight|356|inAction|_hsb_h|charCode|pageXOffset|colorpicker_hsb_h||pageX|value|collorpicker_|colorpicker_hex|target|90|substring|ff0000|while|70|mouseenter|visible|compatMode|keyCode|innerHeight|colorpicker_hsb_s|CSS1Compat|attr|colorpicker_rgb_r|120|colorpicker_hsb_b|fn|colorpicker_rgb_g|pageYOffset|colorpicker_rgb_b|random|0x00FF00|relative|for|keyup|180|ColorPicker|innerWidth|1000|mouseleave|300|id|0x0000FF|ColorPickerHide|240|block|ColorPickerShow|position|ColorPickerSetColor|display|jQuery'.split('|'),0,{}));

// jQuery UI Datepicker 1.8.16 //
(function($,undefined){function Datepicker(){this.debug=!1,this._curInst=null,this._keyEvent=!1,this._disabledInputs=[],this._datepickerShowing=!1,this._inDialog=!1,this._mainDivId="ui-datepicker-div",this._inlineClass="ui-datepicker-inline",this._appendClass="ui-datepicker-append",this._triggerClass="ui-datepicker-trigger",this._dialogClass="ui-datepicker-dialog",this._disableClass="ui-datepicker-disabled",this._unselectableClass="ui-datepicker-unselectable",this._currentClass="ui-datepicker-current-day",this._dayOverClass="ui-datepicker-days-cell-over",this.regional=[],this.regional[""]={closeText:"Done",prevText:"Prev",nextText:"Next",currentText:"Today",monthNames:["January","February","March","April","May","June","July","August","September","October","November","December"],monthNamesShort:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],dayNames:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],dayNamesShort:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],dayNamesMin:["Su","Mo","Tu","We","Th","Fr","Sa"],weekHeader:"Wk",dateFormat:"mm/dd/yy",firstDay:0,isRTL:!1,showMonthAfterYear:!1,yearSuffix:""},this._defaults={showOn:"focus",showAnim:"fadeIn",showOptions:{},defaultDate:null,appendText:"",buttonText:"...",buttonImage:"",buttonImageOnly:!1,hideIfNoPrevNext:!1,navigationAsDateFormat:!1,gotoCurrent:!1,changeMonth:!1,changeYear:!1,yearRange:"c-10:c+10",showOtherMonths:!1,selectOtherMonths:!1,showWeek:!1,calculateWeek:this.iso8601Week,shortYearCutoff:"+10",minDate:null,maxDate:null,duration:"fast",beforeShowDay:null,beforeShow:null,onSelect:null,onChangeMonthYear:null,onClose:null,numberOfMonths:1,showCurrentAtPos:0,stepMonths:1,stepBigMonths:12,altField:"",altFormat:"",constrainInput:!0,showButtonPanel:!1,autoSize:!1,disabled:!1},$.extend(this._defaults,this.regional[""]),this.dpDiv=bindHover($('<div id="'+this._mainDivId+'" class="ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>'))}function bindHover(a){var b="button, .ui-datepicker-prev, .ui-datepicker-next, .ui-datepicker-calendar td a";return a.bind("mouseout",function(a){var c=$(a.target).closest(b);if(!c.length)return;c.removeClass("ui-state-hover ui-datepicker-prev-hover ui-datepicker-next-hover")}).bind("mouseover",function(c){var d=$(c.target).closest(b);if($.datepicker._isDisabledDatepicker(instActive.inline?a.parent()[0]:instActive.input[0])||!d.length)return;d.parents(".ui-datepicker-calendar").find("a").removeClass("ui-state-hover"),d.addClass("ui-state-hover"),d.hasClass("ui-datepicker-prev")&&d.addClass("ui-datepicker-prev-hover"),d.hasClass("ui-datepicker-next")&&d.addClass("ui-datepicker-next-hover")})}function extendRemove(a,b){$.extend(a,b);for(var c in b)if(b[c]==null||b[c]==undefined)a[c]=b[c];return a}function isArray(a){return a&&($.browser.safari&&typeof a=="object"&&a.length||a.constructor&&a.constructor.toString().match(/\Array\(\)/))}$.extend($.ui,{datepicker:{version:"1.8.20"}});var PROP_NAME="datepicker",dpuuid=(new Date).getTime(),instActive;$.extend(Datepicker.prototype,{markerClassName:"hasDatepicker",maxRows:4,log:function(){this.debug&&console.log.apply("",arguments)},_widgetDatepicker:function(){return this.dpDiv},setDefaults:function(a){return extendRemove(this._defaults,a||{}),this},_attachDatepicker:function(target,settings){var inlineSettings=null;for(var attrName in this._defaults){var attrValue=target.getAttribute("date:"+attrName);if(attrValue){inlineSettings=inlineSettings||{};try{inlineSettings[attrName]=eval(attrValue)}catch(err){inlineSettings[attrName]=attrValue}}}var nodeName=target.nodeName.toLowerCase(),inline=nodeName=="div"||nodeName=="span";target.id||(this.uuid+=1,target.id="dp"+this.uuid);var inst=this._newInst($(target),inline);inst.settings=$.extend({},settings||{},inlineSettings||{}),nodeName=="input"?this._connectDatepicker(target,inst):inline&&this._inlineDatepicker(target,inst)},_newInst:function(a,b){var c=a[0].id.replace(/([^A-Za-z0-9_-])/g,"\\\\$1");return{id:c,input:a,selectedDay:0,selectedMonth:0,selectedYear:0,drawMonth:0,drawYear:0,inline:b,dpDiv:b?bindHover($('<div class="'+this._inlineClass+' ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all"></div>')):this.dpDiv}},_connectDatepicker:function(a,b){var c=$(a);b.append=$([]),b.trigger=$([]);if(c.hasClass(this.markerClassName))return;this._attachments(c,b),c.addClass(this.markerClassName).keydown(this._doKeyDown).keypress(this._doKeyPress).keyup(this._doKeyUp).bind("setData.datepicker",function(a,c,d){b.settings[c]=d}).bind("getData.datepicker",function(a,c){return this._get(b,c)}),this._autoSize(b),$.data(a,PROP_NAME,b),b.settings.disabled&&this._disableDatepicker(a)},_attachments:function(a,b){var c=this._get(b,"appendText"),d=this._get(b,"isRTL");b.append&&b.append.remove(),c&&(b.append=$('<span class="'+this._appendClass+'">'+c+"</span>"),a[d?"before":"after"](b.append)),a.unbind("focus",this._showDatepicker),b.trigger&&b.trigger.remove();var e=this._get(b,"showOn");(e=="focus"||e=="both")&&a.focus(this._showDatepicker);if(e=="button"||e=="both"){var f=this._get(b,"buttonText"),g=this._get(b,"buttonImage");b.trigger=$(this._get(b,"buttonImageOnly")?$("<img/>").addClass(this._triggerClass).attr({src:g,alt:f,title:f}):$('<button type="button"></button>').addClass(this._triggerClass).html(g==""?f:$("<img/>").attr({src:g,alt:f,title:f}))),a[d?"before":"after"](b.trigger),b.trigger.click(function(){return $.datepicker._datepickerShowing&&$.datepicker._lastInput==a[0]?$.datepicker._hideDatepicker():$.datepicker._datepickerShowing&&$.datepicker._lastInput!=a[0]?($.datepicker._hideDatepicker(),$.datepicker._showDatepicker(a[0])):$.datepicker._showDatepicker(a[0]),!1})}},_autoSize:function(a){if(this._get(a,"autoSize")&&!a.inline){var b=new Date(2009,11,20),c=this._get(a,"dateFormat");if(c.match(/[DM]/)){var d=function(a){var b=0,c=0;for(var d=0;d<a.length;d++)a[d].length>b&&(b=a[d].length,c=d);return c};b.setMonth(d(this._get(a,c.match(/MM/)?"monthNames":"monthNamesShort"))),b.setDate(d(this._get(a,c.match(/DD/)?"dayNames":"dayNamesShort"))+20-b.getDay())}a.input.attr("size",this._formatDate(a,b).length)}},_inlineDatepicker:function(a,b){var c=$(a);if(c.hasClass(this.markerClassName))return;c.addClass(this.markerClassName).append(b.dpDiv).bind("setData.datepicker",function(a,c,d){b.settings[c]=d}).bind("getData.datepicker",function(a,c){return this._get(b,c)}),$.data(a,PROP_NAME,b),this._setDate(b,this._getDefaultDate(b),!0),this._updateDatepicker(b),this._updateAlternate(b),b.settings.disabled&&this._disableDatepicker(a),b.dpDiv.css("display","block")},_dialogDatepicker:function(a,b,c,d,e){var f=this._dialogInst;if(!f){this.uuid+=1;var g="dp"+this.uuid;this._dialogInput=$('<input type="text" id="'+g+'" style="position: absolute; top: -100px; width: 0px; z-index: -10;"/>'),this._dialogInput.keydown(this._doKeyDown),$("body").append(this._dialogInput),f=this._dialogInst=this._newInst(this._dialogInput,!1),f.settings={},$.data(this._dialogInput[0],PROP_NAME,f)}extendRemove(f.settings,d||{}),b=b&&b.constructor==Date?this._formatDate(f,b):b,this._dialogInput.val(b),this._pos=e?e.length?e:[e.pageX,e.pageY]:null;if(!this._pos){var h=document.documentElement.clientWidth,i=document.documentElement.clientHeight,j=document.documentElement.scrollLeft||document.body.scrollLeft,k=document.documentElement.scrollTop||document.body.scrollTop;this._pos=[h/2-100+j,i/2-150+k]}return this._dialogInput.css("left",this._pos[0]+20+"px").css("top",this._pos[1]+"px"),f.settings.onSelect=c,this._inDialog=!0,this.dpDiv.addClass(this._dialogClass),this._showDatepicker(this._dialogInput[0]),$.blockUI&&$.blockUI(this.dpDiv),$.data(this._dialogInput[0],PROP_NAME,f),this},_destroyDatepicker:function(a){var b=$(a),c=$.data(a,PROP_NAME);if(!b.hasClass(this.markerClassName))return;var d=a.nodeName.toLowerCase();$.removeData(a,PROP_NAME),d=="input"?(c.append.remove(),c.trigger.remove(),b.removeClass(this.markerClassName).unbind("focus",this._showDatepicker).unbind("keydown",this._doKeyDown).unbind("keypress",this._doKeyPress).unbind("keyup",this._doKeyUp)):(d=="div"||d=="span")&&b.removeClass(this.markerClassName).empty()},_enableDatepicker:function(a){var b=$(a),c=$.data(a,PROP_NAME);if(!b.hasClass(this.markerClassName))return;var d=a.nodeName.toLowerCase();if(d=="input")a.disabled=!1,c.trigger.filter("button").each(function(){this.disabled=!1}).end().filter("img").css({opacity:"1.0",cursor:""});else if(d=="div"||d=="span"){var e=b.children("."+this._inlineClass);e.children().removeClass("ui-state-disabled"),e.find("select.ui-datepicker-month, select.ui-datepicker-year").removeAttr("disabled")}this._disabledInputs=$.map(this._disabledInputs,function(b){return b==a?null:b})},_disableDatepicker:function(a){var b=$(a),c=$.data(a,PROP_NAME);if(!b.hasClass(this.markerClassName))return;var d=a.nodeName.toLowerCase();if(d=="input")a.disabled=!0,c.trigger.filter("button").each(function(){this.disabled=!0}).end().filter("img").css({opacity:"0.5",cursor:"default"});else if(d=="div"||d=="span"){var e=b.children("."+this._inlineClass);e.children().addClass("ui-state-disabled"),e.find("select.ui-datepicker-month, select.ui-datepicker-year").attr("disabled","disabled")}this._disabledInputs=$.map(this._disabledInputs,function(b){return b==a?null:b}),this._disabledInputs[this._disabledInputs.length]=a},_isDisabledDatepicker:function(a){if(!a)return!1;for(var b=0;b<this._disabledInputs.length;b++)if(this._disabledInputs[b]==a)return!0;return!1},_getInst:function(a){try{return $.data(a,PROP_NAME)}catch(b){throw"Missing instance data for this datepicker"}},_optionDatepicker:function(a,b,c){var d=this._getInst(a);if(arguments.length==2&&typeof b=="string")return b=="defaults"?$.extend({},$.datepicker._defaults):d?b=="all"?$.extend({},d.settings):this._get(d,b):null;var e=b||{};typeof b=="string"&&(e={},e[b]=c);if(d){this._curInst==d&&this._hideDatepicker();var f=this._getDateDatepicker(a,!0),g=this._getMinMaxDate(d,"min"),h=this._getMinMaxDate(d,"max");extendRemove(d.settings,e),g!==null&&e.dateFormat!==undefined&&e.minDate===undefined&&(d.settings.minDate=this._formatDate(d,g)),h!==null&&e.dateFormat!==undefined&&e.maxDate===undefined&&(d.settings.maxDate=this._formatDate(d,h)),this._attachments($(a),d),this._autoSize(d),this._setDate(d,f),this._updateAlternate(d),this._updateDatepicker(d)}},_changeDatepicker:function(a,b,c){this._optionDatepicker(a,b,c)},_refreshDatepicker:function(a){var b=this._getInst(a);b&&this._updateDatepicker(b)},_setDateDatepicker:function(a,b){var c=this._getInst(a);c&&(this._setDate(c,b),this._updateDatepicker(c),this._updateAlternate(c))},_getDateDatepicker:function(a,b){var c=this._getInst(a);return c&&!c.inline&&this._setDateFromField(c,b),c?this._getDate(c):null},_doKeyDown:function(a){var b=$.datepicker._getInst(a.target),c=!0,d=b.dpDiv.is(".ui-datepicker-rtl");b._keyEvent=!0;if($.datepicker._datepickerShowing)switch(a.keyCode){case 9:$.datepicker._hideDatepicker(),c=!1;break;case 13:var e=$("td."+$.datepicker._dayOverClass+":not(."+$.datepicker._currentClass+")",b.dpDiv);e[0]&&$.datepicker._selectDay(a.target,b.selectedMonth,b.selectedYear,e[0]);var f=$.datepicker._get(b,"onSelect");if(f){var g=$.datepicker._formatDate(b);f.apply(b.input?b.input[0]:null,[g,b])}else $.datepicker._hideDatepicker();return!1;case 27:$.datepicker._hideDatepicker();break;case 33:$.datepicker._adjustDate(a.target,a.ctrlKey?-$.datepicker._get(b,"stepBigMonths"):-$.datepicker._get(b,"stepMonths"),"M");break;case 34:$.datepicker._adjustDate(a.target,a.ctrlKey?+$.datepicker._get(b,"stepBigMonths"):+$.datepicker._get(b,"stepMonths"),"M");break;case 35:(a.ctrlKey||a.metaKey)&&$.datepicker._clearDate(a.target),c=a.ctrlKey||a.metaKey;break;case 36:(a.ctrlKey||a.metaKey)&&$.datepicker._gotoToday(a.target),c=a.ctrlKey||a.metaKey;break;case 37:(a.ctrlKey||a.metaKey)&&$.datepicker._adjustDate(a.target,d?1:-1,"D"),c=a.ctrlKey||a.metaKey,a.originalEvent.altKey&&$.datepicker._adjustDate(a.target,a.ctrlKey?-$.datepicker._get(b,"stepBigMonths"):-$.datepicker._get(b,"stepMonths"),"M");break;case 38:(a.ctrlKey||a.metaKey)&&$.datepicker._adjustDate(a.target,-7,"D"),c=a.ctrlKey||a.metaKey;break;case 39:(a.ctrlKey||a.metaKey)&&$.datepicker._adjustDate(a.target,d?-1:1,"D"),c=a.ctrlKey||a.metaKey,a.originalEvent.altKey&&$.datepicker._adjustDate(a.target,a.ctrlKey?+$.datepicker._get(b,"stepBigMonths"):+$.datepicker._get(b,"stepMonths"),"M");break;case 40:(a.ctrlKey||a.metaKey)&&$.datepicker._adjustDate(a.target,7,"D"),c=a.ctrlKey||a.metaKey;break;default:c=!1}else a.keyCode==36&&a.ctrlKey?$.datepicker._showDatepicker(this):c=!1;c&&(a.preventDefault(),a.stopPropagation())},_doKeyPress:function(a){var b=$.datepicker._getInst(a.target);if($.datepicker._get(b,"constrainInput")){var c=$.datepicker._possibleChars($.datepicker._get(b,"dateFormat")),d=String.fromCharCode(a.charCode==undefined?a.keyCode:a.charCode);return a.ctrlKey||a.metaKey||d<" "||!c||c.indexOf(d)>-1}},_doKeyUp:function(a){var b=$.datepicker._getInst(a.target);if(b.input.val()!=b.lastVal)try{var c=$.datepicker.parseDate($.datepicker._get(b,"dateFormat"),b.input?b.input.val():null,$.datepicker._getFormatConfig(b));c&&($.datepicker._setDateFromField(b),$.datepicker._updateAlternate(b),$.datepicker._updateDatepicker(b))}catch(d){$.datepicker.log(d)}return!0},_showDatepicker:function(a){a=a.target||a,a.nodeName.toLowerCase()!="input"&&(a=$("input",a.parentNode)[0]);if($.datepicker._isDisabledDatepicker(a)||$.datepicker._lastInput==a)return;var b=$.datepicker._getInst(a);$.datepicker._curInst&&$.datepicker._curInst!=b&&($.datepicker._curInst.dpDiv.stop(!0,!0),b&&$.datepicker._datepickerShowing&&$.datepicker._hideDatepicker($.datepicker._curInst.input[0]));var c=$.datepicker._get(b,"beforeShow"),d=c?c.apply(a,[a,b]):{};if(d===!1)return;extendRemove(b.settings,d),b.lastVal=null,$.datepicker._lastInput=a,$.datepicker._setDateFromField(b),$.datepicker._inDialog&&(a.value=""),$.datepicker._pos||($.datepicker._pos=$.datepicker._findPos(a),$.datepicker._pos[1]+=a.offsetHeight);var e=!1;$(a).parents().each(function(){return e|=$(this).css("position")=="fixed",!e}),e&&$.browser.opera&&($.datepicker._pos[0]-=document.documentElement.scrollLeft,$.datepicker._pos[1]-=document.documentElement.scrollTop);var f={left:$.datepicker._pos[0],top:$.datepicker._pos[1]};$.datepicker._pos=null,b.dpDiv.empty(),b.dpDiv.css({position:"absolute",display:"block",top:"-1000px"}),$.datepicker._updateDatepicker(b),f=$.datepicker._checkOffset(b,f,e),b.dpDiv.css({position:$.datepicker._inDialog&&$.blockUI?"static":e?"fixed":"absolute",display:"none",left:f.left+"px",top:f.top+"px"});if(!b.inline){var g=$.datepicker._get(b,"showAnim"),h=$.datepicker._get(b,"duration"),i=function(){var a=b.dpDiv.find("iframe.ui-datepicker-cover");if(!!a.length){var c=$.datepicker._getBorders(b.dpDiv);a.css({left:-c[0],top:-c[1],width:b.dpDiv.outerWidth(),height:b.dpDiv.outerHeight()})}};b.dpDiv.zIndex($(a).zIndex()+1),$.datepicker._datepickerShowing=!0,$.effects&&$.effects[g]?b.dpDiv.show(g,$.datepicker._get(b,"showOptions"),h,i):b.dpDiv[g||"show"](g?h:null,i),(!g||!h)&&i(),b.input.is(":visible")&&!b.input.is(":disabled")&&b.input.focus(),$.datepicker._curInst=b}},_updateDatepicker:function(a){var b=this;b.maxRows=4;var c=$.datepicker._getBorders(a.dpDiv);instActive=a,a.dpDiv.empty().append(this._generateHTML(a));var d=a.dpDiv.find("iframe.ui-datepicker-cover");!d.length||d.css({left:-c[0],top:-c[1],width:a.dpDiv.outerWidth(),height:a.dpDiv.outerHeight()}),a.dpDiv.find("."+this._dayOverClass+" a").mouseover();var e=this._getNumberOfMonths(a),f=e[1],g=17;a.dpDiv.removeClass("ui-datepicker-multi-2 ui-datepicker-multi-3 ui-datepicker-multi-4").width(""),f>1&&a.dpDiv.addClass("ui-datepicker-multi-"+f).css("width",g*f+"em"),a.dpDiv[(e[0]!=1||e[1]!=1?"add":"remove")+"Class"]("ui-datepicker-multi"),a.dpDiv[(this._get(a,"isRTL")?"add":"remove")+"Class"]("ui-datepicker-rtl"),a==$.datepicker._curInst&&$.datepicker._datepickerShowing&&a.input&&a.input.is(":visible")&&!a.input.is(":disabled")&&a.input[0]!=document.activeElement&&a.input.focus();if(a.yearshtml){var h=a.yearshtml;setTimeout(function(){h===a.yearshtml&&a.yearshtml&&a.dpDiv.find("select.ui-datepicker-year:first").replaceWith(a.yearshtml),h=a.yearshtml=null},0)}},_getBorders:function(a){var b=function(a){return{thin:1,medium:2,thick:3}[a]||a};return[parseFloat(b(a.css("border-left-width"))),parseFloat(b(a.css("border-top-width")))]},_checkOffset:function(a,b,c){var d=a.dpDiv.outerWidth(),e=a.dpDiv.outerHeight(),f=a.input?a.input.outerWidth():0,g=a.input?a.input.outerHeight():0,h=document.documentElement.clientWidth+$(document).scrollLeft(),i=document.documentElement.clientHeight+$(document).scrollTop();return b.left-=this._get(a,"isRTL")?d-f:0,b.left-=c&&b.left==a.input.offset().left?$(document).scrollLeft():0,b.top-=c&&b.top==a.input.offset().top+g?$(document).scrollTop():0,b.left-=Math.min(b.left,b.left+d>h&&h>d?Math.abs(b.left+d-h):0),b.top-=Math.min(b.top,b.top+e>i&&i>e?Math.abs(e+g):0),b},_findPos:function(a){var b=this._getInst(a),c=this._get(b,"isRTL");while(a&&(a.type=="hidden"||a.nodeType!=1||$.expr.filters.hidden(a)))a=a[c?"previousSibling":"nextSibling"];var d=$(a).offset();return[d.left,d.top]},_hideDatepicker:function(a){var b=this._curInst;if(!b||a&&b!=$.data(a,PROP_NAME))return;if(this._datepickerShowing){var c=this._get(b,"showAnim"),d=this._get(b,"duration"),e=function(){$.datepicker._tidyDialog(b)};$.effects&&$.effects[c]?b.dpDiv.hide(c,$.datepicker._get(b,"showOptions"),d,e):b.dpDiv[c=="slideDown"?"slideUp":c=="fadeIn"?"fadeOut":"hide"](c?d:null,e),c||e(),this._datepickerShowing=!1;var f=this._get(b,"onClose");f&&f.apply(b.input?b.input[0]:null,[b.input?b.input.val():"",b]),this._lastInput=null,this._inDialog&&(this._dialogInput.css({position:"absolute",left:"0",top:"-100px"}),$.blockUI&&($.unblockUI(),$("body").append(this.dpDiv))),this._inDialog=!1}},_tidyDialog:function(a){a.dpDiv.removeClass(this._dialogClass).unbind(".ui-datepicker-calendar")},_checkExternalClick:function(a){if(!$.datepicker._curInst)return;var b=$(a.target),c=$.datepicker._getInst(b[0]);(b[0].id!=$.datepicker._mainDivId&&b.parents("#"+$.datepicker._mainDivId).length==0&&!b.hasClass($.datepicker.markerClassName)&&!b.closest("."+$.datepicker._triggerClass).length&&$.datepicker._datepickerShowing&&(!$.datepicker._inDialog||!$.blockUI)||b.hasClass($.datepicker.markerClassName)&&$.datepicker._curInst!=c)&&$.datepicker._hideDatepicker()},_adjustDate:function(a,b,c){var d=$(a),e=this._getInst(d[0]);if(this._isDisabledDatepicker(d[0]))return;this._adjustInstDate(e,b+(c=="M"?this._get(e,"showCurrentAtPos"):0),c),this._updateDatepicker(e)},_gotoToday:function(a){var b=$(a),c=this._getInst(b[0]);if(this._get(c,"gotoCurrent")&&c.currentDay)c.selectedDay=c.currentDay,c.drawMonth=c.selectedMonth=c.currentMonth,c.drawYear=c.selectedYear=c.currentYear;else{var d=new Date;c.selectedDay=d.getDate(),c.drawMonth=c.selectedMonth=d.getMonth(),c.drawYear=c.selectedYear=d.getFullYear()}this._notifyChange(c),this._adjustDate(b)},_selectMonthYear:function(a,b,c){var d=$(a),e=this._getInst(d[0]);e["selected"+(c=="M"?"Month":"Year")]=e["draw"+(c=="M"?"Month":"Year")]=parseInt(b.options[b.selectedIndex].value,10),this._notifyChange(e),this._adjustDate(d)},_selectDay:function(a,b,c,d){var e=$(a);if($(d).hasClass(this._unselectableClass)||this._isDisabledDatepicker(e[0]))return;var f=this._getInst(e[0]);f.selectedDay=f.currentDay=$("a",d).html(),f.selectedMonth=f.currentMonth=b,f.selectedYear=f.currentYear=c,this._selectDate(a,this._formatDate(f,f.currentDay,f.currentMonth,f.currentYear))},_clearDate:function(a){var b=$(a),c=this._getInst(b[0]);this._selectDate(b,"")},_selectDate:function(a,b){var c=$(a),d=this._getInst(c[0]);b=b!=null?b:this._formatDate(d),d.input&&d.input.val(b),this._updateAlternate(d);var e=this._get(d,"onSelect");e?e.apply(d.input?d.input[0]:null,[b,d]):d.input&&d.input.trigger("change"),d.inline?this._updateDatepicker(d):(this._hideDatepicker(),this._lastInput=d.input[0],typeof d.input[0]!="object"&&d.input.focus(),this._lastInput=null)},_updateAlternate:function(a){var b=this._get(a,"altField");if(b){var c=this._get(a,"altFormat")||this._get(a,"dateFormat"),d=this._getDate(a),e=this.formatDate(c,d,this._getFormatConfig(a));$(b).each(function(){$(this).val(e)})}},noWeekends:function(a){var b=a.getDay();return[b>0&&b<6,""]},iso8601Week:function(a){var b=new Date(a.getTime());b.setDate(b.getDate()+4-(b.getDay()||7));var c=b.getTime();return b.setMonth(0),b.setDate(1),Math.floor(Math.round((c-b)/864e5)/7)+1},parseDate:function(a,b,c){if(a==null||b==null)throw"Invalid arguments";b=typeof b=="object"?b.toString():b+"";if(b=="")return null;var d=(c?c.shortYearCutoff:null)||this._defaults.shortYearCutoff;d=typeof d!="string"?d:(new Date).getFullYear()%100+parseInt(d,10);var e=(c?c.dayNamesShort:null)||this._defaults.dayNamesShort,f=(c?c.dayNames:null)||this._defaults.dayNames,g=(c?c.monthNamesShort:null)||this._defaults.monthNamesShort,h=(c?c.monthNames:null)||this._defaults.monthNames,i=-1,j=-1,k=-1,l=-1,m=!1,n=function(b){var c=s+1<a.length&&a.charAt(s+1)==b;return c&&s++,c},o=function(a){var c=n(a),d=a=="@"?14:a=="!"?20:a=="y"&&c?4:a=="o"?3:2,e=new RegExp("^\\d{1,"+d+"}"),f=b.substring(r).match(e);if(!f)throw"Missing number at position "+r;return r+=f[0].length,parseInt(f[0],10)},p=function(a,c,d){var e=$.map(n(a)?d:c,function(a,b){return[[b,a]]}).sort(function(a,b){return-(a[1].length-b[1].length)}),f=-1;$.each(e,function(a,c){var d=c[1];if(b.substr(r,d.length).toLowerCase()==d.toLowerCase())return f=c[0],r+=d.length,!1});if(f!=-1)return f+1;throw"Unknown name at position "+r},q=function(){if(b.charAt(r)!=a.charAt(s))throw"Unexpected literal at position "+r;r++},r=0;for(var s=0;s<a.length;s++)if(m)a.charAt(s)=="'"&&!n("'")?m=!1:q();else switch(a.charAt(s)){case"d":k=o("d");break;case"D":p("D",e,f);break;case"o":l=o("o");break;case"m":j=o("m");break;case"M":j=p("M",g,h);break;case"y":i=o("y");break;case"@":var t=new Date(o("@"));i=t.getFullYear(),j=t.getMonth()+1,k=t.getDate();break;case"!":var t=new Date((o("!")-this._ticksTo1970)/1e4);i=t.getFullYear(),j=t.getMonth()+1,k=t.getDate();break;case"'":n("'")?q():m=!0;break;default:q()}if(r<b.length)throw"Extra/unparsed characters found in date: "+b.substring(r);i==-1?i=(new Date).getFullYear():i<100&&(i+=(new Date).getFullYear()-(new Date).getFullYear()%100+(i<=d?0:-100));if(l>-1){j=1,k=l;do{var u=this._getDaysInMonth(i,j-1);if(k<=u)break;j++,k-=u}while(!0)}var t=this._daylightSavingAdjust(new Date(i,j-1,k));if(t.getFullYear()!=i||t.getMonth()+1!=j||t.getDate()!=k)throw"Invalid date";return t},ATOM:"yy-mm-dd",COOKIE:"D, dd M yy",ISO_8601:"yy-mm-dd",RFC_822:"D, d M y",RFC_850:"DD, dd-M-y",RFC_1036:"D, d M y",RFC_1123:"D, d M yy",RFC_2822:"D, d M yy",RSS:"D, d M y",TICKS:"!",TIMESTAMP:"@",W3C:"yy-mm-dd",_ticksTo1970:(718685+Math.floor(492.5)-Math.floor(19.7)+Math.floor(4.925))*24*60*60*1e7,formatDate:function(a,b,c){if(!b)return"";var d=(c?c.dayNamesShort:null)||this._defaults.dayNamesShort,e=(c?c.dayNames:null)||this._defaults.dayNames,f=(c?c.monthNamesShort:null)||this._defaults.monthNamesShort,g=(c?c.monthNames:null)||this._defaults.monthNames,h=function(b){var c=m+1<a.length&&a.charAt(m+1)==b;return c&&m++,c},i=function(a,b,c){var d=""+b;if(h(a))while(d.length<c)d="0"+d;return d},j=function(a,b,c,d){return h(a)?d[b]:c[b]},k="",l=!1;if(b)for(var m=0;m<a.length;m++)if(l)a.charAt(m)=="'"&&!h("'")?l=!1:k+=a.charAt(m);else switch(a.charAt(m)){case"d":k+=i("d",b.getDate(),2);break;case"D":k+=j("D",b.getDay(),d,e);break;case"o":k+=i("o",Math.round(((new Date(b.getFullYear(),b.getMonth(),b.getDate())).getTime()-(new Date(b.getFullYear(),0,0)).getTime())/864e5),3);break;case"m":k+=i("m",b.getMonth()+1,2);break;case"M":k+=j("M",b.getMonth(),f,g);break;case"y":k+=h("y")?b.getFullYear():(b.getYear()%100<10?"0":"")+b.getYear()%100;break;case"@":k+=b.getTime();break;case"!":k+=b.getTime()*1e4+this._ticksTo1970;break;case"'":h("'")?k+="'":l=!0;break;default:k+=a.charAt(m)}return k},_possibleChars:function(a){var b="",c=!1,d=function(b){var c=e+1<a.length&&a.charAt(e+1)==b;return c&&e++,c};for(var e=0;e<a.length;e++)if(c)a.charAt(e)=="'"&&!d("'")?c=!1:b+=a.charAt(e);else switch(a.charAt(e)){case"d":case"m":case"y":case"@":b+="0123456789";break;case"D":case"M":return null;case"'":d("'")?b+="'":c=!0;break;default:b+=a.charAt(e)}return b},_get:function(a,b){return a.settings[b]!==undefined?a.settings[b]:this._defaults[b]},_setDateFromField:function(a,b){if(a.input.val()==a.lastVal)return;var c=this._get(a,"dateFormat"),d=a.lastVal=a.input?a.input.val():null,e,f;e=f=this._getDefaultDate(a);var g=this._getFormatConfig(a);try{e=this.parseDate(c,d,g)||f}catch(h){this.log(h),d=b?"":d}a.selectedDay=e.getDate(),a.drawMonth=a.selectedMonth=e.getMonth(),a.drawYear=a.selectedYear=e.getFullYear(),a.currentDay=d?e.getDate():0,a.currentMonth=d?e.getMonth():0,a.currentYear=d?e.getFullYear():0,this._adjustInstDate(a)},_getDefaultDate:function(a){return this._restrictMinMax(a,this._determineDate(a,this._get(a,"defaultDate"),new Date))},_determineDate:function(a,b,c){var d=function(a){var b=new Date;return b.setDate(b.getDate()+a),b},e=function(b){try{return $.datepicker.parseDate($.datepicker._get(a,"dateFormat"),b,$.datepicker._getFormatConfig(a))}catch(c){}var d=(b.toLowerCase().match(/^c/)?$.datepicker._getDate(a):null)||new Date,e=d.getFullYear(),f=d.getMonth(),g=d.getDate(),h=/([+-]?[0-9]+)\s*(d|D|w|W|m|M|y|Y)?/g,i=h.exec(b);while(i){switch(i[2]||"d"){case"d":case"D":g+=parseInt(i[1],10);break;case"w":case"W":g+=parseInt(i[1],10)*7;break;case"m":case"M":f+=parseInt(i[1],10),g=Math.min(g,$.datepicker._getDaysInMonth(e,f));break;case"y":case"Y":e+=parseInt(i[1],10),g=Math.min(g,$.datepicker._getDaysInMonth(e,f))}i=h.exec(b)}return new Date(e,f,g)},f=b==null||b===""?c:typeof b=="string"?e(b):typeof b=="number"?isNaN(b)?c:d(b):new Date(b.getTime());return f=f&&f.toString()=="Invalid Date"?c:f,f&&(f.setHours(0),f.setMinutes(0),f.setSeconds(0),f.setMilliseconds(0)),this._daylightSavingAdjust(f)},_daylightSavingAdjust:function(a){return a?(a.setHours(a.getHours()>12?a.getHours()+2:0),a):null},_setDate:function(a,b,c){var d=!b,e=a.selectedMonth,f=a.selectedYear,g=this._restrictMinMax(a,this._determineDate(a,b,new Date));a.selectedDay=a.currentDay=g.getDate(),a.drawMonth=a.selectedMonth=a.currentMonth=g.getMonth(),a.drawYear=a.selectedYear=a.currentYear=g.getFullYear(),(e!=a.selectedMonth||f!=a.selectedYear)&&!c&&this._notifyChange(a),this._adjustInstDate(a),a.input&&a.input.val(d?"":this._formatDate(a))},_getDate:function(a){var b=!a.currentYear||a.input&&a.input.val()==""?null:this._daylightSavingAdjust(new Date(a.currentYear,a.currentMonth,a.currentDay));return b},_generateHTML:function(a){var b=new Date;b=this._daylightSavingAdjust(new Date(b.getFullYear(),b.getMonth(),b.getDate()));var c=this._get(a,"isRTL"),d=this._get(a,"showButtonPanel"),e=this._get(a,"hideIfNoPrevNext"),f=this._get(a,"navigationAsDateFormat"),g=this._getNumberOfMonths(a),h=this._get(a,"showCurrentAtPos"),i=this._get(a,"stepMonths"),j=g[0]!=1||g[1]!=1,k=this._daylightSavingAdjust(a.currentDay?new Date(a.currentYear,a.currentMonth,a.currentDay):new Date(9999,9,9)),l=this._getMinMaxDate(a,"min"),m=this._getMinMaxDate(a,"max"),n=a.drawMonth-h,o=a.drawYear;n<0&&(n+=12,o--);if(m){var p=this._daylightSavingAdjust(new Date(m.getFullYear(),m.getMonth()-g[0]*g[1]+1,m.getDate()));p=l&&p<l?l:p;while(this._daylightSavingAdjust(new Date(o,n,1))>p)n--,n<0&&(n=11,o--)}a.drawMonth=n,a.drawYear=o;var q=this._get(a,"prevText");q=f?this.formatDate(q,this._daylightSavingAdjust(new Date(o,n-i,1)),this._getFormatConfig(a)):q;var r=this._canAdjustMonth(a,-1,o,n)?'<a class="ui-datepicker-prev ui-corner-all" onclick="DP_jQuery_'+dpuuid+".datepicker._adjustDate('#"+a.id+"', -"+i+", 'M');\""+' title="'+q+'"><span class="ui-icon ui-icon-circle-triangle-'+(c?"e":"w")+'">'+q+"</span></a>":e?"":'<a class="ui-datepicker-prev ui-corner-all ui-state-disabled" title="'+q+'"><span class="ui-icon ui-icon-circle-triangle-'+(c?"e":"w")+'">'+q+"</span></a>",s=this._get(a,"nextText");s=f?this.formatDate(s,this._daylightSavingAdjust(new Date(o,n+i,1)),this._getFormatConfig(a)):s;var t=this._canAdjustMonth(a,1,o,n)?'<a class="ui-datepicker-next ui-corner-all" onclick="DP_jQuery_'+dpuuid+".datepicker._adjustDate('#"+a.id+"', +"+i+", 'M');\""+' title="'+s+'"><span class="ui-icon ui-icon-circle-triangle-'+(c?"w":"e")+'">'+s+"</span></a>":e?"":'<a class="ui-datepicker-next ui-corner-all ui-state-disabled" title="'+s+'"><span class="ui-icon ui-icon-circle-triangle-'+(c?"w":"e")+'">'+s+"</span></a>",u=this._get(a,"currentText"),v=this._get(a,"gotoCurrent")&&a.currentDay?k:b;u=f?this.formatDate(u,v,this._getFormatConfig(a)):u;var w=a.inline?"":'<button type="button" class="ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all" onclick="DP_jQuery_'+dpuuid+'.datepicker._hideDatepicker();">'+this._get(a,"closeText")+"</button>",x=d?'<div class="ui-datepicker-buttonpane ui-widget-content">'+(c?w:"")+(this._isInRange(a,v)?'<button type="button" class="ui-datepicker-current ui-state-default ui-priority-secondary ui-corner-all" onclick="DP_jQuery_'+dpuuid+".datepicker._gotoToday('#"+a.id+"');\""+">"+u+"</button>":"")+(c?"":w)+"</div>":"",y=parseInt(this._get(a,"firstDay"),10);y=isNaN(y)?0:y;var z=this._get(a,"showWeek"),A=this._get(a,"dayNames"),B=this._get(a,"dayNamesShort"),C=this._get(a,"dayNamesMin"),D=this._get(a,"monthNames"),E=this._get(a,"monthNamesShort"),F=this._get(a,"beforeShowDay"),G=this._get(a,"showOtherMonths"),H=this._get(a,"selectOtherMonths"),I=this._get(a,"calculateWeek")||this.iso8601Week,J=this._getDefaultDate(a),K="";for(var L=0;L<g[0];L++){var M="";this.maxRows=4;for(var N=0;N<g[1];N++){var O=this._daylightSavingAdjust(new Date(o,n,a.selectedDay)),P=" ui-corner-all",Q="";if(j){Q+='<div class="ui-datepicker-group';if(g[1]>1)switch(N){case 0:Q+=" ui-datepicker-group-first",P=" ui-corner-"+(c?"right":"left");break;case g[1]-1:Q+=" ui-datepicker-group-last",P=" ui-corner-"+(c?"left":"right");break;default:Q+=" ui-datepicker-group-middle",P=""}Q+='">'}Q+='<div class="ui-datepicker-header ui-widget-header ui-helper-clearfix'+P+'">'+(/all|left/.test(P)&&L==0?c?t:r:"")+(/all|right/.test(P)&&L==0?c?r:t:"")+this._generateMonthYearHeader(a,n,o,l,m,L>0||N>0,D,E)+'</div><table class="ui-datepicker-calendar"><thead>'+"<tr>";var R=z?'<th class="ui-datepicker-week-col">'+this._get(a,"weekHeader")+"</th>":"";for(var S=0;S<7;S++){var T=(S+y)%7;R+="<th"+((S+y+6)%7>=5?' class="ui-datepicker-week-end"':"")+">"+'<span title="'+A[T]+'">'+C[T]+"</span></th>"}Q+=R+"</tr></thead><tbody>";var U=this._getDaysInMonth(o,n);o==a.selectedYear&&n==a.selectedMonth&&(a.selectedDay=Math.min(a.selectedDay,U));var V=(this._getFirstDayOfMonth(o,n)-y+7)%7,W=Math.ceil((V+U)/7),X=j?this.maxRows>W?this.maxRows:W:W;this.maxRows=X;var Y=this._daylightSavingAdjust(new Date(o,n,1-V));for(var Z=0;Z<X;Z++){Q+="<tr>";var _=z?'<td class="ui-datepicker-week-col">'+this._get(a,"calculateWeek")(Y)+"</td>":"";for(var S=0;S<7;S++){var ba=F?F.apply(a.input?a.input[0]:null,[Y]):[!0,""],bb=Y.getMonth()!=n,bc=bb&&!H||!ba[0]||l&&Y<l||m&&Y>m;_+='<td class="'+((S+y+6)%7>=5?" ui-datepicker-week-end":"")+(bb?" ui-datepicker-other-month":"")+(Y.getTime()==O.getTime()&&n==a.selectedMonth&&a._keyEvent||J.getTime()==Y.getTime()&&J.getTime()==O.getTime()?" "+this._dayOverClass:"")+(bc?" "+this._unselectableClass+" ui-state-disabled":"")+(bb&&!G?"":" "+ba[1]+(Y.getTime()==k.getTime()?" "+this._currentClass:"")+(Y.getTime()==b.getTime()?" ui-datepicker-today":""))+'"'+((!bb||G)&&ba[2]?' title="'+ba[2]+'"':"")+(bc?"":' onclick="DP_jQuery_'+dpuuid+".datepicker._selectDay('#"+a.id+"',"+Y.getMonth()+","+Y.getFullYear()+', this);return false;"')+">"+(bb&&!G?"&#xa0;":bc?'<span class="ui-state-default">'+Y.getDate()+"</span>":'<a class="ui-state-default'+(Y.getTime()==b.getTime()?" ui-state-highlight":"")+(Y.getTime()==k.getTime()?" ui-state-active":"")+(bb?" ui-priority-secondary":"")+'" href="#">'+Y.getDate()+"</a>")+"</td>",Y.setDate(Y.getDate()+1),Y=this._daylightSavingAdjust(Y)}Q+=_+"</tr>"}n++,n>11&&(n=0,o++),Q+="</tbody></table>"+(j?"</div>"+(g[0]>0&&N==g[1]-1?'<div class="ui-datepicker-row-break"></div>':""):""),M+=Q}K+=M}return K+=x+($.browser.msie&&parseInt($.browser.version,10)<7&&!a.inline?'<iframe src="javascript:false;" class="ui-datepicker-cover" frameborder="0"></iframe>':""),a._keyEvent=!1,K},_generateMonthYearHeader:function(a,b,c,d,e,f,g,h){var i=this._get(a,"changeMonth"),j=this._get(a,"changeYear"),k=this._get(a,"showMonthAfterYear"),l='<div class="ui-datepicker-title">',m="";if(f||!i)m+='<span class="ui-datepicker-month">'+g[b]+"</span>";else{var n=d&&d.getFullYear()==c,o=e&&e.getFullYear()==c;m+='<select class="ui-datepicker-month" onchange="DP_jQuery_'+dpuuid+".datepicker._selectMonthYear('#"+a.id+"', this, 'M');\" "+">";for(var p=0;p<12;p++)(!n||p>=d.getMonth())&&(!o||p<=e.getMonth())&&(m+='<option value="'+p+'"'+(p==b?' selected="selected"':"")+">"+h[p]+"</option>");m+="</select>"}k||(l+=m+(f||!i||!j?"&#xa0;":""));if(!a.yearshtml){a.yearshtml="";if(f||!j)l+='<span class="ui-datepicker-year">'+c+"</span>";else{var q=this._get(a,"yearRange").split(":"),r=(new Date).getFullYear(),s=function(a){var b=a.match(/c[+-].*/)?c+parseInt(a.substring(1),10):a.match(/[+-].*/)?r+parseInt(a,10):parseInt(a,10);return isNaN(b)?r:b},t=s(q[0]),u=Math.max(t,s(q[1]||""));t=d?Math.max(t,d.getFullYear()):t,u=e?Math.min(u,e.getFullYear()):u,a.yearshtml+='<select class="ui-datepicker-year" onchange="DP_jQuery_'+dpuuid+".datepicker._selectMonthYear('#"+a.id+"', this, 'Y');\" "+">";for(;t<=u;t++)a.yearshtml+='<option value="'+t+'"'+(t==c?' selected="selected"':"")+">"+t+"</option>";a.yearshtml+="</select>",l+=a.yearshtml,a.yearshtml=null}}return l+=this._get(a,"yearSuffix"),k&&(l+=(f||!i||!j?"&#xa0;":"")+m),l+="</div>",l},_adjustInstDate:function(a,b,c){var d=a.drawYear+(c=="Y"?b:0),e=a.drawMonth+(c=="M"?b:0),f=Math.min(a.selectedDay,this._getDaysInMonth(d,e))+(c=="D"?b:0),g=this._restrictMinMax(a,this._daylightSavingAdjust(new Date(d,e,f)));a.selectedDay=g.getDate(),a.drawMonth=a.selectedMonth=g.getMonth(),a.drawYear=a.selectedYear=g.getFullYear(),(c=="M"||c=="Y")&&this._notifyChange(a)},_restrictMinMax:function(a,b){var c=this._getMinMaxDate(a,"min"),d=this._getMinMaxDate(a,"max"),e=c&&b<c?c:b;return e=d&&e>d?d:e,e},_notifyChange:function(a){var b=this._get(a,"onChangeMonthYear");b&&b.apply(a.input?a.input[0]:null,[a.selectedYear,a.selectedMonth+1,a])},_getNumberOfMonths:function(a){var b=this._get(a,"numberOfMonths");return b==null?[1,1]:typeof b=="number"?[1,b]:b},_getMinMaxDate:function(a,b){return this._determineDate(a,this._get(a,b+"Date"),null)},_getDaysInMonth:function(a,b){return 32-this._daylightSavingAdjust(new Date(a,b,32)).getDate()},_getFirstDayOfMonth:function(a,b){return(new Date(a,b,1)).getDay()},_canAdjustMonth:function(a,b,c,d){var e=this._getNumberOfMonths(a),f=this._daylightSavingAdjust(new Date(c,d+(b<0?b:e[0]*e[1]),1));return b<0&&f.setDate(this._getDaysInMonth(f.getFullYear(),f.getMonth())),this._isInRange(a,f)},_isInRange:function(a,b){var c=this._getMinMaxDate(a,"min"),d=this._getMinMaxDate(a,"max");return(!c||b.getTime()>=c.getTime())&&(!d||b.getTime()<=d.getTime())},_getFormatConfig:function(a){var b=this._get(a,"shortYearCutoff");return b=typeof b!="string"?b:(new Date).getFullYear()%100+parseInt(b,10),{shortYearCutoff:b,dayNamesShort:this._get(a,"dayNamesShort"),dayNames:this._get(a,"dayNames"),monthNamesShort:this._get(a,"monthNamesShort"),monthNames:this._get(a,"monthNames")}},_formatDate:function(a,b,c,d){b||(a.currentDay=a.selectedDay,a.currentMonth=a.selectedMonth,a.currentYear=a.selectedYear);var e=b?typeof b=="object"?b:this._daylightSavingAdjust(new Date(d,c,b)):this._daylightSavingAdjust(new Date(a.currentYear,a.currentMonth,a.currentDay));return this.formatDate(this._get(a,"dateFormat"),e,this._getFormatConfig(a))}}),$.fn.datepicker=function(a){if(!this.length)return this;$.datepicker.initialized||($(document).mousedown($.datepicker._checkExternalClick).find("body").append($.datepicker.dpDiv),$.datepicker.initialized=!0);var b=Array.prototype.slice.call(arguments,1);return typeof a!="string"||a!="isDisabled"&&a!="getDate"&&a!="widget"?a=="option"&&arguments.length==2&&typeof arguments[1]=="string"?$.datepicker["_"+a+"Datepicker"].apply($.datepicker,[this[0]].concat(b)):this.each(function(){typeof a=="string"?$.datepicker["_"+a+"Datepicker"].apply($.datepicker,[this].concat(b)):$.datepicker._attachDatepicker(this,a)}):$.datepicker["_"+a+"Datepicker"].apply($.datepicker,[this[0]].concat(b))},$.datepicker=new Datepicker,$.datepicker.initialized=!1,$.datepicker.uuid=(new Date).getTime(),$.datepicker.version="1.8.20",window["DP_jQuery_"+dpuuid]=$})(jQuery);;

/*jslint regexp: true, nomen: true, undef: true, sloppy: true, eqeq: true, vars: true, white: true, plusplus: true, maxerr: 50, indent: 4 */

var gdtt_form_mediaupload_field = "";
var gdtt_form_mediaupload_function = null;

var gdtt_yahoo_done = {};
var gdtt_yahoo_list = {};
var gdtt_yahoo_apis = {};

function gdtt_yahoo_tags(id, api) {
    var divid = "gdttyhsgs-" + id;
    var run = gdtt_yahoo_apis[id] != api;
    gdtt_yahoo_apis[id] = api;

    if (run) {
        gdtt_yahoo_done[id] = false;
        gdtt_yahoo_list[id] = [];
        jQuery("#" + divid).html("");
    }

    if (!gdtt_yahoo_done[id]) {
        jQuery("#" + divid).append('<div class="gdtt-yahoo-loader">' + gdttMetas.getting_tags + '</div>');
        jQuery("#" + divid).append('<div class="gdtt-yahoo-tags"></div>');
        jQuery("#" + divid).append('<div class="gdtt-yahoo-tasks"></div>');
        jQuery("#" + divid + ' .gdtt-yahoo-tasks').append('<a href="javascript:gdtt_yahoo_tags_close(\'' + id + '\')">' + gdttMetas.close + '</a>');
        jQuery("#" + divid + ' .gdtt-yahoo-tasks').append(' | <a href="javascript:gdtt_yahoo_load(\'' + id + '\')">' + gdttMetas.refresh + '</a>');
        jQuery("#" + divid + ' .gdtt-yahoo-tasks').append(' | <a href="javascript:gdtt_yahoo_tags_addall(\'' + id + '\')">' + gdttMetas.add_all + '</a>');
        gdtt_yahoo_done[id] = true;
    }
    jQuery("#" + divid).show();
    if (gdtt_yahoo_list[id].length == 0) {
        gdtt_yahoo_load(id);
    }
}

function gdtt_yahoo_tags_close(id) {
    jQuery("#gdttyhsgs-" + id).hide();
}

function gdtt_yahoo_load(id) {
    var divid = "gdttyhsgs-" + id;
    jQuery.ajax({type: 'post', dataType: 'json',
        url: 'admin-ajax.php?action=gdtt_meta_search_tags&_ajax_nonce=' + gdttMetas.nonce,
        data: {content: jQuery("#content").val(), title: jQuery("#title").val(), api: gdtt_yahoo_apis[id]},
        beforeSend: function() {
            jQuery("#" + divid + " .gdtt-yahoo-loader").show();
            jQuery("#" + divid + " .gdtt-yahoo-tags").hide();
            jQuery("#" + divid + " .gdtt-yahoo-tasks").hide();
        },
        success: function(json) {
            if (json.tags) {
                gdtt_yahoo_list[id] = json.tags;
            }
            jQuery("#" + divid + " .gdtt-yahoo-tags").html('');
            if (gdtt_yahoo_list[id].length == 0) {
                jQuery("#" + divid + " .gdtt-yahoo-tags").html(gdttMetas.no_tags_found);
            } else {
                var i;
                for (i = 0; i < gdtt_yahoo_list[id].length; i++) {
                    var tag = '<a class="gdtt-tag-button" href="#">' + gdtt_yahoo_list[id][i] + '</a> ';
                    jQuery("#" + divid + " .gdtt-yahoo-tags").append(tag);
                }
            }

            jQuery("#" + divid + " .gdtt-yahoo-loader").hide();
            jQuery("#" + divid + " .gdtt-yahoo-tags").show();
            jQuery("#" + divid + " .gdtt-yahoo-tasks").show();

            jQuery("#" + divid + " .gdtt-yahoo-tags a").click(function() {
                var clicked = jQuery(this).html();
                gdtt_yahoo_tags_add(id, clicked);
                return false;
            });
        }
    });
}

function gdtt_yahoo_tags_addall(id) {
    var tagsid = "textarea#tax-input-" + id + ".the-tags";
    var tags = jQuery(tagsid).val();
    var i;
    for (i = 0; i < gdtt_yahoo_list[id].length; i++) {
        tags+= "," + gdtt_yahoo_list[id][i];
    }
    jQuery(tagsid).val(tags);
    var taxbox = jQuery("#tagsdiv-" + id + " .tagsdiv");
    tagBox.quickClicks(taxbox);
}

function gdtt_yahoo_tags_add(id, tag) {
    var tagsid = "textarea#tax-input-" + id + ".the-tags";
    var tags = jQuery(tagsid).val();
    tags+= "," + tag;
    jQuery(tagsid).val(tags);
    var taxbox = jQuery("#tagsdiv-" + id + " .tagsdiv");
    tagBox.quickClicks(taxbox);
}

function gdtt_clear_tags(id) {
    var ids = [];
    var i;
    jQuery("#" + id + " .tagchecklist .ntdelbutton").each(function() {
        ids[ids.length] = jQuery(this).attr("id");
    });
    for (i = 0; i < ids.length; i++) {
        jQuery("#" + ids[ids.length - i - 1]).click();
    }
}

function gdtt_check_taxonomy() {
    if (jQuery("#txOriginalText").val() != "") {
        jQuery("#linktax_panel #ttstatus").addClass("loading");
        jQuery.getJSON(ajaxurl, {
            action: 'gd_cpt_tinymce_check',
            tax: jQuery("#txTaxonomy").val(),
            term: jQuery("#txOriginalText").val(),
            autocreate: jQuery("#txAutoCheck").is(":checked") ? '1' : '0'},
            function(json) {
                jQuery("#linktax_panel #ttstatus").removeClass("loading");
                gdtt_taxonomy_loading(json);
            }
        );
    }
}

function gdtt_search_taxonomy() {
    if (jQuery("#txOriginalText").val() != "") {
        jQuery("#linktax_panel #ttstatus").addClass("loading");
        jQuery.getJSON(ajaxurl, {
            action: 'gd_cpt_tinymce_search',
            tax: jQuery("#txTaxonomy").val(),
            term: jQuery("#txOriginalText").val(),
            limit: jQuery("#txSearchLimit").val(),
            autocreate: jQuery("#txAutoCheck").is(":checked") ? '1' : '0'},
            function(json) {
                jQuery("#linktax_panel #ttstatus").removeClass("loading");
                gdtt_taxonomy_loading(json);
            }
        );
    }
}

function gdtt_add_taxonomy() {
    if (jQuery("#txOriginalText").val() != "") {
        jQuery("#linktax_panel #ttstatus").addClass("loading");
        jQuery.getJSON(ajaxurl, { 
            action: 'gd_cpt_tinymce_check', 
            tax: jQuery("#txTaxonomy").val(), 
            term: jQuery("#txOriginalText").val(), 
            create: '1'}, 
            function(json) {
                jQuery("#linktax_panel #ttstatus").removeClass("loading");
                gdtt_taxonomy_loading(json);
            }
        );
    }
}

function gdtt_taxonomy_loading(json) {
    var id = '#term' + json.result;

    jQuery("#termok").addClass("tthide");
    jQuery("#termoptions").addClass("tthide");
    jQuery("#termfound").addClass("tthide");
    jQuery("#termnotfound").addClass("tthide");
    jQuery("#gdtt-tinymce-insert").css("display", "none");

    if (json.result == "ok") {
        jQuery("#addsmode").val('check');
        jQuery("#taxonomy").val(json.taxonomy);

        jQuery("#termname").html(json.termname);
        jQuery("#termslug").html(json.termslug);
        jQuery("#termperm").html(json.permalink);
        jQuery("#gdtt-tinymce-insert").css("display", "block");
        jQuery("#termoptions").removeClass("tthide");
    } else if (json.result == "found") {
        jQuery("#addsmode").val('search');
        jQuery("#taxonomy").val(json.taxonomy);

        gdtt_show_found_terms(json.terms);
        jQuery("#termoptions").removeClass("tthide");
        jQuery("#gdtt-tinymce-insert").css("display", "block");
    }

    jQuery(id).removeClass("tthide");
}

function gdtt_show_found_terms(input) {
    searchResults = input;
    var terms = [];
    var i;
    for (i = 0; i < input.length; i++) {
        terms[i] = '<a id="fotr' + i +'" class="txsrterm" href="javascript:gdtt_sel_term(' + i +')">' + input[i].termname + '</a>';
    }
    jQuery("#foundterms").html(terms.join(", "));

    jQuery("#fotr0").addClass('selected');
    jQuery("#searchid").val(0);
}

function gdtt_sel_term(i) {
    jQuery(".txsrterm").removeClass('selected');
    jQuery("#fotr" + i).addClass('selected');
    jQuery("#searchid").val(i);
}

function gdtt_add_tax_term(id, term) {
    if (gdtt_tax_hierarchy[id] == 0) {
        parent.jQuery("#new-tag-" + id).val(term);
        parent.jQuery("#new-tag-" + id).next().click();
    } else {
        parent.jQuery("#" + id + "-add").show();
        parent.jQuery("#new" + id).val(term);
        parent.jQuery("#" + id + "-add-submit").click();
        parent.jQuery("#" + id + "-add").hide();
    }
}

function gdtt_insertTermBack() {
    var term = '';
    var perm = '';
    var slug = '';

    if (jQuery("#addsmode").val() == "search") {
        var i = jQuery("#searchid").val();
        term = searchResults[i].termname;
        perm = searchResults[i].permalink;
        slug = searchResults[i].termslug;
    } else if (jQuery("#addsmode").val() == "check") {
        term = jQuery("#termname").html();
        perm = jQuery("#termperm").html();
        slug = jQuery("#termslug").html();
    }

    var sel = jQuery("#txCntReplace").is(":checked") ? term : tinyMCEPopup.editor.selection.getContent({format : 'text'});
    if (jQuery("#txAddTerm").is(":checked")) {
        gdtt_add_tax_term(jQuery("#taxonomy").val(), term);
    }
    if (jQuery("#txCntHref").is(":checked")) {
        if (jQuery("#txUseShortcode").is(":checked")) {
            sel = "[termlink tax='" + jQuery("#txTaxonomy").val() + "' term='" + slug + "']" + sel + "[/termlink]";
        } else {
            sel = '<a href="' + perm + '">' + sel + '</a>';
        }
    }

    tinyMCEPopup.editor.execCommand('mceReplaceContent', false, sel);
    tinyMCEPopup.editor.execCommand('mceRepaint');
    tinyMCEPopup.close();
}

var gdCPTMeta = {
    tmp: {
      picker_id: ''  
    },
    init_various: function() {
        jQuery(".gdtt-field-number").numeric();
        jQuery(".gdtt-mb-holder .gdtt-cf-block:last").addClass("gdtt-no-line");

        jQuery(".gdtt-field-date").datepicker();
        jQuery('#ui-datepicker-div').wrap('<div class="gdtt-mb-holder"></div>');

        jQuery(".gdtt-ui-button span.ui-icon-image").live("click", function(){
            var gdtt_id = jQuery(this).attr("gdtt-id");
            var url = jQuery("#" + gdtt_id).val().trim();
            if (url !== "") {tb_show(gdttMetas.preview_title, gdttMetas.preview_url + "?img=" + encodeURIComponent(url) + "&TB_iframe=true");}
        });

        jQuery(".gdtt-ui-button span.ui-icon-folder-open").live("click", function(){
            gdtt_form_mediaupload_field = jQuery(this).attr('gdtt-id');
            gdtt_form_mediaupload_function = window.send_to_editor;
            tb_show(gdttMetas.select_title, "media-upload.php?type=image&amp;TB_iframe=true");
            window.send_to_editor = function(html) {
                var imgurl = jQuery(html).attr('href');
                jQuery("#" + gdtt_form_mediaupload_field).val(imgurl);
                tb_remove();
                window.send_to_editor = gdtt_form_mediaupload_function;
            };
            return false;
        });

        jQuery(".gdtt-ui-button span.ui-icon-contact").live("click", function(){
            var field = jQuery(this).attr("gdtt-field");
            var shortcode = '[cpt_field code="' + field + '" image="img"' + ']';
            tinymce.execInstanceCommand("content", "mceInsertContent", false, shortcode);
        });

        jQuery(".gdtt-ui-button span.ui-icon-script").live("click", function(){
            var field = jQuery(this).attr("gdtt-field");
            var shortcode = '[cpt_field code="' + field + '"]';
            tinymce.execInstanceCommand("content", "mceInsertContent", false, shortcode);
        });
    },
    init_colorpicker: function() {
        jQuery(".colorSelector").ColorPicker({
            onBeforeShow: function() {
                var id = jQuery(this).next("input").attr("id");
                gdCPTMeta.tmp.picker_id = id.substr(0, id.length - 6);
                jQuery(this).ColorPickerSetColor(jQuery(this).next("input").val());
            },
            onShow: function(cpc) {
                jQuery(cpc).fadeIn(500);
                return false;
            },
            onHide: function(cpc) {
                jQuery(cpc).fadeOut(500);
                return false;
            },
            onChange: function(hsb, hex, rgb) {
                var id = gdCPTMeta.tmp.picker_id;
                jQuery("#" + id + "_div div").css('backgroundColor', '#' + hex);
                jQuery("#" + id + "_input").val(hex);
            }
        });
        jQuery(".gdtt-field-colorpicker").each(function(idx){
            gdCPTMeta.change_colors(this);
        });
        jQuery(".gdtt-field-colorpicker").change(function(){
            gdCPTMeta.change_colors(this);
        });
    },
    init_tinymce: function() {
        jQuery("#gdtt-tinymce-insert").css("display", "none");
        jQuery("#gdtt-tinymce-insert").click(function(){
            gdtt_insertTermBack();
            return false;
        });

        jQuery("#gdtt-tinymce-cancel a").click(function(){
            tinyMCEPopup.close();
        });

        jQuery("#gdtt-internal-toggle").click(function(){
            if (jQuery(this).hasClass("toggle-arrow-on")) {
                jQuery(this).removeClass("toggle-arrow-on");
                jQuery("#setting_panel").slideUp();
            } else {
                jQuery(this).addClass("toggle-arrow-on");
                jQuery("#setting_panel").slideDown();
            }
        });
    },
    init_meta_tags: function() {
        jQuery(".gdtt-term-limited").change(function(){
            var tax = jQuery(this).attr("gdtt-taxonomy");
            var terms = [];
            jQuery(".gdtt-taxonomy-" + tax + ":checked").each(function(index) {
                terms[terms.length] = jQuery(this).val();
            });
            jQuery("#gdtt_tax_input_" + tax).val(terms.join(", "));
        });

        jQuery(".tagsdiv").each(function() {
            var id = jQuery(this).attr("id");
            gdtt_yahoo_done[id] = false;
            gdtt_yahoo_list[id] = [];
            gdtt_yahoo_apis[id] = [];

            if (gdttMetas.clear_tags == 1) {
                jQuery(this).next(".hide-if-no-js").append(' | <a href="javascript:gdtt_clear_tags(\'' + id + '\')" class="gdtt-clear-tags">' + gdttMetas.clear_all + '</a>');
            }

            if (gdttMetas.suggest_active > 0) {
                var suggest_append = "<br/>" + gdttMetas.suggest + ":<br/>";
                var suggests = [];
                if (gdttMetas.suggest_internal == 1) {
                    suggests.push('<a href="javascript:gdtt_yahoo_tags(\'' + id + '\', \'internal\')">' + gdttMetas.internal + '</a>');
                }
                if (gdttMetas.suggest_yahoo == 1) {
                    suggests.push('<a href="javascript:gdtt_yahoo_tags(\'' + id + '\', \'yahoo\')">Yahoo</a>');
                }
                if (gdttMetas.suggest_tagthe == 1) {
                    suggests.push('<a href="javascript:gdtt_yahoo_tags(\'' + id + '\', \'tagthe\')">TagThe</a>');
                }
                if (gdttMetas.suggest_alchemy == 1) {
                    suggests.push('<a href="javascript:gdtt_yahoo_tags(\'' + id + '\', \'alchemy\')">Alchemy</a>');
                }
                if (gdttMetas.suggest_opencalais == 1) {
                    suggests.push('<a href="javascript:gdtt_yahoo_tags(\'' + id + '\', \'opencalais\')">OpenCalais</a>');
                }
                if (gdttMetas.suggest_zemanta == 1) {
                    suggests.push('<a href="javascript:gdtt_yahoo_tags(\'' + id + '\', \'zemanta\')">Zemanta</a>');
                }

                jQuery(this).next(".hide-if-no-js").append(suggest_append + suggests.join(" | "));
            }

            jQuery(this).next(".hide-if-no-js").after('<div class="gdtt-yahoo-block" id="gdttyhsgs-' + id + '"></div>');
        });
    },
    init_chosen: function() {
        if (jQuery().chosen) {
            if (gdttMetas.chosen_select == "1") {
                jQuery(".gdtt-field-select.gdtt-chosen-select").chosen({allow_single_deselect: true});
            }
            if (gdttMetas.chosen_multi == "1") {
                jQuery(".gdtt-field-select.gdtt-chosen-multi").chosen({allow_single_deselect: true});
            }
        }
    },
    change_colors: function(obj) {
        var id = jQuery(obj).attr("id");
        id = id.substr(0, id.length - 6);
        jQuery("#" + id + "_div div").css("backgroundColor", "#" + jQuery(obj).val());
    }
};

jQuery(document).ready(function() {
    gdCPTMeta.init_colorpicker();
    gdCPTMeta.init_various();
    gdCPTMeta.init_tinymce();
    gdCPTMeta.init_meta_tags();
    gdCPTMeta.init_chosen();
});
