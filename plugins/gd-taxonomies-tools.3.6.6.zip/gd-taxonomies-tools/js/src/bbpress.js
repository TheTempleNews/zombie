/*jslint regexp: true, nomen: true, undef: true, sloppy: true, eqeq: true, vars: true, white: true, plusplus: true, maxerr: 50, indent: 4 */

jQuery(document).ready(function() {
    function change_colors(obj) {
        var id = jQuery(obj).attr("id");
        id = id.substr(0, id.length - 6);
        jQuery("#" + id + "_div div").css("backgroundColor", "#" + jQuery(obj).val());
    }

    var tempPickerID = "";
    jQuery(".colorSelector").ColorPicker({
        onBeforeShow: function() {
            var id = jQuery(this).next("input").attr("id");
            tempPickerID = id.substr(0, id.length - 6);
            jQuery(this).ColorPickerSetColor(jQuery(this).next("input").val());
        },
        onShow: function(cpc) {
            jQuery(cpc).fadeIn(500);
            return false;
        },
        onHide: function(cpc) {
            jQuery(cpc).fadeOut(500);
            return false;
        },
        onChange: function(hsb, hex, rgb) {
            var id = tempPickerID;
            jQuery("#" + id + "_div div").css('backgroundColor', '#' + hex);
            jQuery("#" + id + "_input").val(hex);
        }
    });
    jQuery(".gdtt-field-colorpicker").each(function(idx){
        change_colors(this);
    });
    jQuery(".gdtt-field-colorpicker").change(function(){
        change_colors(this);
    });

    jQuery(".gdtt-field-number").numeric();

    jQuery(".gdtt-field-date").datepicker();
    jQuery('#ui-datepicker-div').wrap('<div class="gdtt-mb-holder"></div>');
});
