<?php

/*
Name:    gdr2_DB
Version: 2.7.6.1
Author:  Milan Petrovic
Email:   milan@gdragon.info
Website: http://www.dev4press.com/libs/gdr2/

== Copyright ==
Copyright 2008 - 2012 Milan Petrovic (email: milan@gdragon.info)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

if (!class_exists("gdr2_Plugin_DB")) {
    class gdr2_Plugin_DB {
        public $plugin_prefix_db = 'gdr2';
        public $db_tables = array(
            'network' => array(),
            'site' => array()
        );
        public $statistics = array(
            'query' => 0, 'get_var' => 0, 'get_row' => 0,
            'get_results' => 0, 'insert' => 0, 'update' => 0
        );
        public $db;

        function __construct() {
            global $wpdb;

            $tables = array_merge($this->db_tables['network'], $this->db_tables['site']);
            $plugin = new gdrBase();
            $this->db = new gdrBase();

            foreach ($tables as $name) {
                $real_name = $wpdb->prefix.$this->plugin_prefix_db.'_'.$name;

                $plugin->$name = $real_name;
                $this->db->$name = $real_name;
            }

            $wpdb->{$this->plugin_prefix_db} = $plugin;
        }

        public function t($name) {
            return $this->db->$name;
        }

        public function query($query) {
            global $wpdb;
            $this->statistics['query']++;
            return $wpdb->query($query);
        }

        public function get_insert_id() {
            global $wpdb;
            return $wpdb->insert_id;
        }

        public function get_datetime($timestamp = null) {
            if (is_null($timestamp)) {
                $timestamp = time();
            }

            return date('Y-m-d H:i:s', $timestamp);
        }

        public function get_var($query, $x = 0, $y = 0) {
            global $wpdb;
            $this->statistics['get_var']++;
            return $wpdb->get_var($query, $x, $y);
        }

        public function get_row($query = null, $output = OBJECT, $y = 0) {
            global $wpdb;
            $this->statistics['get_row']++;
            return $wpdb->get_row($query, $output, $y);
        }

        public function get_results($query = null, $output = OBJECT) {
            global $wpdb;
            $this->statistics['get_results']++;
            return $wpdb->get_results($query, $output);
        }

        public function insert($table, $data, $format = null) {
            global $wpdb;
            $this->statistics['insert']++;
            return $wpdb->insert($this->t($table), $data, $format);
        }

        public function update( $table, $data, $where, $format = null, $where_format = null) {
            global $wpdb;
            $this->statistics['update']++;
            return $wpdb->update($this->t($table), $data, $where, $format, $where_format);
        }
    }
}

?>