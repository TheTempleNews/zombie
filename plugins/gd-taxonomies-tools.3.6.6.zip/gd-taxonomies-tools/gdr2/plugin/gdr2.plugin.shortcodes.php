<?php

/*
Name:    gdr2_Shortcodes
Version: 2.7.6.1
Author:  Milan Petrovic
Email:   milan@gdragon.info
Website: http://www.dev4press.com/libs/gdr2/

== Copyright ==
Copyright 2008 - 2012 Milan Petrovic (email: milan@gdragon.info)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

if (!class_exists('gdr2_Shortcodes')) {
    abstract class gdr2_Shortcodes {
        public $aliases = true;
        public $prefix = 'shortcode_';
        public $shortcodes = array();

        function __construct() {
            $data_defaults = array('name', 'args', 'atts', 'alias');

            $this->init();

            foreach ($this->shortcodes as $shortcode => $data) {
                $data = wp_parse_args($data, $data_defaults);
                add_shortcode($shortcode, array(&$this, $this->prefix.$shortcode));

                if ($this->aliases && !empty($data['alias'])) {
                    foreach ((array)$data['alias'] as $alias) {
                        add_shortcode($alias, array(&$this, $this->prefix.$shortcode));
                    }
                }
            }
        }

        public function atts($code, $atts) {
            return shortcode_atts($this->shortcodes[$code]['atts'], $atts);
        }

        public function _content($content) {
            if (substr($content, 0, 7) == "<p></p>") {
                $content = substr($content, 7);
            } else if (substr($content, 0, 4) == "</p>") {
                $content = substr($content, 4);
            } else if (substr($content, 0, 6) == "<br />") {
                $content = substr($content, 6);
            }

            if (substr($content, -7) == "<p></p>") {
                $content = substr($content, strlen($content) - 7);
            } else if (substr($content, -3) == "<p>") {
                $content = substr($content, 0, strlen($content) - 3);
            } else if (substr($content, -4) == "</p>") {
                $content = substr($content, 0, strlen($content) - 4);
            } else if (substr($content, -7) == "<br />") {
                $content = substr($content, 0, strlen($content) - 7);
            }

            $content = str_replace("<p></p>", "", $content);

            return trim($content);
        }

        abstract public function init();
    }
}

?>