<?php

$bbp_locations_topic = array(
    "bbp_theme_before_topic_form_title" => __("Notices", "gd-taxonomies-tools"),
    "bbp_theme_after_topic_form_title" => __("Title", "gd-taxonomies-tools"),
    "bbp_theme_after_topic_form_content" => __("Content", "gd-taxonomies-tools"),
    "bbp_theme_after_topic_form_tags" => __("Tags", "gd-taxonomies-tools"),
    "bbp_theme_before_topic_form_submit_wrapper" => __("Form", "gd-taxonomies-tools")
);
$bbp_locations_reply = array(
    "bbp_theme_before_topic_form_title" => __("Notices", "gd-taxonomies-tools"),
    "bbp_theme_after_reply_form_content" => __("Content", "gd-taxonomies-tools"),
    "bbp_theme_after_reply_form_tags" => __("Tags", "gd-taxonomies-tools"),
    "bbp_theme_before_reply_form_submit_wrapper" => __("Form", "gd-taxonomies-tools")
);
$bbp_boxes = array(
    "__none__" => __("Do not use any", "gd-taxonomies-tools")
);
foreach ($meta as $name => $box) {
    $fields_count = count($box->fields);
    $bbp_boxes[$name] = $box->name." (".$fields_count." "._n("field", "fields", $fields_count, "gd-taxonomies-tools").")";
}

?>
<?php if (isset($_GET['message']) && $_GET['message'] == "saved") { ?>
<div id="message" class="updated fade" style="background-color: rgb(255, 251, 204);"><p><strong><?php _e("Settings saved.", "gd-taxonomies-tools"); ?></strong></p></div>
<?php } ?>

<form method="post" action="">
<div id="tabs" class="gdtttabs gdtt-middle-tabs" style="width: 100%;">
    <ul>
        <li><a href="#integration"><?php _e("Integration", "gd-taxonomies-tools"); ?></a><div><?php _e("into WordPress panels", "gd-taxonomies-tools"); ?></div></li>
        <li><a href="#enhanced"><?php _e("Enhanced", "gd-taxonomies-tools"); ?></a><div><?php _e("plugin added features", "gd-taxonomies-tools"); ?></div></li>
        <li><a href="#metabox"><?php _e("Meta Boxes", "gd-taxonomies-tools"); ?></a><div><?php _e("integration and control", "gd-taxonomies-tools"); ?></div></li>
        <li><a href="#tagger"><?php _e("Tagger", "gd-taxonomies-tools"); ?></a><div><?php _e("API's access and settings", "gd-taxonomies-tools"); ?></div></li>
        <li><a href="#bbpress"><?php _e("bbPress", "gd-taxonomies-tools"); ?></a><div><?php _e("plugin integration", "gd-taxonomies-tools"); ?></div></li>
        <li><a href="#accessibility"><?php _e("Accessibility", "gd-taxonomies-tools"); ?></a><div><?php _e("and visual enhancements", "gd-taxonomies-tools"); ?></div></li>
    </ul>
    <div style="clear: both"></div>
    <div id="integration">
        <?php include GDTAXTOOLS_PATH."forms/settings/integration.php"; ?>
    </div>
    <div id="enhanced">
        <?php include GDTAXTOOLS_PATH."forms/settings/enhanced.php"; ?>
    </div>
    <div id="metabox">
        <?php include GDTAXTOOLS_PATH."forms/settings/metabox.php"; ?>
    </div>
    <div id="tagger">
        <?php include GDTAXTOOLS_PATH."forms/settings/tagger.php"; ?>
    </div>
    <div id="bbpress">
        <?php include GDTAXTOOLS_PATH."forms/settings/bbpress.php"; ?>
    </div>
    <div id="accessibility">
        <?php include GDTAXTOOLS_PATH."forms/settings/accessibility.php"; ?>
    </div>
</div>

<input type="submit" class="pressbutton" value="<?php _e("Save Settings", "gd-taxonomies-tools"); ?>" name="gdtt_saving" style="margin-top: 10px;" />
</form>
