<h3><?php _e("Function run to register this custom post type", "gd-taxonomies-tools"); ?>:</h3>
<div class="gdtt-func"><?php echo $f; ?></div>

<a class="pressbutton" style="margin-top: 10px;" href="admin.php?page=gdtaxtools_postypes&amp;cpt=1&amp;pid=<?php echo $_GET["pid"]; ?>&amp;action=edit"><?php _e("Edit Post Type", "gd-taxonomies-tools"); ?></a>
