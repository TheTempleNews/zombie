<div class="gdtt-mb-holder">
<?php if ($meta->description != "") { echo '<p class="gdtt-mb-description">'.__($meta->description).'</p>'; } ?>

<input type="hidden" name="<?php echo $_NAME ?>__nonce__][0]" value="<?php echo wp_create_nonce("gdcpttools"); ?>" />

<?php

do_action("gdcpt_metabox_".$meta->code."_header");

$use_wp_editor = GDTAXTOOLS_WPV > 32;
$done = $rich_editor = array();
foreach ($meta->fields as $f) {
    $field = $_F[$f];
    if (!isset($done[$f])) { $done[$f] = 0; } else { $done[$f]++; }

    $id = $_ID.$field->code."_".$done[$f];
    $name = $_NAME.$field->code."][".$done[$f]."]";
    $value = $values[$f][$done[$f]];

    echo '<div class="gdtt-cf-block'.($field->required ? " gdtt-required" : "").'">';
        do_action("gdcpt_metabox_".$meta->code."_field_header");
        do_action("gdcpt_metabox_".$meta->code."_field_header_".$field->code);
        echo '<div class="gdtt-cf-icons">';
            echo '<div class="gdtt-ui-button"><span gdtt-field="'.$f.'" title="'.__("Insert shortcode for this custom field.", "gd-taxonomies-tools").'" class="ui-icon ui-icon-script"></span></div>';
            if ($field->type == gdttCustomType::IMAGE) {
                echo '<div class="gdtt-ui-button"><span gdtt-id="'.$id.'" gdtt-field="'.$f.'" title="'.__("Insert advanced shortcode for this custom field.", "gd-taxonomies-tools").'" class="ui-icon ui-icon-contact"></span></div>';
                echo '<div class="gdtt-ui-button"><span gdtt-id="'.$id.'" gdtt-field="'.$f.'" title="'.__("Preview selected image.", "gd-taxonomies-tools").'" class="ui-icon ui-icon-image"></span></div>';
                echo '<div class="gdtt-ui-button"><span gdtt-id="'.$id.'" gdtt-field="'.$f.'" title="'.__("Select image from WP media library.", "gd-taxonomies-tools").'" class="ui-icon ui-icon-folder-open"></span></div>';
            }
        echo '</div>';
        echo '<label class="gdtt-label-'.$field->type.'" for="'.$id.'">'.__($field->name).($field->required ? " <span>(*)</span>" : "").':</label>';

        include(GDTAXTOOLS_PATH."forms/shared/meta.form.php");

        if ($field->description != "") { echo '<p class="gdtt-cf-description">'.__($field->description).'</p>'; }
        do_action("gdcpt_metabox_".$meta->code."_field_footer");
        do_action("gdcpt_metabox_".$meta->code."_field_footer_".$field->code);
    echo '</div>';

    do_action("gdcpt_metabox_".$meta->code."_field_after");
    do_action("gdcpt_metabox_".$meta->code."_field_after_".$field->code);
}

if (!empty($rich_editor) && !$use_wp_editor) {
    gdtt_embed_richeditor($rich_editor);
}

do_action("gdcpt_metabox_".$meta->code."_footer");

?>
</div>
