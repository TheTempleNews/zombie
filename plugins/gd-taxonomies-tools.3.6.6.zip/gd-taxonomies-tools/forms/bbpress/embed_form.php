<?php

do_action("gdcpt_metabox_".$meta->code."_header");

$use_wp_editor = GDTAXTOOLS_WPV > 32;

$done = array();
foreach ($meta->fields as $f) {
    $field = $_F[$f];

    if ($field->type != gdttCustomType::IMAGE) {
        if (!isset($done[$f])) { $done[$f] = 0; } else { $done[$f]++; }

        $id = $_ID.$field->code."_".$done[$f];
        $name = $_NAME.$field->code."][".$done[$f]."]";
        $value = isset($posted_values[$f][$done[$f]]) ? $posted_values[$f][$done[$f]] : "";

        echo '<div class="gdtt-field gdtt-field-'.$field->code.'"><label for="'.$id.'">';
            do_action("gdcpt_metabox_".$meta->code."_field_header");
            do_action("gdcpt_metabox_".$meta->code."_field_header_".$field->code);
            echo __($field->name).($field->required ? " <span>(*)</span>" : "");
            if ($field->description != "") {
                echo " - <em>".$field->description.'</em>';
            }
            echo ':</label><br/>';

            include(GDTAXTOOLS_PATH."forms/shared/meta.form.php");

            do_action("gdcpt_metabox_".$meta->code."_field_footer");
            do_action("gdcpt_metabox_".$meta->code."_field_footer_".$field->code);
        echo '</div>';

        do_action("gdcpt_metabox_".$meta->code."_field_after");
        do_action("gdcpt_metabox_".$meta->code."_field_after_".$field->code);
    }
}

do_action("gdcpt_metabox_".$meta->code."_footer");

?>