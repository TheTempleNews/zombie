<h3><?php _e("Function run to register this custom taxonomy", "gd-taxonomies-tools"); ?>:</h3>
<div class="gdtt-func"><?php echo $f; ?></div>

<a class="pressbutton" style="margin-top: 10px;" href="admin.php?page=gdtaxtools_taxs&amp;cpt=1&amp;tid=<?php echo $_GET["tid"]; ?>&amp;action=edit"><?php _e("Edit Taxonomy", "gd-taxonomies-tools"); ?></a>
