<?php

require_once(GDTAXTOOLS_PATH."gdr2/gdr2.ui.php");

$wppt = gdtt_get_public_post_types(true);
$post_types_list = array("__none__" => __("Select Post Type", "gd-taxonomies-tools"));
foreach ($wppt as $name => $obj) {
    $post_types_list[$name] = $obj->label;
}

$custom_fields_list = array("__none__" => __("Select Field", "gd-taxonomies-tools"));
foreach ($gdtt_meta["fields"] as $field => $obj) {
    $custom_fields_list[$field] = $obj->name." (".$obj->get_type().")";
}

$custom_functions_list = array("__none__" => __("Select Function", "gd-taxonomies-tools"));
$custom_functions_list = apply_filters("gdcpt_custom_field_function", $custom_functions_list);

$select_methods = array(
    'normal' => __("Normal List", "gd-taxonomies-tools"),
    'associative' => __("Associative List", "gd-taxonomies-tools"),
    'function' => __("Function", "gd-taxonomies-tools")
);

$selection_methods = array(
    'select' => __("Single Item / Select Control", "gd-taxonomies-tools"),
    'radio' => __("Single Item / Radio Control", "gd-taxonomies-tools"),
    'multi' => __("Multi Items / Select Control", "gd-taxonomies-tools"),
    'checkbox' => __("Multi Items / Checkbox Control", "gd-taxonomies-tools"),
);

$custom_meta_locations = array(
    "advanced" => __("Advanced", "gd-taxonomies-tools"),
    "normal" => __("Normal", "gd-taxonomies-tools"),
    "side" => __("Side", "gd-taxonomies-tools")
);

$custom_tax_values = array();
global $wp_taxonomies;
foreach ($wp_taxonomies as $taxonomy => $cnt) {
    $custom_tax_values[$taxonomy] = $cnt->labels->name;
}

$custom_fields_values = array(
    gdttCustomType::TEXT => __("Text", "gd-taxonomies-tools"),
    gdttCustomType::BOOLEAN => __("Boolean", "gd-taxonomies-tools"),
    gdttCustomType::NUMBER => __("Number", "gd-taxonomies-tools"),
    gdttCustomType::EDITOR => __("Rich Editor", "gd-taxonomies-tools"),
    gdttCustomType::HTML => __("HTML", "gd-taxonomies-tools"),
    gdttCustomType::COLOR => __("Color", "gd-taxonomies-tools"),
    gdttCustomType::LISTING => __("Listing", "gd-taxonomies-tools"),
    gdttCustomType::SELECT => __("Select", "gd-taxonomies-tools"),
    gdttCustomType::RESOLUTION => __("Resolution", "gd-taxonomies-tools"),
    gdttCustomType::DATE => __("Date", "gd-taxonomies-tools"),
    gdttCustomType::IMAGE => __("Image", "gd-taxonomies-tools"),
    gdttCustomType::TERM => __("Taxonomy Term", "gd-taxonomies-tools"),
    gdttCustomType::LINK => __("Email or Web Link", "gd-taxonomies-tools")
);

?>

<script type='text/javascript'>
    jQuery(document).ready(function() {
        jQuery("#gdttcfedit").dialog({ closeOnEscape: true, resizable: false,
            autoOpen: false, bgiframe: true, width: 480, modal: true, buttons: {
                '<?php _e("Save", "gd-taxonomies-tools"); ?>': function() { gdCPTAdmin.editor.add_field(); },
                '<?php _e("Cancel", "gd-taxonomies-tools"); ?>': function() { jQuery(this).dialog('close'); }
            }
        });
        jQuery("#gdttcfdelete").dialog({ closeOnEscape: true, resizable: false,
            autoOpen: false, bgiframe: true, width: 480, modal: true, buttons: {
                '<?php _e("Delete", "gd-taxonomies-tools"); ?>': function() { gdCPTAdmin.editor.delete_field(); },
                '<?php _e("Cancel", "gd-taxonomies-tools"); ?>': function() { jQuery(this).dialog('close'); }
            }
        });
        jQuery("#gdttmbdelete").dialog({ closeOnEscape: true, resizable: false,
            autoOpen: false, bgiframe: true, width: 480, modal: true, buttons: {
                '<?php _e("Delete", "gd-taxonomies-tools"); ?>': function() { gdCPTAdmin.editor.delete_metabox(); },
                '<?php _e("Cancel", "gd-taxonomies-tools"); ?>': function() { jQuery(this).dialog('close'); }
            }
        });
        jQuery("#gdttmbedit").dialog({ closeOnEscape: true, resizable: false,
            autoOpen: false, bgiframe: true, width: 480, modal: true, buttons: {
                '<?php _e("Save", "gd-taxonomies-tools"); ?>': function() { gdCPTAdmin.editor.add_metabox(); },
                '<?php _e("Cancel", "gd-taxonomies-tools"); ?>': function() { jQuery(this).dialog('close'); }
            }
        });
        jQuery("#gdttmbptypes").dialog({ closeOnEscape: true, resizable: false,
            autoOpen: false, bgiframe: true, width: 480, modal: true, buttons: {
                '<?php _e("Save", "gd-taxonomies-tools"); ?>': function() { gdCPTAdmin.editor.attach_posttypes(); },
                '<?php _e("Cancel", "gd-taxonomies-tools"); ?>': function() { jQuery(this).dialog('close'); }
            }
        });

        gdCPTAdmin.tmp.meta_boxes_count = <?php echo count($gdtt_meta["boxes"]); ?>;
        gdCPTAdmin.tmp.custom_fields_count = <?php echo count($gdtt_meta["fields"]); ?>;

        gdCPTAdmin.tmp.meta_boxes = <?php echo json_encode($gdtt_meta["boxes"]); ?>;
        gdCPTAdmin.tmp.post_types = <?php echo json_encode($post_types_list); ?>;
        gdCPTAdmin.tmp.post_types_map = <?php echo json_encode($gdtt_meta["map"]); ?>;
        gdCPTAdmin.tmp.custom_fields = <?php echo json_encode($gdtt_meta["fields"]); ?>;

        gdCPTAdmin.tpl.mbe_row = '<tr class="gdtt-mbrow-%CODE%"><td><strong>%CODE%</strong></td><td>%NAME%</td><td>%FIELDS%</td><td class="gdtt-post-types">%POST_TYPES%</td><td>%LOCATION%</td><td>%DESCRIPTION%</td><td style="width: 128px; text-align: right;"><a class="ttoption-edit gdtt-mbo-postypes" href="#%CODE%"><?php _e("post types", "gd-taxonomies-tools"); ?></a><br/><a class="ttoption-edit gdtt-mbo-edit" href="#%CODE%"><?php _e("edit", "gd-taxonomies-tools"); ?></a> | <a class="ttoption-del gdtt-mbo-delete" href="#%CODE%"><?php _e("delete", "gd-taxonomies-tools"); ?></a></td></tr>';
        gdCPTAdmin.tpl.cfe_row = '<tr class="gdtt-cfrow-%CODE%"><td><strong>%CODE%</strong></td><td>%NAME%</td><td>%TYPE%</td><td>%REQUIRED%</td><td>%VALUES%</td><td>%DESCRIPTION%</td><td style="width:64px; text-align: right;">%COUNTER%</td><td style="width:128px;text-align:right;"><a class="ttoption-edit gdtt-cfo-edit" href="#%CODE%"><?php _e("edit", "gd-taxonomies-tools"); ?></a> | <a class="ttoption-edit gdtt-cfo-copy" href="#%CODE%"><?php _e("copy", "gd-taxonomies-tools"); ?></a> | <a class="ttoption-del gdtt-cfo-delete" href="#%CODE%"><?php _e("delete", "gd-taxonomies-tools"); ?></a></td></tr>';

        gdCPTAdmin.editor.init();
    });
</script>
<div class="gdcpt-settings">
<form action="" id="gdcpt-settings-form" method="post">
    <div id="tabs" class="gdtt-wide-tabs" style="width: 99.4%;">
        <ul>
            <li><a href="#tabs-boxes"><?php _e("Meta Boxes", "gd-taxonomies-tools"); ?></a><div><?php _e("to use for post types", "gd-taxonomies-tools"); ?></div></li>
            <li><a href="#tabs-fields"><?php _e("Custom Fields", "gd-taxonomies-tools"); ?></a><div><?php _e("to use in the meta boxes", "gd-taxonomies-tools"); ?></div></li>
        </ul>
        <div id="tabs-boxes">
            <?php include GDTAXTOOLS_PATH."forms/meta/boxes.php"; ?>
        </div>
        <div id="tabs-fields">
            <?php include GDTAXTOOLS_PATH."forms/meta/fields.php"; ?>
        </div>
    </div>
</form>
</div>
