<table class="form-table"><tbody>
    <tr><th scope="row"><?php _e("Main Settings", "gd-taxonomies-tools"); ?></th>
        <td>
            <input type="checkbox" name="metabox_unique_fields" id="metabox_unique_fields"<?php if ($options["metabox_unique_fields"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="metabox_unique_fields"><?php _e("Allow only for unique fields in the single meta box (recommended).", "gd-taxonomies-tools"); ?></label>
            <br/>
            <input type="checkbox" name="metabox_remove_empty" id="metabox_remove_empty"<?php if ($options["metabox_remove_empty"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="metabox_remove_empty"><?php _e("Remove old meta element from the database if new value is empty.", "gd-taxonomies-tools"); ?></label>
            <div class="gdsr-table-split"></div>
            <input type="checkbox" name="metabox_preload_select" id="metabox_preload_select"<?php if ($options["metabox_preload_select"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="metabox_preload_select"><?php _e("Load pre defined set of functions to get data for Select custom field type.", "gd-taxonomies-tools"); ?></label>
        </td>
    </tr>
    <tr><th scope="row"><?php _e("Meta Rendering", "gd-taxonomies-tools"); ?></th>
        <td>
            <input type="checkbox" name="metabox_clean_title" id="metabox_clean_title"<?php if ($options["metabox_clean_title"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="metabox_clean_title"><?php _e("Display clean title for meta boxes with no plugin name as prefix.", "gd-taxonomies-tools"); ?></label>
        </td>
    </tr>
    <tr><th scope="row"><?php _e("Post Type Meta Box", "gd-taxonomies-tools"); ?></th>
        <td>
            <input type="checkbox" name="meta_post_type_change" id="meta_post_type_change"<?php if ($options["meta_post_type_change"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="meta_post_type_change"><?php _e("Add meta box allowing change of post type for posts.", "gd-taxonomies-tools"); ?></label>
        </td>
    </tr>
    <tr class="last-row"><th scope="row"><?php _e("Chosen Library", "gd-taxonomies-tools"); ?></th>
        <td>
            <input type="checkbox" name="load_chosen_meta" id="load_chosen_meta"<?php if ($options["load_chosen_meta"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="load_chosen_meta"><?php _e("Load chosen.js library on the post editor panels.", "gd-taxonomies-tools"); ?></label>
            <div class="gdsr-table-split"></div>
            <input type="checkbox" name="transform_chosen_single_meta" id="transform_chosen_single_meta"<?php if ($options["transform_chosen_single_meta"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="transform_chosen_single_meta"><?php _e("Apply Chosen transformation for single select control.", "gd-taxonomies-tools"); ?></label>
            <br/>
            <input type="checkbox" name="transform_chosen_multi_meta" id="transform_chosen_multi_meta"<?php if ($options["transform_chosen_multi_meta"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="transform_chosen_multi_meta"><?php _e("Apply Chosen transformation for multi select control.", "gd-taxonomies-tools"); ?></label>
        </td>
    </tr>
</tbody></table>