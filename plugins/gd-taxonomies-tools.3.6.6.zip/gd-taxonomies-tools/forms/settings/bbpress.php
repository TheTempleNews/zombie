<table class="form-table"><tbody>
    <tr><th scope="row"><?php _e("Active", "gd-taxonomies-tools"); ?></th>
        <td>
            <input type="checkbox" name="bbpress_active" id="cache_active"<?php if ($options["bbpress_active"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="bbpress_active"><?php _e("Enable integration with bbPress 2.0 forums", "gd-taxonomies-tools"); ?></label>
            <div class="gdsr-table-split"></div>
            <?php _e("When enable, plugin will allow assigining meta boxes to individual forums to expand the topic and reply forms with extra fields and data.", "gd-taxonomies-tools"); ?>
        </td>
    </tr>
    <tr><th scope="row"><?php _e("Default Meta Boxes", "gd-taxonomies-tools"); ?></th>
        <td>
            <table cellpadding="0" cellspacing="0" class="previewtable">
                <tr>
                    <td width="150"><?php _e("Topic", "gd-taxonomies-tools"); ?>:</td>
                    <td>
                        <select style="width: 200px" name="bbpress_metabox_topic" id="bbpress_metabox_topic">
                            <?php
                                foreach ($bbp_boxes as $key => $f_val) {
                                    $sel = $key == $options["bbpress_metabox_topic"] ? ' selected="selected"' : '';
                                    echo '<option value="'.__($key).'"'.$sel.'>'.__($f_val).'</option>';
                                }
                            ?>
                        </select> <?php _e("add after", "gd-taxonomies-tools"); ?> <select style="width: 200px" name="bbpress_metabox_location_topic" id="bbpress_metabox_location_topic">
                            <?php
                                foreach ($bbp_locations_topic as $key => $f_val) {
                                    $sel = $key == $options["bbpress_metabox_location_topic"] ? ' selected="selected"' : '';
                                    echo '<option value="'.__($key).'"'.$sel.'>'.__($f_val).'</option>';
                                }
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td width="150"><?php _e("Reply", "gd-taxonomies-tools"); ?>:</td>
                    <td>
                        <select style="width: 200px" name="bbpress_metabox_reply" id="bbpress_metabox_reply">
                            <?php
                                foreach ($bbp_boxes as $key => $f_val) {
                                    $sel = $key == $options["bbpress_metabox_reply"] ? ' selected="selected"' : '';
                                    echo '<option value="'.__($key).'"'.$sel.'>'.__($f_val).'</option>';
                                }
                            ?>
                        </select> <?php _e("add after", "gd-taxonomies-tools"); ?> <select style="width: 200px" name="bbpress_metabox_location_reply" id="bbpress_metabox_location_reply">
                            <?php
                                foreach ($bbp_locations_reply as $key => $f_val) {
                                    $sel = $key == $options["bbpress_metabox_location_reply"] ? ' selected="selected"' : '';
                                    echo '<option value="'.__($key).'"'.$sel.'>'.__($f_val).'</option>';
                                }
                            ?>
                        </select>
                    </td>
                </tr>
            </table>
            <div class="gdsr-table-split"></div>
            <?php _e("All forums will use these meta boxes if you don't change it for individual forums from their edit panels.", "gd-taxonomies-tools"); ?>
        </td>
    </tr>
    <tr><th scope="row"><?php _e("Integration", "gd-taxonomies-tools"); ?></th>
        <td>
            <input type="checkbox" name="bbpress_embed_active" id="bbpress_embed_active"<?php if ($options["bbpress_embed_active"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="bbpress_embed_active"><?php _e("Auto embed extra fields into the topics and replies", "gd-taxonomies-tools"); ?></label>
            <br/>
            <input type="checkbox" name="bbpress_embed_author" id="bbpress_embed_active"<?php if ($options["bbpress_embed_author"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="bbpress_embed_author"><?php _e("Topic or reply author will be able to see embedded data", "gd-taxonomies-tools"); ?></label>
            <br/>
            <input type="checkbox" name="bbpress_embed_anyone" id="bbpress_embed_anyone"<?php if ($options["bbpress_embed_anyone"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="bbpress_embed_anyone"><?php _e("Anyone will be able to see embedded data", "gd-taxonomies-tools"); ?></label>
            <div class="gdsr-table-split"></div>
            <table cellpadding="0" cellspacing="0" class="previewtable">
                <tr>
                    <td style="width: 140px; padding-right: 10px; vertical-align: top;"><?php _e("User roles that will be able to see embedded data", "gd-taxonomies-tools"); ?>:</td>
                    <td>
                        <?php foreach ($wp_roles->role_names as $role => $title) { ?>
                        <label for="bbpress_embed_roles_<?php echo $role; ?>">
                            <input type="checkbox" <?php if (!isset($options["bbpress_embed_roles"]) || is_null($options["bbpress_embed_roles"]) || in_array($role, $options["bbpress_embed_roles"])) echo " checked"; ?> value="<?php echo $role; ?>" id="bbpress_embed_roles_<?php echo $role; ?>" name="bbpress_embed_roles[]" />
                            <?php echo $title; ?>
                        </label><br/>
                        <?php } ?>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr class="last-row"><th scope="row"><?php _e("Styling and JavaScript", "gd-taxonomies-tools"); ?></th>
        <td>
            <input type="checkbox" name="bbpress_embed_js" id="bbpress_embed_js"<?php if ($options["bbpress_embed_js"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="bbpress_embed_js"><?php _e("Embed additional JavaScript for forum pages", "gd-taxonomies-tools"); ?></label>
            <br/>
            <input type="checkbox" name="bbpress_embed_css" id="bbpress_embed_css"<?php if ($options["bbpress_embed_css"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="bbpress_embed_css"><?php _e("Embed default styling CSS classes for forum pages", "gd-taxonomies-tools"); ?></label>
            <div class="gdsr-table-split"></div>
            <?php _e("Additional jQueryUI powered code used by some of the control. It will be added to footer.", "gd-taxonomies-tools"); ?><br/>
            <?php _e("Default CSS will be added to page header. If you want to include your own styling, you can disable this option.", "gd-taxonomies-tools"); ?>
        </td>
    </tr>
</tbody></table>