<div class="copyright">
    Plugin Website: <a style="font-weight: bold;" href="http://www.gdcpttools.com/" target="_blank">GD Custom Posts And Taxonomies Tools</a><br/><br/>

    More from Dev4Press: <a href="http://www.gdpc.me/" target="_blank">GD Products Center</a> |
    <a href="http://www.dev4press.com/gd-press-tools/" target="_blank">GD Press Tools</a> |
    <a href="http://www.gdaffiliatecenter.com/" target="_blank">GD Affiliate Center</a> |
    <a href="http://www.dev4press.com/plugins/gd-azon-fusion/" target="_blank">GD aZon FUSION</a> |
    <a href="http://www.gdstarrating.com/" target="_blank">GD Star Rating</a> |
    <a href="http://www.dev4press.com/themes/" target="_blank">xScape Themes</a>
    <div class="dev4press">Dev4Press &copy; 2008 - 2011 <a href="http://www.dev4press.com" target="_blank">www.dev4press.com</a></div>
</div>
