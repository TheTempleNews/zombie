<div class="contextual-help">
    <div class="help-info">
        <?php _e("To get additional help with GD Custom Posts And Taxonomies Tools, check out the resources available on Dev4Press website.", "gd-taxonomies-tools"); ?>
    </div>
    <div class="help-more">
        <h4><?php _e("General Resources", "gd-taxonomies-tools"); ?></h4>
        <a href="http://www.dev4press.com/forums/" target="_blank">
            <?php _e("Support Forum", "gd-taxonomies-tools"); ?>
        </a><br/>
        <a href="http://www.dev4press.com/documentation/" target="_blank">
            <?php _e("Documentation", "gd-taxonomies-tools"); ?>
        </a><br/>
        <a href="http://www.dev4press.com/category/tutorials/" target="_blank">
            <?php _e("Tutorials", "gd-taxonomies-tools"); ?>
        </a><br/>
    </div>
    <div class="help-block">
        <h4><?php _e("General Information", "gd-taxonomies-tools"); ?></h4>
        <a href="http://www.dev4press.com/plugin/gd-taxonomies-tools/" target="_blank">
            <?php _e("Plugin Home Page", "gd-taxonomies-tools"); ?>
        </a><br/>
        <a href="http://www.dev4press.com/forums/forum/plugins/gd-taxonomies-tools/" target="_blank">
            <?php _e("Support Forum", "gd-taxonomies-tools"); ?>
        </a><br/>
    </div>
    <div class="help-block">
        <h4><?php _e("Documentation &amp; Tutorials", "gd-taxonomies-tools"); ?></h4>
        <a href="http://www.dev4press.com/documentation/product/plg-gd-taxonomies-tools/" target="_blank">
            <?php _e("Documentation", "gd-taxonomies-tools"); ?>
        </a><br/>
        <a href="http://www.dev4press.com/category/tutorials/plugins/gd-taxonomies-tools/" target="_blank">
            <?php _e("Tutorials", "gd-taxonomies-tools"); ?>
        </a><br/>
    </div>
    <div class="help-main">
        <h4><?php _e("Panel specific tutorials", "gd-taxonomies-tools"); ?></h4>
        <?php

        foreach ($this->tutorials as $tut) {
            if (in_array($gdsr_page, $tut["panels"])) {
                echo '<div style="">';
                echo '<a class="gdsr-icon-tutorial gdsr-icon-tutorial-'.$tut["icon"].'" href="http://www.dev4press.com/?p='.$tut["id"].'" target="_blank">'.$tut["title"].'</a>';
                echo '</div>';
            }
        }

        ?>
    </div>
    <div class="clear"></div>
</div>