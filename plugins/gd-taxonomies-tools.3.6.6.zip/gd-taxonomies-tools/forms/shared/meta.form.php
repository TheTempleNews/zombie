<?php

switch ($field->type) {
    default:
    case gdttCustomType::TEXT:
        echo '<input class="gdtt-field-text" type="text" id="'.$id.'" name="'.$name.'" value="'.__($value).'" />';
        break;
    case gdttCustomType::RESOLUTION:
        $value = $field->val_resolution($value);

        echo '<span class="gdtt-field-resname">x:</span>';
        echo '<input class="gdtt-field-numberres" type="text" id="'.$id.'_x" name="'.$name.'[x]" value="'.$value['x'].'" />';
        echo '<span class="gdtt-field-respxls">'.__("pixels", "gd-taxonomies-tools").'</span>';
        echo '<span class="gdtt-field-resname">y:</span>';
        echo '<input class="gdtt-field-numberres" type="text" id="'.$id.'_y" name="'.$name.'[y]" value="'.$value['y'].'" />';
        echo '<span class="gdtt-field-respxls">'.__("pixels", "gd-taxonomies-tools").'</span>';
        break;
    case gdttCustomType::LINK:
        echo '<input class="gdtt-field-link" type="text" id="'.$id.'" name="'.$name.'" value="'.__($value).'" />';
        break;
    case gdttCustomType::BOOLEAN:
        echo '<input class="gdtt-field-boolean" type="checkbox" id="'.$id.'" name="'.$name.'"'.($value == "1" ? " checked" : "").' />';
        break;
    case gdttCustomType::DATE:
        echo '<input class="gdtt-field-date" type="text" id="'.$id.'" name="'.$name.'" value="'.$value.'" />';
        break;
    case gdttCustomType::COLOR:
        echo '<div id="'.$id.'_div" class="colorSelector"><div class="xs-back" style="background-color: #000000"></div></div>';
        echo '<input class="gdtt-field-colorpicker" type="text" name="'.$name.'" id="'.$id.'_input" value="'.$value.'" />';
        break;
    case gdttCustomType::TERM:
        $args = array("id" => $id, "name" => $name, "selected" => $value, "taxonomy" => $field->values, "show_option_none" => __("Select term from the list", "gd-taxonomies-tools"), "hierarchical" => 1);
        wp_dropdown_categories($args);
        break;
    case gdttCustomType::HTML:
        echo '<textarea class="gdtt-field-html" id="'.$id.'" name="'.$name.'">'.esc_html($value).'</textarea>';
        break;
    case gdttCustomType::EDITOR:
        if ($use_wp_editor) {
            wp_editor(gdr2_entity_decode($value), $id, 
                    array("dfw" => false,
                        "textarea_name" => $name, 
                        "css" => "css-'.$name.'",
                        "teeny" => false,
                        "textarea_rows" => 10
                    ));
        } else {
            echo '<textarea class="gdpc-field-editor" id="'.$id.'" name="'.$name.'">'.esc_html($value).'</textarea>';
            $rich_editor[] = $id;
        }
        break;
    case gdttCustomType::LISTING:
        echo '<textarea class="gdtt-field-html" id="'.$id.'" name="'.$name.'">'.join("\n", (array)$value).'</textarea>';
        break;
    case gdttCustomType::NUMBER:
        echo '<input class="gdtt-field-number" type="text" id="'.$id.'" name="'.$name.'" value="'.$value.'" />';
        break;
    case gdttCustomType::IMAGE:
        echo '<input class="gdtt-field-image" type="text" id="'.$id.'" name="'.$name.'" value="'.$value.'" />';
        break;
    case gdttCustomType::SELECT:
        $value = (array)$value;
        $p_values = $field->get_select_values();
        $multiple = '';
        $real_name = $name;

        if ($field->selection == 'multi' || $field->selection == 'checkbox') {
            $multiple = ' multiple="multiple"';
            $real_name.= '[]';
        }

        switch ($field->selection) {
            case 'multi':
            case 'select':
                echo '<select class="gdtt-field-select gdtt-chosen-'.$field->selection.'" name="'.$real_name.'" id="'.$id.'"'.$multiple.'>';
                echo '<option value=""> </option>';
                foreach ($p_values as $f_val => $f_cap) {
                    $sel = in_array($f_val, $value) ? ' selected="selected"' : (in_array($f_cap, $value) ? ' selected="selected"' : '');
                    echo '<option value="'.$f_val.'"'.$sel.'>'.__($f_cap).'</option>';
                }
                echo '</select>';
                break;
            case 'radio':
                foreach ($p_values as $f_val => $f_cap) {
                    $sel = in_array($f_val, $value) ? ' checked' : (in_array($f_cap, $value) ? ' checked' : '');
                    echo '<div class="gdtt-single-select-value"><input class="gdtt-field-boolean" type="radio" id="'.$id.'" value="'.$f_val.'" name="'.$name.'"'.$sel.' /> <span>'.__($f_cap).'</span></div>';
                }
                break;
                break;
            case 'checkbox':
                foreach ($p_values as $f_val => $f_cap) {
                    $sel = in_array($f_val, $value) ? ' checked' : (in_array($f_cap, $value) ? ' checked' : '');
                    echo '<div class="gdtt-single-select-value"><input class="gdtt-field-boolean" type="checkbox" id="'.$id.'" value="'.$f_val.'" name="'.$real_name.'"'.$sel.' /> <span>'.__($f_cap).'</span></div>';
                }
                break;
        }
        break;
}

?>