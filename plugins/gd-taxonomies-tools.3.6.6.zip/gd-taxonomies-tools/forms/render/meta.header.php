<table class="widefat">
    <thead>
        <tr>
            <th scope="col" style="white-space: nowrap;"><?php _e("Label", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 10%;"><?php _e("Name", "gd-taxonomies-tools"); ?></th>
            <th scope="col"><?php _e("Taxonomies", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 15%;text-align: center;"><?php _e("Public / UI", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 5%;text-align: center;"><?php _e("Menu", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 10%; text-align: center;"><?php _e("Hierarchical", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 60px; text-align: right;"><?php _e("Items", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 20%; text-align: right;"><?php _e("Options", "gd-taxonomies-tools"); ?></th>
        </tr>
    </thead>
    <tbody>

<?php $tr_class = ""; ?>
