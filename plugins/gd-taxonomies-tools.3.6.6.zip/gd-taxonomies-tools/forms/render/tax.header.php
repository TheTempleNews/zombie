<table class="widefat">
    <thead>
        <tr>
            <th scope="col" style="white-space: nowrap;"><?php _e("Name", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 18%; text-align: left;"><?php _e("Rewrite & Query", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 18%; text-align: left;"><?php _e("Post Types", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 18%; text-align: left;"><?php _e("Settings", "gd-taxonomies-tools"); ?></th>
            <th scope="col" style="width: 5%; text-align: right;"><?php _e("Terms", "gd-taxonomies-tools"); ?></th>
        </tr>
    </thead>
    <tbody>

<?php $tr_class = ""; ?>
