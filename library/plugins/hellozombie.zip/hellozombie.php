<?php
/**
 * @package Hello_Zombie
 * @version 1.6
 */
/*
Plugin Name: Hello Zombie
Plugin URI: http://www.temple.edu
Description: This is not just a plugin, it symbolizes the despair and uncertainty of an entire generation summed up in two words you never want to hear: Hello, Zombie. When activated you will randomly see a lyric from <cite>Zombie</cite> or a line from <cite>Dawn of the Dead</cite> in the upper right of your admin screen on every page.
Author: Chris Montgomery
Version: 1.0

Based on Matt Mullenweg's <cite>Hello Dolly</cite> plugin (obviously).
*/

function hello_zombie_get_lyric() {
	/** These are the lyrics to Zombie */
	$lyrics = "Zombie o, zombie
Zombie o, zombie
Zombie no go go, unless you tell am to go
Zombie no go stop, unless you tell am to stop
Zombie no go turn, unless you tell am to turn
Zombie no go think, unless you tell am to think
Tell am to go straight
A joro, jara, joro
No break, no job, no sense
A joro, jara, joro
Tell am to go kill
A joro, jara, joro
No break, no job, no sense
A joro, jara, joro
Tell am to go quench
A joro, jara, joro
No break, no job, no sense
A joro, jara, joro
Go and kill! (Joro, jaro, joro)
Go and die! (Joro, jaro, joro)
Go and quench! (Joro, jaro, joro)
Put am for reverse! (Joro, jaro, joro)
Joro, jara, joro, zombie wey na one way
Joro, jara, joro, zombie wey na one way
Joro, jara, joro, zombie wey na one way
Joro, jara, joro
Attention!
Quick march!
Slow march!
Left turn!
Right turn!
About turn!
Double up!
Salute!
Open your hat!
Stand at ease!
Fall in!
Fall out!
Fall down!
Get ready!
Halt!
Order!
Dismiss!";

/** These are some lines from Dawn of the Dead **/
$lyrics .= "
What are they doing? Why do they come here?
Some kind of instinct.
Memory of what they used to do.
This was an important place in their lives. 
When the dead walk, señores, we must stop the killing... or lose the war.
Dummies! Dummies! Dummies!
This is down to the line, folks, this is down to the line.
There can be no more divisions among the living!
They're us, that's all, when there's no more room in hell.
What the hell are they?
When there's no more room in hell, the dead will walk the Earth.
They kill for one reason: they kill for food.
Intelligence?
Seemingly little or no reasoning power, but basic skills remain and more remembered behaviors from normal life.
There are reports of these creatures using tools.
These creatures are nothing but pure, motorized instinct.
People aren't willing to accept your solutions, doctor, and I for one don't blame them!
We've got to survive! Somebody's got to survive!
If they're anything like Philly, we may never get out alive.
Now it would be crazy to start shooting at each other.
You're hypnotized by this place. All of you!
You never point a gun at anyone, mister. Scary, isn't it?
Fat city, brother! How do we work it?
It's Christmastime down there, buddy!
Get that guy off the air!
Why don't we drop bombs on all the big cities?
We have to remain rational. We have to remain logical.";

	// Here we split it into lines
	$lyrics = explode( "\n", $lyrics );

	// And then randomly choose a line
	return wptexturize( $lyrics[ mt_rand( 0, count( $lyrics ) - 1 ) ] );
}

// This just echoes the chosen line, we'll position it later
function hello_zombie() {
	$chosen = hello_zombie_get_lyric();
	echo "<p id='dolly'>$chosen</p>";
}

// Now we set that function up to execute when the admin_notices action is called
add_action( 'admin_notices', 'hello_zombie' );

// We need some CSS to position the paragraph
function hello_zombie_css() {
	// This makes sure that the positioning is also good for right-to-left languages
	$x = is_rtl() ? 'left' : 'right';

	echo "
	<style type='text/css'>
	#dolly {
		float: $x;
		padding-$x: 15px;
		padding-top: 5px;		
		margin: 0;
		font-size: 11px;
	}
	</style>
	";
}

add_action( 'admin_head', 'hello_zombie_css' );

?>
