=== Dev4Press Updater ===
Version: 1.8.7
Requires at least: 3.0
Tested up to: 3.4
Stable tag: trunk

Dev4Press Updater is a plugin for performing the updates of the Dev4Press Pro plugins and xScape Pro themes, including beta and nightly releases, directly from WordPress.

== Requirements ==
= WordPress =
* WordPress 3.x

= PHP =
* PHP 5.x

== Installation ==
= Standard Installation =
* Plugin folder in the WordPress plugins folder must be `dev4press-updater`.
* Upload folder `dev4press-updater` to the `/wp-content/plugins/` directory.
* Activate the plugin through the 'Plugins' menu in WordPress.

= WordPress Multisite Installation =
* Activate it only as network wide
