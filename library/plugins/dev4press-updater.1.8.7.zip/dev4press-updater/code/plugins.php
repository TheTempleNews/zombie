<?php

if (!defined("DEV4UPDATER_LOG_PATH")) define("DEV4UPDATER_LOG_PATH", dirname(dirname(__FILE__))."/log.txt");
if (!defined("DEV4UPDATER_DEBUG_PATH")) define("DEV4UPDATER_DEBUG_PATH", dirname(dirname(__FILE__))."/debug.txt");
if (!defined("DEV4UPDATER_DEBUG_ACTIVE")) define("DEV4UPDATER_DEBUG_ACTIVE", true);

class gdDebugD4PU {
    var $log_file;
    var $active = false;

    function gdDebugD4PU($log_url = '') {
        $this->log_file = $log_url;

        if ($this->log_file != '') {
            if (file_exists($this->log_file) && is_writable($this->log_file)) {
                $this->active = true;
            }
        }
    }

    function truncate() {
        $f = fopen($this->log_file, "w+");
        fclose($f);
    }

    function prepare_array($info) {
        $wr = "";
        foreach ($info as $name => $value) {
            $wr.= $name.": ".$value."\r\n";
        }
        return $wr;
    }

    function log($msg, $info, $mode = "a+") {
        if ($this->active) {
            $info = $this->prepare_array($info);
            $f = fopen($this->log_file, $mode);
            fwrite ($f, sprintf("[%s] : %s\r\n", date('Y-m-d h:i:s'), $msg));
            fwrite ($f, "$info");
            fwrite ($f, "\r\n");
            fclose($f);
        }
    }

    function dump($msg, $object, $block = "none", $mode = "a+") {
        if ($this->active) {
            $obj = print_r($object, true);
            $f = fopen($this->log_file, $mode);
            if ($block == "start")
                fwrite ($f, "-- DUMP BLOCK STARTED ---------------------------------- \r\n");
            fwrite ($f, sprintf("[%s] : %s\r\n", date('Y-m-d h:i:s'), $msg));
            fwrite ($f, "$obj");
            fwrite ($f, "\r\n");
            if ($block == "end")
                fwrite ($f, "-------------------------------------------------------- \r\n");
            fclose($f);
        }
    }
}

$d4pu_log = new gdDebugD4PU(DEV4UPDATER_LOG_PATH);
$d4pu_debug = new gdDebugD4PU(DEV4UPDATER_DEBUG_PATH);

function dev4upd_dump($msg, $obj, $block = "none", $mode = "a+") {
    if (DEV4UPDATER_DEBUG_ACTIVE) {
        global $d4pu_debug;
        $d4pu_debug->dump($msg, $obj, $block, $mode);
    }
}

function dev4upd_log($msg, $obj, $block = "none", $mode = "a+") {
    global $d4pu_log;
    $d4pu_log->dump($msg, $obj, $block, $mode);
}

class dev4UPDThemes {
    var $themes;

    function dev4UPDThemes() { }
}

class dev4UPDPlugins {
    var $plugins = array(
        "dev4press-updater/dev4press-updater.php" => array(
            "options" => "dev4press-updater", 
            "method" => "classic"),
        "gd-bbpress-attachments/gd-bbpress-attachments.php" => array(
            "options" => "gd-bbpress-attachments", 
            "method" => "classic"),
        "gd-bbpress-tools/gd-bbpress-tools.php" => array(
            "options" => "gd-bbpress-tools", 
            "method" => "classic"),
        "gd-bbpress-widgets/gd-bbpress-widgets.php" => array(
            "options" => "gd-bbpress-widgets", 
            "method" => "classic"),
        "gd-bbpress-toolbox/gd-bbpress-toolbox.php" => array(
            "options" => "gd-bbpress-settings", 
            "method" => "gdr2"),
        "gd-headspace4/headspace.php" => array(
            "options" => "gd-headspace4", 
            "method" => "load"),
        "gd-content-tools/gd-content-tools.php" => array(
            "options" => "gd-content-tools", 
            "method" => "gdr2"),
        "gd-press-tools/gd-press-tools.php" => array(
            "options" => "gd-press-tools", 
            "method" => "classic"),
        "gd-products-center/gd-products-center.php" => array(
            "options" => "gd-products-center-settings", 
            "method" => "gdr2"),
        "gd-linkedin-badge/gd-linkedin-badge.php" => array(
            "options" => "", 
            "method" => "none"),
        "gd-pages-navigator/gd-pages-navigator.php" => array(
            "options" => "", 
            "method" => "none"),
        "gd-unit-converter/gd-unit-converter.php" => array(
            "options" => "", 
            "method" => "none"),
        "gd-azon-fusion/gd-azon-fusion.php" => array(
            "options" => "gd-azon-fusion", 
            "method" => "classic"),
        "gd-simple-widgets/gd-simple-widgets.php" => array(
            "options" => "gd-simple-widgets", 
            "method" => "classic"),
        "gd-taxonomies-tools/gd-taxonomies-tools.php" => array(
            "options" => "gd-taxonomy-tools", 
            "method" => "classic"),
        "gd-affiliate-center/gd-affiliate-center.php" => array(
            "options" => "gd-affiliate-center", 
            "method" => "classic"),
        "gd-star-rating/gd-star-rating.php" => array(
            "options" => "gd-star-rating", 
            "method" => "classic")
    );

    function dev4UPDPlugins() { }
}

class dev4Updater {
    var $api_key;
    var $home_url;
    var $wordpress;
    var $plugins;
    var $themes;
    var $core_themes;
    var $status;
    var $response;

    function dev4Updater($plugins, $themes, $key, $status = "stable") {
        global $wp_version;

        $this->plugins = array();
        $this->api_key = $key;
        $this->home_url = get_bloginfo("url");
        $this->wordpress = $wp_version;
        $this->status = $status;
        $this->response = "";

        $this->process_plugins($plugins);
        $this->process_themes($themes);
    }

    function post($url, $data) {
        global $wp_version;
        $options = array("timeout" => 30, "body" => $data, "method" => "POST",
            "user-agent" => "WordPress/".$wp_version."; ".get_bloginfo("url")
        );

        return wp_remote_post($url, $options);
    }

    function update($url) {
        global $wp_version;

        if ($this->api_key != "") {
            $debug = dev4upd_get("debug_level");

            $body = array(
                "api_key" => $this->api_key, "home_url" => $this->home_url,
                "wordpress" => $this->wordpress, "status" => $this->status,
                "plugins" => $this->plugins, "themes" => $this->themes,
                "core_themes" => $this->core_themes);

            if ($debug == "full" || $debug == "requests") {
                dev4upd_dump("REMOTE_POST_REQUEST_DATA", $body);
            }

            $options = serialize($body);
            if ($debug == "full" || $debug == "requests") {
                dev4upd_dump("REMOTE_POST_REQUEST_RAW", $options);
            }

            $raw = $this->post($url, $options);

            if ($debug == "full" || $debug == "responses") {
                dev4upd_dump("REMOTE_POST_RESPONSE_RAW", $raw);
            }

            if (is_wp_error($raw)) {
                dev4upd_log("REMOTE_POST_ERROR", $raw);
                $this->response = "remote_error";
            } else if ($raw["response"]["code"] == 200) {
                $this->response = unserialize($raw["body"]);

                if ($debug == "full" || $debug == "responses") {
                    dev4upd_dump("REMOTE_POST_RESPONSE_DATA", $this->response);
                }
            }
        }

        return $this->response;
    }

    function process_plugins($plugins) {
        foreach ($plugins as $plugin => $value) {
            $this->plugins[$plugin] = $value["settings"];
        }
    }

    function process_themes($themes) {
        foreach ($themes["pro"] as $theme => $value) {
            $this->themes[$theme] = $value["settings"];
            $this->themes[$theme]["xscape"] = $value["xscape"]["build"];
        }

        foreach ($themes["core"] as $theme => $value) {
            $this->core_themes[$theme] = $value["settings"];
            $this->core_themes[$theme]["xscape"] = 0;
        }
    }
}

function dev4upd_update_print($update) {
    $upd = array();

    $count = $update["summary"]["plugins"];
    if ($count > 0) {
        $ux = $count." ";
        $ux.= _n("plugin", "plugins", $count, "dev4press-updater");
        $upd[] = $ux;
    }
    $count = $update["summary"]["themes"] + $update["summary"]["xscape"];
    if ($count > 0) {
        $ux = $count." ";
        $ux.= _n("theme", "themes", $count, "dev4press-updater");
        $upd[] = $ux;
    }
    $count = $update["summary"]["core_themes"];
    if ($count > 0) {
        $ux = $count." ";
        $ux.= _n("core theme", "core themes", $count, "dev4press-updater");
        $upd[] = $ux;
    }

    $updates = join(", ", $upd);

    return sprintf(__("Updates available for %s, click to %s.", "dev4press-updater"), $updates, sprintf(' <a href="%s">%s</a>', network_admin_url("admin.php?page=dev4press_updater"), __("update", "dev4press-updater")));
}

function dev4upd_remove_cron($hook) {
    $crons = _get_cron_array();

    if (!empty($crons)) {
        $save = false;
        foreach ($crons as $timestamp => $cron) {
            if (isset($cron[$hook])) {
                unset($crons[$timestamp][$hook]);
                $save = true;

                if (empty($crons[$timestamp])) {
                    unset($crons[$timestamp]);
                }
            }
        }

        if ($save) {
            _set_cron_array($crons);
        }
    }
}

if (!function_exists("wp_redirect_self")) {
    function wp_redirect_self() {
        wp_redirect($_SERVER['REQUEST_URI']);
    }
}

if (!function_exists("network_admin_url")) {
    function network_admin_url($path = '', $scheme = 'admin') {
        return admin_url($path, $scheme);
    }
}

if (!function_exists("is_multisite")) {
    function is_multisite() {
        return false;
    }
}

?>