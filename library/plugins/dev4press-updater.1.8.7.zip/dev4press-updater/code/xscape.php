<?php

if (!class_exists('xScape_ThemeInfo')) {
    class xScape_ThemeInfo {
        var $name;
        var $title;
        var $version;
        var $edition;
        var $build;
        var $date;
        var $status;
        var $design_author;
        var $design_url;

        function xScape_ThemeInfo() { }
    }
}

if (!class_exists('xScape_Info')) {
    class xScape_Info {
        var $version;
        var $build;
        var $edition;
        var $date;
        var $status;

        function xScape_Info() { }
    }
}
?>