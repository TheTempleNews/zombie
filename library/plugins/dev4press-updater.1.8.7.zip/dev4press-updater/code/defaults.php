<?php

class dev4UPDDefaults {
    var $default_options = array(
        'version' => '1.8.7',
        'date' => '2012.05.27.',
        'build' => 892,
        'status' => 'Stable',
        'product_id' => 'dev4press-updater',
        'revision' => 0,
        'edition' => 'pro',
        'dev4press_api_key' => '',
        'update_status' => 'stable',
        'force_run_onload' => 0,
        'managewp_support' => 1,
        'right_now_active' => 1,
        'adminbar_active' => 1,
        'admin_notice_active' => 0,
        'debug_level' => 'none'
    );

    var $settings_names = array('version', 'date', 'status', 'product_id', 'revision', 'build', 'edition');
    var $updater_url = 'http://www.dev4press.com/wp-content/plugins/gd-product-central/updater.php';

    function dev4UPDDefaults() { }
}

?>