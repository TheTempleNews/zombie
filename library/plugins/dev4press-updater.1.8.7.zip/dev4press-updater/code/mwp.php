<?php

class d4pu_ManageWP {
    function __construct() {
        add_filter('mwp_premium_update_check', array(&$this, 'mwp_premium_update_check'));
        add_filter('mwp_premium_update_notification', array(&$this, 'mwp_premium_update_notification'));
        add_filter('mwp_premium_perform_update', array(&$this, 'mwp_premium_perform_update'));
    }

    public function mwp_premium_update_check($update) {
        if (!function_exists('get_plugin_data')) {
            include_once( ABSPATH.'wp-admin/includes/plugin.php');
        }

        $d4p_updater = get_plugin_data(DEV4UPDATER_PATH.'dev4press-updater.php');
        $d4p_updater['callback'] = 'd4pu_run_update_check';

        array_push($update, $d4p_updater);
        return $update;
    }

    public function mwp_premium_update_notification($premium_updates) {
        if (!function_exists('get_plugin_data')) {
            include_once( ABSPATH.'wp-admin/includes/plugin.php');
        }

        global $d4pu;
        $update = $d4pu->u;
        $d4p_updater = array();

        if (isset($update['plugins']) && is_array($update['plugins'])) {
            foreach ($update['plugins'] as $key => $data) {
                foreach ($data as $status => $value) {
                    if ($status == 'beta' || $status == 'nightly' || $status == 'stable') {
                        $d4p_updater = get_plugin_data(trailingslashit(WP_PLUGIN_DIR).$key);
                        $d4p_updater['new_version'] = $value->version;
                        $d4p_updater['type'] = 'plugin';

                        array_push($premium_updates, $d4p_updater);
                        break;
                    }
                }
            }
        }

        if (isset($update['themes']) && is_array($update['themes'])) {
            foreach ($update['themes'] as $key => $data) {
                foreach ($data as $status => $value) {
                    if ($status == 'beta' || $status == 'nightly' || $status == 'stable') {
                        $d4p_updater = get_theme_data(WP_CONTENT_DIR.'/themes/'.$key.'/style.css');
                        $d4p_updater['new_version'] = $value->version;
                        $d4p_updater['type'] = 'theme';

                        array_push($premium_updates, $d4p_updater);
                        break;
                    }
                }
            }
        }

        if (isset($update['core_themes']) && is_array($update['core_themes'])) {
            foreach ($update['core_themes'] as $key => $data) {
                foreach ($data as $status => $value) {
                    if ($status == 'beta' || $status == 'nightly' || $status == 'stable') {
                        $d4p_updater = get_theme_data(WP_CONTENT_DIR.'/themes/'.$key.'/style.css');
                        $d4p_updater['new_version'] = $value->version;
                        $d4p_updater['type'] = 'theme';

                        array_push($premium_updates, $d4p_updater);
                        break;
                    }
                }
            }
        }

        return $premium_updates;
    }

    public function mwp_premium_perform_update($premium_updates) {
        if (!function_exists('get_plugin_data')) {
            include_once( ABSPATH.'wp-admin/includes/plugin.php');
        }

        global $d4pu;
        $update = $d4pu->u;
        $d4p_updater = array();

        if (isset($update['plugins']) && is_array($update['plugins'])) {
            foreach ($update['plugins'] as $key => $data) {
                foreach ($data as $status => $value) {
                    if ($status == 'beta' || $status == 'nightly' || $status == 'stable') {
                        $d4p_updater = get_plugin_data(trailingslashit(WP_PLUGIN_DIR).$key);
                        $d4p_updater['url'] = $d4pu->get_package_download_url($value->id, $d4pu->o['dev4press_api_key'], 'plugin');
                        $d4p_updater['type'] = 'plugin';

                        array_push($premium_updates, $d4p_updater);
                        break;
                    }
                }
            }
        }

        if (isset($update['themes']) && is_array($update['themes'])) {
            foreach ($update['themes'] as $key => $data) {
                foreach ($data as $status => $value) {
                    if ($status == 'beta' || $status == 'nightly' || $status == 'stable') {
                        $d4p_updater = get_theme_data(WP_CONTENT_DIR.'/themes/'.$key.'/style.css');
                        $d4p_updater['url'] = $d4pu->get_package_download_url($value->id, $d4pu->o['dev4press_api_key'], 'theme');
                        $d4p_updater['type'] = 'theme';

                        array_push($premium_updates, $d4p_updater);
                        break;
                    }
                }
            }
        }

        if (isset($update['core_themes']) && is_array($update['core_themes'])) {
            foreach ($update['core_themes'] as $key => $data) {
                foreach ($data as $status => $value) {
                    if ($status == 'beta' || $status == 'nightly' || $status == 'stable') {
                        $d4p_updater = get_theme_data(WP_CONTENT_DIR.'/themes/'.$key.'/style.css');
                        $d4p_updater['url'] = $d4pu->get_package_download_url($value->id, $d4pu->o['dev4press_api_key'], 'theme');
                        $d4p_updater['type'] = 'theme';

                        array_push($premium_updates, $d4p_updater);
                        break;
                    }
                }
            }
        }

        return $premium_updates;
    }
}

?>