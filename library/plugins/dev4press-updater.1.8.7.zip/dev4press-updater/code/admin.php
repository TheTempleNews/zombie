<?php

class d4PU_Admin {
    var $l;

    var $admin_plugin;
    var $admin_plugin_page;

    var $page_ids = array();
    var $tutorials = array();

    function __construct() {
        global $d4pu;

        if (!is_multisite() || DEV4UPDATER_WPV < 31) {
            add_action('admin_menu', array(&$this, 'admin_menu'));
            add_action('admin_notices', array(&$this, 'admin_notice_apikey'));

            if ($d4pu->get('right_now_active') == 1) {
                add_action('rightnow_end', array(&$this, 'rightnow_end'));
            }

            if ($d4pu->get('admin_notice_active') == 1) {
                add_action('admin_notices', array(&$this, 'admin_notice_update'));
            }
        } else {
            add_action('network_admin_menu', array(&$this, 'admin_menu'));
            add_action('network_admin_notices', array(&$this, 'admin_notice_apikey'));
            add_action('admin_notices', array(&$this, 'admin_notice_apikey'));

            if ($d4pu->get('right_now_active') == 1) {
                add_action('mu_rightnow_end', array(&$this, 'rightnow_end'));
            }

            if ($d4pu->get('admin_notice_active') == 1) {
                add_action('network_admin_notices', array(&$this, 'admin_notice_update'));
                add_action('admin_notices', array(&$this, 'admin_notice_update'));
            }
        }

        add_action('init', array(&$this, 'init'));

        add_action('admin_init', array(&$this, 'admin_init'));
        add_action('admin_head', array(&$this, 'admin_head'));
        add_filter('plugin_row_meta', array(&$this, 'plugin_row_meta'), 10, 2);

        if (DEV4UPDATER_WPV < 33) {
            add_filter('contextual_help', array(&$this, 'contextual_help'));
        }
    }

    function _tutorials() {
        $this->tutorials = array(
            array('id' => 4725, 'icon' => 'video',
                'title' => __("Using Dev4Press Updater Plugin", "dev4press-updater"),
                'panels' => array('updater', 'installer', 'settings'))
            );
    }

    function save_option($name, $type = 'text') {
        global $d4pu;

        if ($type == 'checkbox') {
            $d4pu->o[$name] = isset($_POST[$name]) ? 1 : 0;
        }

        if ($type == 'text') {
            $d4pu->o[$name] = strip_tags($_POST[$name]);
        }
    }

    function admin_head() {
        if ($this->admin_plugin) {

            echo('<link rel="stylesheet" href="'.DEV4UPDATER_URL.'css/admin_main.css" type="text/css" media="screen" />');
        }

        echo '<style type="text/css">';
        echo '.dev4upd-msg {padding: 5px 10px !important}';
        echo '</style>';
    }

    function admin_init() {
        if (isset($_GET["page"])) {
            if (substr($_GET["page"], 0, 9) == "dev4press") {
                $this->admin_plugin = true;
                $this->admin_plugin_page = substr($_GET["page"], 10);
            }
        }

        if ($this->admin_plugin) {
            global $d4pu;

            if (isset($_GET["action"]) && $_GET["action"] == "runcheck") {
                $d4pu->update_check();

                wp_redirect("admin.php?page=dev4press_updater");
                exit;
            } else if ($d4pu->u == "" || $d4pu->o["force_run_onload"] == 1) {
                $d4pu->update_check();
            }

            if (isset($_POST["dev4press_saving"])) {
                check_admin_referer("dev4press-updater-settings");

                $this->save_option("dev4press_api_key");
                $this->save_option("update_status");
                $this->save_option("debug_level");
                $this->save_option("right_now_active", "checkbox");
                $this->save_option("admin_notice_active", "checkbox");
                $this->save_option("managewp_support", "checkbox");

                update_site_option("dev4press-updater", $d4pu->o);
                wp_redirect(add_query_arg("settings", "saved"));
                exit;
            }
        }
    }

    function contextual_help($text) {
        if ($this->admin_plugin) {
            $this->_tutorials();
            $panel = $this->admin_plugin_page;

            ob_start();
            include(DEV4UPDATER_PATH."forms/context.php");
            return ob_get_clean();
        } else {
            return $text;
        }
    }

    function plugin_row_meta($links, $file) {
        if ($file == plugin_basename(__FILE__)) {
            $links[] = '<a href="'.network_admin_url("admin.php?page=dev4press_settings").'">'.__("Settings", "dev4press-updater").'</a>';
            $links[] = '<a href="'.network_admin_url("admin.php?page=dev4press_updater").'">'.__("Run Updater", "dev4press-updater").'</a>';
        }
        return $links;
    }

    function init() {
        load_plugin_textdomain('dev4press-updater', false, 'dev4press-updater/languages/');
    }

    function rightnow_end() {
        global $d4pu;

        $update = $d4pu->u;
        include(DEV4UPDATER_PATH."forms/rightnow.php");
    }

    function admin_notice_update() {
        global $d4pu;

        if (current_user_can("dev4press_updater") && $d4pu->update_found()) {
            echo '<div class="dev4upd-msg updated"><strong>Dev4Press:</strong> ';
            echo dev4upd_update_print($d4pu->u);
            echo '</div>';
        }
    }

    function admin_notice_apikey() {
        global $d4pu;

        if (current_user_can("dev4press_updater") && $d4pu->o["dev4press_api_key"] == "") {
            echo '<div class="dev4upd-msg error">';
            echo sprintf(__("Dev4Press Updater needs to be set properly. Please go to the %s plugin settings</strong></a> to enter valid Dev4Press API Key.", "dev4press-updater"), '<a href="'.network_admin_url('admin.php?page=dev4press_settings').'"><strong>');
            echo '</div>';
        }
    }

    function admin_menu() {
        global $d4pu;

        if (!is_super_admin()) return;

        $menu_count = $d4pu->menu_count();

        $this->page_ids[] = add_menu_page('Dev4Press', 'Dev4Press'.$menu_count, 'dev4press_updater', 'dev4press_updater', array(&$this, 'menu_updater'), DEV4UPDATER_URL.'gfx/menu.png');
        $this->page_ids[] = add_submenu_page('dev4press_updater', __("Dev4Press Installed Products", "dev4press-updater"), __("Installed", "dev4press-updater"), 'dev4press_updater', 'dev4press_updater', array(&$this, 'menu_updater'));
        $this->page_ids[] = add_submenu_page('dev4press_updater', __("Dev4Press Install New Product", "dev4press-updater"), __("Install New", "dev4press-updater"), 'dev4press_updater', 'dev4press_installer', array(&$this, 'menu_installer'));
        $this->page_ids[] = add_submenu_page('dev4press_updater', __("Dev4Press Check for Products Updates", "dev4press-updater"), __("Run Check", "dev4press-updater"), 'dev4press_updater', 'dev4press_updater&action=runcheck', array(&$this, 'menu_updater'));
        $this->page_ids[] = add_submenu_page('dev4press_updater', __("Dev4Press Updater Settings", "dev4press-updater"), __("Settings", "dev4press-updater"), 'dev4press_updater', 'dev4press_settings', array(&$this, 'menu_settings'));

        $this->admin_load_hooks();
    }

    function admin_load_hooks() {
        if (DEV4UPDATER_WPV < 33) return;

        foreach ($this->page_ids as $id) {
            add_action("load-".$id, array(&$this, "load_admin_page"));
        }
    }

    function load_admin_page() {
        $screen = get_current_screen();
        $page_id = $screen->id == "toplevel_page_dev4press_updater" ? "updater" : substr($screen->id, 25);
        $this->_tutorials();

        $screen->set_help_sidebar('<p><strong>Dev4Press:</strong></p>
            <p><a target="_blank" href="http://www.dev4press.com/">'.__("Website", "dev4press-updater").'</a></p>
            <p><a target="_blank" href="http://twitter.com/dev4press">'.__("On Twitter", "dev4press-updater").'</a></p>
            <p><a target="_blank" href="http://facebook.com/dev4press">'.__("On Facebook", "dev4press-updater").'</a></p>');

        $counter = 0;
        $tutorials = "";
        foreach ($this->tutorials as $tut) {
            if (in_array($page_id, $tut["panels"])) {
                $tutorials.= '<a class="gdsr-icon-tutorial gdsr-icon-tutorial-'.$tut["icon"].'" href="http://www.dev4press.com/?p='.$tut["id"].'" target="_blank">'.$tut["title"].'</a>';
                $counter++;
            }
        }

        if ($counter == 0) {
            $tutorials.= '<p>'.__("Nothing found.", "dev4press-updater").'</p>';
        }

        $screen->add_help_tab(array(
            "id" => "gdpt-screenhelp-tutorials",
            "title" => __("Tutorials", "dev4press-updater"),
            "content" => '<h5>'.__("Panel specific tutorials", "dev4press-updater").'</h5>'.$tutorials));

        $screen->add_help_tab(array(
            "id" => "gdpt-screenhelp-website",
            "title" => "Dev4Press", "sfc",
            "content" => '<p>'.__("On Dev4Press website you can find many useful plugins, themes and tutorials, all for WordPress. Please, take a few minutes to browse some of these resources, you might find some of them very useful.", "dev4press-updater").'</p>
                <p><a href="http://www.dev4press.com/plugins/" target="_blank"><strong>'.__("Plugins", "dev4press-updater").'</strong></a> - '.__("We have more than 10 plugins available, some of them are commercial and some are available for free.", "dev4press-updater").'</p>
                <p><a href="http://www.dev4press.com/themes/" target="_blank"><strong>'.__("Themes", "dev4press-updater").'</strong></a> - '.__("All our themes are based on our own xScape Theme Framework, and only available as premium.", "dev4press-updater").'</p>
                <p><a href="http://www.dev4press.com/category/tutorials/" target="_blank"><strong>'.__("Tutorials", "dev4press-updater").'</strong></a> - '.__("Premium and free tutorials for our plugins themes, and many general and practical WordPress tutorials.", "dev4press-updater").'</p>
                <p><a href="http://www.dev4press.com/documentation/" target="_blank"><strong>'.__("Central Documentation", "dev4press-updater").'</strong></a> - '.__("Growing collection of functions, classes, hooks, constants with examples for our plugins and themes.", "dev4press-updater").'</p>
                <p><a href="http://www.dev4press.com/forums/" target="_blank"><strong>'.__("Support Forums", "dev4press-updater").'</strong></a> - '.__("Premium support forum for all with valid licenses to get help. Also, report bugs and leave suggestions.", "dev4press-updater").'</p>'));
    }

    function menu_updater() {
        global $d4pu;

        if ($d4pu->o["dev4press_api_key"] == "") {
            $header = array(array(__("Error", "dev4press-updater"), "#"));
            include(DEV4UPDATER_PATH.'forms/shared/all.header.php');
            include(DEV4UPDATER_PATH."forms/nokey.php");
            include(DEV4UPDATER_PATH.'forms/shared/all.footer.php');
        } else {
            $options = $d4pu->o;

            if (isset($_GET["install"])) {
                check_ajax_referer("dev4press");

                $this->install_package();
            } else if (isset($_POST["d4p_update"])) {
                check_ajax_referer("dev4press");

                $this->bulk_installer();
            } else {
                $update = $d4pu->u;
                $dev4press_plugins = $d4pu->get_plugins();
                $dev4press_all_themes = $d4pu->get_themes();

                $header = array(array(__("Installed Plugins and Themes", "dev4press-updater"), "#"));
                include(DEV4UPDATER_PATH."forms/shared/all.header.php");
                include(DEV4UPDATER_PATH."forms/status.php");
                include(DEV4UPDATER_PATH."forms/shared/all.footer.php");
            }
        }
    }

    function menu_installer() {
        global $d4pu;

        if ($d4pu->o["dev4press_api_key"] == "") {
            $header = array(array(__("Error", "dev4press-updater"), "#"));
            include(DEV4UPDATER_PATH."forms/shared/all.header.php");
            include(DEV4UPDATER_PATH."forms/nokey.php");
            include(DEV4UPDATER_PATH."forms/shared/all.footer.php");
        } else {
            $options = $d4pu->o;

            if (isset($_GET["install"])) {
                check_ajax_referer("dev4press");

                $this->install_package();
            } else if (isset($_POST["d4p_install"])) {
                check_ajax_referer("dev4press");

                $this->bulk_installer();
            } else {
                $update = $d4pu->u;

                $header = array(array(__("Install new Plugins and Themes", "dev4press-updater"), "#"));
                include(DEV4UPDATER_PATH."forms/shared/all.header.php");
                include(DEV4UPDATER_PATH."forms/new.php");
                include(DEV4UPDATER_PATH."forms/shared/all.footer.php");
            }
        }
    }

    function menu_settings() {
        global $d4pu;

        $options = $d4pu->o;

        $header = array(array(__("Settings", "dev4press-updater"), "#"));
        include(DEV4UPDATER_PATH."forms/shared/all.header.php");
        include(DEV4UPDATER_PATH."forms/settings.php");
        include(DEV4UPDATER_PATH."forms/shared/all.footer.php");
    }

    function install_package() {
        global $d4pu;

        $operation = $_GET["do"];
        $to_update = $_GET["update"];
        $id = $_GET["install"];

        $product = isset($_GET["product"]) ? $_GET["product"] : "generic";
        $package = $d4pu->get_package_download_url($id, $d4pu->o["dev4press_api_key"], $to_update);

        $box = array(
            $to_update => array(array("id" => $id, "product" => $product, "url" => $package))
        );

        $upd = $d4pu->u;
        $box = $d4pu->package_processor($box, $upd, $operation);

        $header = array(array(__("Installer Progress", "dev4press-updater"), "#"));
        include(DEV4UPDATER_PATH."forms/shared/all.header.php");
        include(DEV4UPDATER_PATH."forms/installer.php");
        include(DEV4UPDATER_PATH."forms/shared/all.footer.php");

        $d4pu->o["force_run_onload"] = 1;
        update_site_option('dev4press-updater', $d4pu->o);
    }

    function bulk_installer() {
        global $d4pu;

        $operation = $_POST["do"] == "install-new" ? "new" : "update";
        $box = array("plugin" => array(), "theme" => array(), "core_theme" => array(), "xscape" => array());

        foreach ($_POST["update"] as $type => $list) {
            foreach ($list as $product => $id) {
                $package = $d4pu->get_package_download_url($id, $d4pu->o["dev4press_api_key"], $type);
                $box[$type][] = array("id" => $id, "product" => $product, "url" => $package);
            }
        }

        $upd = $d4pu->u;
        $box = $d4pu->package_processor($box, $upd, $operation);

        $header = array(array(__("Installer Progress", "dev4press-updater"), "#"));
        include(DEV4UPDATER_PATH."forms/shared/all.header.php");
        include(DEV4UPDATER_PATH."forms/installer.php");
        include(DEV4UPDATER_PATH."forms/shared/all.footer.php");

        $d4pu->o["force_run_onload"] = 1;
        update_site_option('dev4press-updater', $d4pu->o);
    }
}

?>