<?php

class xScape_Upgrader extends Theme_Upgrader {
    function install_package($args = array()) {
        global $wp_filesystem;
        $defaults = array('source' => '', 'destination' => '',
                          'clear_destination' => false,
                          'clear_working' => false,
                          'hook_extra' => array()
                    );

        $args = wp_parse_args($args, $defaults);
        extract($args);

        @set_time_limit( 300 );

        if ( empty($source) || empty($destination) ) return new WP_Error('bad_request', $this->strings['bad_request']);

        $this->skin->feedback('installing_package');

        $res = apply_filters('upgrader_pre_install', true, $hook_extra);
        if ( is_wp_error($res) ) return $res;

        $remote_source = $source;
        $local_destination = $destination;

        $source_files = array_keys( $wp_filesystem->dirlist($remote_source) );
        $remote_destination = $wp_filesystem->find_folder($local_destination);
        $remote_destination = trailingslashit($remote_destination);

        if ( 1 == count($source_files) && $wp_filesystem->is_dir( trailingslashit($source) . $source_files[0] . '/') ) //Only one folder? Then we want its contents.
            $source = trailingslashit($source) . trailingslashit($source_files[0]);
        elseif ( count($source_files) == 0 )
            return new WP_Error('bad_package', $this->strings['bad_package']);

        //Protection against deleting files in any important base directories.
        if ( in_array( $destination, array(ABSPATH, WP_CONTENT_DIR, WP_PLUGIN_DIR, WP_CONTENT_DIR . '/themes') ) ) {
            $remote_destination = $remote_destination . trailingslashit(basename($source));
            $destination = trailingslashit($destination) . trailingslashit(basename($source));
        }

        if ( $wp_filesystem->exists($remote_destination) ) {
            if ( $clear_destination ) {
                //We're going to clear the destination if theres something there
                $this->skin->feedback('remove_old');
                $removed = $wp_filesystem->delete($remote_destination."xscape", true);
                $removed = $wp_filesystem->delete($remote_destination."extend", true);

                if ( is_wp_error($removed) ) return $removed;
                else if ( ! $removed ) return new WP_Error('remove_old_failed', $this->strings['remove_old_failed']);
            }
        }

        // Copy new version of item into place.
        $result = copy_dir($source, $remote_destination);
        if ( is_wp_error($result) ) {
            if ( $clear_working ) $wp_filesystem->delete($remote_source, true);
            return $result;
        }

        //Clear the Working folder?
        if ( $clear_working ) $wp_filesystem->delete($remote_source, true);

        $destination_name = basename( str_replace($local_destination, '', $destination) );
        if ( '.' == $destination_name ) $destination_name = '';

        $this->result = compact('local_source', 'source', 'source_name', 'source_files', 'destination', 'destination_name', 'local_destination', 'remote_destination', 'clear_destination', 'delete_source_dir');

        $res = apply_filters('upgrader_post_install', true, $hook_extra, $this->result);
        if ( is_wp_error($res) ) {
            $this->result = $res;
            return $res;
        }

        return $this->result;
    }
}

?>