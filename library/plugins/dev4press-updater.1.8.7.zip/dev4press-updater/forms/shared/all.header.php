<div class="wrap gdsr">
    <div class="logo"></div>
    <div class="header">
        <?php

        $breadcrumb = array();
        foreach ($header as $h) {
            if ($h[1] == "#") $h[1] = $_SERVER['REQUEST_URI'];
            if (!isset($h[2])) $h[2] = '';
            if (!isset($h[3])) {
                $h[3] = '';
            } else {
                $h[3] = ' qtip-content="'.$h[3].'"';
            }
            $breadcrumb[] = '<a'.$h[3].' class="'.$h[2].'" href="'.$h[1].'">'.$h[0].'</a>';
        }
        echo join("<span>|</span>", $breadcrumb);

        ?>
    </div>
