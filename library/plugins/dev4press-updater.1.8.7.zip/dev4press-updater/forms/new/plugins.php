<table class="widefat" cellspacing="0">
    <thead>
        <tr>
            <th scope="col" class="manage-column" style="width: 35%;"><?php _e("Plugin Details and Actions", "dev4press-updater"); ?></th>
            <th scope="col" class="manage-column"><?php _e("Description and Update info", "dev4press-updater"); ?></th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th scope="col" class="manage-column" style="width: 35%;"><?php _e("Plugin Details and Actions", "dev4press-updater"); ?></th>
            <th scope="col" class="manage-column"><?php _e("Description and Update info", "dev4press-updater"); ?></th>
        </tr>
    </tfoot>
    <tbody class="plugins">

    <?php foreach ($plugins as $plugin) { ?>
        <tr class="active">
            <td class='plugin-title'>
                <h4><?php echo $plugin->name; ?></h4>
                <p>
                    <strong><?php _e("Version", "dev4press-updater"); ?>:</strong> <?php echo $plugin->version; ?>
                    <?php echo " (".$plugin->build.")"; ?><br />
                    <strong><?php _e("Plugin Home", "dev4press-updater"); ?>:</strong> <a target="_blank" href="http://www.dev4press.com/plugins/<?php echo $plugin->group; ?>/" title="<?php __("Visit plugin homepage", "dev4press-updater"); ?>"><?php _e("Visit", "dev4press-updater"); ?></a>
                </p>
            </td>
            <td class='desc'>
                <p><?php echo $plugin->description; ?></p>
                <div class="plugin-left-line"></div>
                <?php
                    if (current_user_can('update_plugins')) {
                        $url = 'admin.php?page=dev4press_installer&update=plugin&do=new&_wpnonce='.wp_create_nonce("dev4press");
                        echo '<a style="float: right" href="'.$url.'&product='.$plugin->group.'&install='.$plugin->id.'">'.__("install now", "dev4press-updater").'</a>';
                        echo '<label><input type="checkbox" name="update[plugin]['.$plugin->group.']" value="'.$plugin->id.'" style="margin-right: 5px" />'.__("to installation queue", "dev4press-updater").'</label>';
                    }

                ?>
            </td>
        </tr>
    <?php } ?>

    </tbody>
</table>
