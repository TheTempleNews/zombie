<table class="widefat" cellspacing="0">
    <thead>
        <tr>
            <th scope="col" class="manage-column" style="width: 35%;"><?php _e("Themes Details and Actions", "dev4press-updater"); ?></th>
            <th scope="col" class="manage-column"><?php _e("Description and Update info", "dev4press-updater"); ?></th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th scope="col" class="manage-column" style="width: 35%;"><?php _e("Themes Details and Actions", "dev4press-updater"); ?></th>
            <th scope="col" class="manage-column"><?php _e("Description and Update info", "dev4press-updater"); ?></th>
        </tr>
    </tfoot>
    <tbody class="plugins">

    <?php foreach ($themes as $theme) { ?>
        <tr class="active">
            <td class='plugin-title'>
                <h4><?php echo $theme->name; ?></h4>
                <p>
                    <strong><?php _e("Version", "dev4press-updater"); ?>:</strong> <?php echo $theme->version; ?>
                    <?php echo " (".$theme->build.")"; ?><br />
                    <strong><?php _e("Theme Home", "dev4press-updater"); ?>:</strong> <a target="_blank" href="http://www.dev4press.com/themes/<?php echo $theme->group; ?>/" title="<?php __("Visit theme homepage", "dev4press-updater"); ?>"><?php _e("Visit", "dev4press-updater"); ?></a>
                </p>
            </td>
            <td class='desc'>
                <p><?php echo $theme->description; ?></p>
                <div class="plugin-left-line"></div>
                <?php
                    if (current_user_can('update_plugins')) {
                        $url = 'admin.php?page=dev4press_installer&update='.$update_type.'&do=new&_wpnonce='.wp_create_nonce("dev4press");
                        echo '<a style="float: right" href="'.$url.'&product='.$theme->group.'&install='.$theme->id.'">'.__("install now", "dev4press-updater").'</a>';
                        echo '<label><input type="checkbox" name="update['.$update_type.']['.$theme->group.']" value="'.$theme->id.'" style="margin-right: 5px" />'.__("to installation queue", "dev4press-updater").'</label>';
                    }

                ?>
            </td>
        </tr>
    <?php } ?>

    </tbody>
</table>
