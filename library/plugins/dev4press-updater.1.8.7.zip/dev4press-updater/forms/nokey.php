<?php
    _e("API Key is requied for the Updater to work. Go to the Settings page and enter valid API Key.", "dev4press-updater");
    
?>