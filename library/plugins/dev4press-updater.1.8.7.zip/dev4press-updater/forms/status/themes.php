<table class="widefat" cellspacing="0">
    <thead>
        <tr>
            <th scope="col" class="manage-column" style="width: 35%;"><?php _e("Theme Details and Actions", "dev4press-updater"); ?></th>
            <th scope="col" class="manage-column"><?php _e("Description and Update info", "dev4press-updater"); ?></th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th scope="col" class="manage-column" style="width: 35%;"><?php _e("Theme Details and Actions", "dev4press-updater"); ?></th>
            <th scope="col" class="manage-column"><?php _e("Description and Update info", "dev4press-updater"); ?></th>
        </tr>
    </tfoot>
    <tbody class="plugins">
    <?php
        if (empty($dev4press_themes)) {
            echo '<tr><td colspan="2">'.__("No themes to show", "dev4press-updater").'</td></tr>';
	} else {
        $current_theme = current_theme_info();
        foreach ($dev4press_themes as $theme_file => $values) {
            if (isset($values["settings"]["build"]) && $values["settings"]["build"] > 0) {
            $actions = array();
            $is_active = $values["infos"]["Template"] == $current_theme->template;

            if (!$is_active) $actions[] = '<a href="'.wp_nonce_url("themes.php?action=activate&amp;template=".urlencode($values["infos"]["Template"])."&amp;stylesheet=".urlencode($values["infos"]["Stylesheet"]), 'switch-theme_'.$values["infos"]["Template"]).'" title="'.__("Activate this theme", "dev4press-updater").'" class="edit">'.__("Activate", "dev4press-updater").'</a>';
            else $actions[] = __("Active", "dev4press-updater");
            if (current_user_can('edit_themes')) $actions[] = '<a href="theme-editor.php?theme='.$values["infos"]["Name"].'" title="'.__("Open this theme in the Theme Editor", "dev4press-updater").'" class="edit">'.__("Edit", "dev4press-updater").'</a>';
            if (!$is_active && current_user_can('delete_plugins')) $actions[] = '<a href="'.wp_nonce_url("themes.php?action=delete&amp;template=".urlencode($values["infos"]["Stylesheet"]), "delete-theme_".$values["infos"]["Stylesheet"]).'" title="'.__("Delete this plugin", "dev4press-updater").'" class="delete">'.__("Delete", "dev4press-updater").'</a>';
            $class = $is_active ? 'active' : 'inactive';
        ?>
        <tr class="<?php echo $class; ?>">
            <td class='plugin-title'>
                <h4><?php echo $values["infos"]["Name"]; ?></h4>
                <p>
                    <strong><?php _e("Version", "dev4press-updater"); ?>:</strong> <?php echo $values["settings"]['version']; ?>
                    <?php echo " (".$values["settings"]["build"].")"; ?><br />
                    <?php if ($update_type == "theme") { ?>
                    <strong><?php _e("xScape", "dev4press-updater"); ?>:</strong> <?php echo $values["xscape"]['version']; ?>
                    <?php echo " (".$values["xscape"]["build"].")"; ?><br />
                    <?php } ?>
                    <strong><?php _e("Theme Home", "dev4press-updater"); ?>:</strong> <a target="_blank" href="http://www.dev4press.com/themes/<?php echo $values["infos"]['Stylesheet']; ?>/" title="<?php __("Visit plugin homepage", "dev4press-updater"); ?>"><?php _e("Visit", "dev4press-updater"); ?></a><br />
                    <strong><?php _e("Author", "dev4press-updater"); ?>:</strong> <?php echo $values["infos"]['Author']; ?>
                </p>
                <div class="row-actions-visible">
                <?php foreach ($actions as $action => $link) {
                    $sep = end($actions) == $link ? '' : ' | ';
                    echo "<span class='$action'>$link$sep</span>";
		} ?>
                </div>
            </td>
            <td class='desc'>
                <p><?php echo $values["infos"]["Description"]; ?></p>
                <div class="plugin-left-line"></div>
                <?php

                    $framework = true;
                    if (!is_array($update_themes)) {
                        echo "<strong>".__("Error occured during the remote update request.", "dev4press-updater")."</strong>";
                    } else if (isset($update_themes[$theme_file]) && is_array($update_themes[$theme_file])) {
                        $results = $update_themes[$theme_file];
                        foreach ($results as $status => $value) {
                            switch ($status) {
                                default:
                                    $framework = false;
                                    echo "<strong>".__("No data received for this theme.", "dev4press-updater")."</strong>";
                                    break;
                                case "beta":
                                case "nightly":
                                case "stable":
                                    $framework = false;
                                    echo '<strong><u>'.__("Theme", "dev4press-updater").":</u></strong> ";
                                    echo '<strong>'.$value->version.' '.$value->status."</strong> | ";
                                    echo 'build: '.$value->build." | date: ".$value->release_date;
                                    if (!empty($value->info)) echo '<br/><strong>description:</strong> '.$value->info;
                                    echo '<div class="plugin-left-line"></div>';
                                    if (current_user_can('update_themes')) {
                                        $_install_on = true;
                                        $url = 'admin.php?page=dev4press_updater&update='.$update_type.'&do=update&_wpnonce='.wp_create_nonce("dev4press");
                                        echo '<a style="float: right" href="'.$url.'&product='.$values["settings"]["product_id"].'&install='.$value->id.'">'.__("update now", "dev4press-updater").'</a>';
                                        echo '<label><input checked type="checkbox" name="update['.$update_type.']['.$values["settings"]["product_id"].']" value="'.$value->id.'" style="margin-right: 5px" />'.__("to update queue", "dev4press-updater").'</label>';
                                    }
                                    break;
                                case "illegal":
                                    $framework = false;
                                    echo '<strong style="color: red;"><u>'.__("Theme", "dev4press-updater").":</u> ".__($value, "dev4press-updater").'</strong>';
                                    break;
                                case "not_found":
                                    echo '<strong><u>'.__("Theme", "dev4press-updater").":</u> ".__($value, "dev4press-updater").'</strong>';
                                    break;
                            }
                        }
                    } else {
                        _e("No data available right now. Run update manually, or wait for next auto update check.", "dev4press-updater");
                    }

                    if (isset($update["xscape"])) {
                        if ($framework && isset($update["xscape"][$theme_file]) && is_array($update["xscape"][$theme_file])) {
                            $results = $update["xscape"][$theme_file];
                            foreach ($results as $status => $value) {
                                switch ($status) {
                                    case "beta":
                                    case "nightly":
                                    case "stable":
                                        echo '<div class="plugin-left-line"></div><strong><u>'.__("Framework", "dev4press-updater").":</u></strong> ";
                                        echo '<strong>xScape '.$value->version.' '.$value->status."</strong> | ";
                                        echo 'build: '.$value->build." | date: ".$value->release_date;
                                        if (!empty($value->info)) echo '<br/><strong>description:</strong> '.$value->info;
                                        echo '<div class="plugin-left-line"></div>';
                                        if (current_user_can('update_themes')) {
                                            $_install_on = true;
                                            $url = 'admin.php?page=dev4press_updater&update=xscape&do=update&_wpnonce='.wp_create_nonce("dev4press");
                                            echo '<a style="float: right" href="'.$url.'&product='.$values["settings"]["product_id"].'&install='.$value->id.'">'.__("update now", "dev4press-updater").'</a>';
                                            echo '<label><input checked type="checkbox" name="update[xscape]['.$values["settings"]["product_id"].']" value="'.$value->id.'" style="margin-right: 5px" />'.__("to update queue", "dev4press-updater").'</label>';
                                        }
                                        break;
                                }
                            }
                        }
                    }

                ?>
            </td>
        </tr>
        <?php } } } ?>
    </tbody>
</table>
