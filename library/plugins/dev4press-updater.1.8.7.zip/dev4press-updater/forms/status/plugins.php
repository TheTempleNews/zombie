<table class="widefat" cellspacing="0">
    <thead>
        <tr>
            <th scope="col" class="manage-column" style="width: 35%;"><?php _e("Plugin Details and Actions", "dev4press-updater"); ?></th>
            <th scope="col" class="manage-column"><?php _e("Description and Update info", "dev4press-updater"); ?></th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th scope="col" class="manage-column" style="width: 35%;"><?php _e("Plugin Details and Actions", "dev4press-updater"); ?></th>
            <th scope="col" class="manage-column"><?php _e("Description and Update info", "dev4press-updater"); ?></th>
        </tr>
    </tfoot>
    <tbody class="plugins">
    <?php
        if (empty($dev4press_plugins)) {
            echo '<tr><td colspan="2">'.__("No plugins to show", "dev4press-updater").'</td></tr>';
	} else {
        foreach ($dev4press_plugins as $plugin_file => $values) {
            $actions = array();
            $is_active = is_plugin_active($plugin_file);
            $context = $is_active ? "active" : "inactive";

            if ($is_active) $actions[] = '<a href="'.wp_nonce_url('plugins.php?action=deactivate&amp;plugin='.$plugin_file.'&amp;plugin_status='.$context, 'deactivate-plugin_'.$plugin_file).'" title="'.__("Deactivate this plugin", "dev4press-updater").'">'.__("Deactivate", "dev4press-updater").'</a>';
            else $actions[] = '<a href="'.wp_nonce_url('plugins.php?action=activate&amp;plugin='.$plugin_file.'&amp;plugin_status='.$context, 'activate-plugin_'.$plugin_file).'" title="'.__("Activate this plugin", "dev4press-updater").'" class="edit">'.__("Activate", "dev4press-updater").'</a>';
            if (current_user_can('edit_plugins')) $actions[] = '<a href="plugin-editor.php?file='.$plugin_file.'" title="'.__("Open this plugin in the Plugin Editor", "dev4press-updater").'" class="edit">'.__("Edit", "dev4press-updater").'</a>';
            if (!$is_active && current_user_can('delete_plugins')) $actions[] = '<a href="'.wp_nonce_url('plugins.php?action=delete-selected&amp;checked[]='.$plugin_file.'&amp;plugin_status='.$context, 'bulk-manage-plugins').'" title="'.__("Delete this plugin", "dev4press-updater").'" class="delete">'.__("Delete", "dev4press-updater").'</a>';
            $class = $is_active ? 'active' : 'inactive';
        ?>
        <tr class="<?php echo $class; ?>">
            <td class='plugin-title'>
                <h4><?php echo $values["data"]["Name"]; ?></h4>
                <p>
                    <strong><?php _e("Version", "dev4press-updater"); ?>:</strong> <?php echo $values["data"]["Version"]; ?>
                    <?php echo " (".$values["settings"]["build"].")"; ?><br />
                    <strong><?php _e("Plugin Home", "dev4press-updater"); ?>:</strong> <a target="_blank" href="<?php echo $values["data"]['PluginURI']; ?>" title="<?php __("Visit plugin homepage", "dev4press-updater"); ?>"><?php _e("Visit", "dev4press-updater"); ?></a><br />
                    <strong><?php _e("Author", "dev4press-updater"); ?>:</strong> <a target="_blank" href="<?php echo $values["data"]['AuthorURI']; ?>" title="<?php __("Visit author homepage", "dev4press-updater"); ?>"><?php echo $values["data"]['Author']; ?></a>
                </p>
                <div class="row-actions-visible">
                <?php foreach ($actions as $action => $link) {
                    $sep = end($actions) == $link ? '' : ' | ';
                    echo "<span class='$action'>$link$sep</span>";
		} ?>
                </div>
            </td>
            <td class='desc'>
                <p><?php echo $values["data"]["Description"]; ?></p>
                <div class="plugin-left-line"></div>
                <?php
                    if (!is_array($update["plugins"])) echo "<strong>".__("Error occured during the remote update request.", "dev4press-updater")."</strong>";
                    else if (isset($update["plugins"][$plugin_file]) && is_array($update["plugins"][$plugin_file])) {
                        $results = $update["plugins"][$plugin_file];
                        foreach ($results as $status => $value) {
                            switch ($status) {
                                default:
                                    echo "<strong>".__("No data received for this plugin.", "dev4press-updater")."</strong>";
                                    break;
                                case "beta":
                                case "nightly":
                                case "stable":
                                    echo '<strong>'.$value->version.' '.$value->status."</strong> | ";
                                    echo 'build: '.$value->build." | date: ".$value->release_date;
                                    if (!empty($value->info)) echo '<br/><strong>description:</strong> '.$value->info;
                                    if (current_user_can('update_plugins')) {
                                        $_install_on = true;
                                        echo '<div class="plugin-left-line"></div>';
                                        $url = 'admin.php?page=dev4press_updater&update=plugin&do=update&_wpnonce='.wp_create_nonce("dev4press");
                                        echo '<a  style="float: right" href="'.$url.'&product='.$values["settings"]["product_id"].'&install='.$value->id.'">'.__("install this release", "dev4press-updater").'</a>';
                                        echo '<label><input checked type="checkbox" name="update[plugin]['.$values["settings"]["product_id"].']" value="'.$value->id.'" style="margin-right: 5px" />'.__("to update queue", "dev4press-updater").'</label>';
                                    }
                                    break;
                                case "illegal":
                                    echo '<strong style="color: red;">'.__($value, "dev4press-updater").'</strong>';
                                    break;
                                case "not_found":
                                    echo '<strong>'.__($value, "dev4press-updater").'</strong>';
                                    break;
                            }
                        }
                    } else _e("No data available right now. Run update manually, or wait for next auto update check.", "dev4press-updater");
                ?>
            </td>
        </tr>
        <?php } } ?>
    </tbody>
</table>
