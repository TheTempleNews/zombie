<form action="" method="POST">
    <?php wp_nonce_field("dev4press"); ?>
    <input type="hidden" name="do" value="install-new" />

    <?php

        $_install_on = false;
        if (isset($update["install"]["plugins"]) && !empty($update["install"]["plugins"])) {
            $_install_on = true;
            echo '<h3>'.__("Plugins available for installation", "dev4press-updater").'</h3>';
            $plugins = $update["install"]["plugins"];
            include(DEV4UPDATER_PATH."forms/new/plugins.php");
        }

        if (isset($update["install"]["themes"]) && !empty($update["install"]["themes"])) {
            $_install_on = true;
            echo '<h3>'.__("Themes available for installation", "dev4press-updater").'</h3>';
            $themes = $update["install"]["themes"];
            $update_type = "theme";
            include(DEV4UPDATER_PATH."forms/new/themes.php");
        }

        if (isset($update["install"]["core_themes"]) && !empty($update["install"]["core_themes"])) {
            $_install_on = true;
            echo '<h3>'.__("Core Themes available for installation", "dev4press-updater").'</h3>';
            $themes = $update["install"]["core_themes"];
            $update_type = "core_theme";
            include(DEV4UPDATER_PATH."forms/new/themes.php");
        }

        if ($_install_on) {
            echo '<input style="margin-top: 20px;" type="submit" value="'.__("Install Selected", "dev4press-updater").'" class="button" name="d4p_install">';
        }

    ?>
</form>
