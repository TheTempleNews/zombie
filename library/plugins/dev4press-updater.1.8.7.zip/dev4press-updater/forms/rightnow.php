<?php

echo '<p><a href="http://www.dev4press.com/" target="_blank">Dev4Press</a>: ';

if ($update == "remote_error") {
    _e("An error occured during last update check.", "dev4press-updater");
    echo sprintf(' <a href="'.network_admin_url("admin.php?page=dev4press_updater&action=runcheck").'">%s</a>.', __("Recheck", "dev4press-updater"));
} else if (is_array($update["summary"]) &&
    $update["summary"]["plugins"] == 0 &&
    $update["summary"]["themes"] == 0 && 
    $update["summary"]["core_themes"] == 0) {
        _e("No updates for plugins or themes at this time.", "dev4press-updater");
        ?>
         <a href="<?php echo network_admin_url("admin.php?page=dev4press_updater&action=runcheck"); ?>"><?php _e("Check Now", "dev4press-updater"); ?></a>
        <?php
} else {
    echo dev4upd_update_print($update);
}

echo '</p>';

?>