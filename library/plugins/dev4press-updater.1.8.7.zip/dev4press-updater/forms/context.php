<div class="contextual-help">
    <div class="help-info">
        <?php _e("To get help with Dev4Press Updater, check out resources available on Dev4Press website.", "dev4press-updater"); ?>
    </div>
    <div class="help-more">
        <h4><?php _e("General Resources", "dev4press-updater"); ?></h4>
        <a href="http://www.dev4press.com/forums/" target="_blank"><?php _e("Support Forum", "dev4press-updater"); ?></a> | 
        <a href="http://www.dev4press.com/documentation/" target="_blank"><?php _e("Documentation", "dev4press-updater"); ?></a> | 
        <a href="http://www.dev4press.com/category/tutorials/" target="_blank"><?php _e("Tutorials", "dev4press-updater"); ?></a>
    </div>
    <div class="help-block">
        <h4><?php _e("Tutorials", "dev4press-updater"); ?></h4>
        <?php

        foreach ($this->tutorials as $tut) {
            if (in_array($panel, $tut["panels"])) {
                echo '<div>';
                echo '<a class="gdsr-icon-tutorial gdsr-icon-tutorial-'.$tut["icon"].'" href="http://www.dev4press.com/?p='.$tut["id"].'" target="_blank">'.$tut["title"].'</a>';
                echo '</div>';
            }
        }

        ?>
    </div>
    <div class="help-block">
        <h4><?php _e("Plugin Information", "dev4press-updater"); ?></h4>
        <a href="http://www.dev4press.com/auto-updater/" target="_blank"><?php _e("About Updater", "dev4press-updater"); ?></a> | 
        <a href="http://www.dev4press.com/forums/forum/plugins/dev4press-updater/" target="_blank"><?php _e("Support Forum", "dev4press-updater"); ?></a> | 
        <a href="http://www.dev4press.com/documentation/product/plg-dev4press-updater/" target="_blank"><?php _e("Documentation", "dev4press-updater"); ?></a>
    </div>
    <div class="clear"></div>
</div>