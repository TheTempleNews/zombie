<?php

require_once(ABSPATH."wp-admin/includes/class-wp-upgrader.php");
require_once(DEV4UPDATER_PATH."code/upgrade.php");

$responses = array(
    __("Pre update backup operation failed.", "dev4press-updater")
);

$plugin_update = new Plugin_Upgrader();
$theme_update = new Theme_Upgrader();
$xscape_update = new xScape_Upgrader();

$plugin_update->init();
$theme_update->init();
$xscape_update->init();

$plugin_update->upgrade_strings();
$theme_update->upgrade_strings();
$xscape_update->upgrade_strings();

if ($operation == "new") {
    $plugin_update->install_strings();
    $theme_update->install_strings();
}

$class_block = "d4p-single-block";
$counter_id = 1;
foreach ($box as $type => $files) {
    for ($i = 0; $i < count($files); $i++) {
        $package = $files[$i];
        $action_type = $type == "core_theme" ? "theme" : $type;

        echo '<div class="'.$class_block.'">';
        echo '<h3>'.$counter_id.". ".__("Installing", "dev4press-updater")." ".str_replace("_", " ", $type).": ".$package["name"]." ".$package["version"]."</h3>";

        do_action("dev4press_updater_pre_update");
        do_action("dev4press_updater_pre_update_".$action_type."_".$package["product"]);
        $update_is_go = apply_filters("dev4press_updater_run_update_".$action_type."_".$package["product"], "OK");

        if ($update_is_go == "OK") {
            switch ($type) {
                case "plugin":
                    $plugin_update->run(array('package' => $package["url"], 'destination' => WP_PLUGIN_DIR,
                                              'clear_destination' => true, 'is_multi' => true, 'clear_working' => true));
                    $plugin_file = $plugin_update->plugin_info();
                    break;
                case "core_theme":
                case "theme":
                    $theme_update->run(array('package' => $package["url"], 'destination' => WP_CONTENT_DIR.'/themes',
                                             'clear_destination' => true, 'is_multi' => true, 'clear_working' => true));
                    $theme_file = $theme_update->theme_info();
                    break;
                case "xscape":
                    $xscape_update->run(array('package' => $package["url"], 'destination' => WP_CONTENT_DIR.'/themes/'.$package["product"],
                                              'clear_destination' => true, 'is_multi' => true, 'clear_working' => true));
                    break;
            }

            do_action("dev4press_updater_post_update_".$action_type."_".$package["product"]);
            do_action("dev4press_updater_post_update");
        } else {
            echo '<span class="d4p-error">'.__($update_is_go, "dev4press-updater").'</span>';
        }

        echo '</div>';
        $class_block = "d4p-single-block d4p-single-notfirst";
        $counter_id++;
    }
}

?>
<div id="d4p-link-ctrl">
    <?php

    if ($operation == "new") {
        echo '<a href="admin.php?page=dev4press_installer">'.__("Go back to Installer", "dev4press-updater").'</a>';
    } else {
        echo '<a href="admin.php?page=dev4press_updater">'.__("Go back to Updater", "dev4press-updater").'</a>';
    }

    echo ' | <a href="plugins.php">'.__("Plugins", "dev4press-updater").'</a>';
    echo ' | <a href="themes.php">'.__("Themes", "dev4press-updater").'</a>';
    echo ' | <a href="index.php">'.__("Dashboard", "dev4press-updater").'</a>';

    ?>
</div>
