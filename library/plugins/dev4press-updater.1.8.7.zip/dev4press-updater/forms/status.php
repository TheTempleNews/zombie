<?php
$errors = array(
    __("Update not available at this time.", "dev4press-updater"),
    __("You don't have license required for this plugin.", "dev4press-updater"),
    __("You don't have license required for this theme.", "dev4press-updater")
);
?>
<form action="" method="POST">
    <?php wp_nonce_field("dev4press"); ?>
    <input type="hidden" name="do" value="update-current" />

    <?php

        $_install_on = false;
        echo '<h3>'.__("Currently installed Plugins", "dev4press-updater").'</h3>';
        include(DEV4UPDATER_PATH."forms/status/plugins.php");

        $dev4press_themes = $dev4press_all_themes["pro"];
        if (!empty($dev4press_themes)) {
            $dev4press_core = false;
            $update_themes = $update["themes"];
            echo '<h3>'.__("Currently installed Themes", "dev4press-updater").'</h3>';
            $update_type = "theme";
            include(DEV4UPDATER_PATH."forms/status/themes.php");
        }

        $dev4press_themes = $dev4press_all_themes["core"];
        if (!empty($dev4press_themes)) {
            $dev4press_core = false;
            $update_themes = $update["core_themes"];
            echo '<h3>'.__("Currently installed Core Themes", "dev4press-updater").'</h3>';
            $update_type = "core_theme";
            include(DEV4UPDATER_PATH."forms/status/themes.php");
        }

        if ($_install_on) {
            echo '<input style="margin-top: 20px;" type="submit" value="'.__("Install Selected", "dev4press-updater").'" class="button" name="d4p_update">';
        }

    ?>
</form>
