<?php if (isset($_GET['settings']) && $_GET['settings'] == "saved") { ?>
<div id="message" class="updated fade" style="background-color: rgb(255, 251, 204);"><p><strong><?php _e("Settings saved.", "dev4press-updater"); ?></strong></p></div>
<?php } ?>

<form action="" method="post">
    <?php wp_nonce_field("dev4press-updater-settings"); ?>
    <table class="form-table form-apikey"><tbody>
        <tr><th scope="row"><?php _e("API Key", "dev4press-updater"); ?></th>
            <td>
                <table cellpadding="0" cellspacing="0" class="previewtable">
                    <tr>
                        <td width="150"><?php _e("Key", "dev4press-updater"); ?>:</td>
                        <td><input type="password" name="dev4press_api_key" id="dev4press_api_key" value="<?php echo $options["dev4press_api_key"]; ?>" style="width: 250px" /></td>
                    </tr>
                </table>
                <div class="gdsr-table-split"></div>
                <?php _e("This is required for the updater to work. Do not share your API Key with anyone, because the abuse of the updates can lead to removal of your account and cancelation of all your licenses from Dev4Press. To get your API Key, log into Dev4Press and visit your user dashboard.", "dev4press-updater"); ?>
                <div class="gdsr-table-split"></div>
                <strong><a href="http://www.dev4press.com/user/"><?php _e("User Dashboard", "dev4press-updater"); ?></a> | 
                <a href="http://www.dev4press.com/user/profile/"><?php _e("Profile Page", "dev4press-updater"); ?></a> | 
                <a href="http://www.dev4press.com/support-policy/"><?php _e("Support Policy", "dev4press-updater"); ?></a></strong>
            </td>
        </tr>
    </tbody></table>
    <table class="form-table"><tbody>
        <tr><th scope="row"><?php _e("Update", "dev4press-updater"); ?></th>
            <td>
                <table cellpadding="0" cellspacing="0" class="previewtable">
                    <tr>
                        <td width="150"><?php _e("Check for", "dev4press-updater"); ?>:</td>
                        <td>
                            <select name="update_status" id="update_status"  style="width: 250px">
                                <option<?php echo $options["update_status"] == "stable" ? ' selected="selected"' : ''; ?> value="stable"><?php _e("Only stable releases", "dev4press-updater"); ?></option>
                                <option<?php echo $options["update_status"] == "normal" ? ' selected="selected"' : ''; ?> value="normal"><?php _e("Stable and beta releases", "dev4press-updater"); ?></option>
                                <option<?php echo $options["update_status"] == "nightly" ? ' selected="selected"' : ''; ?> value="nightly"><?php _e("Stable, beta and nightly releases", "dev4press-updater"); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
                <div class="gdsr-table-split"></div>
                <?php _e("Nightly builds are not reccomended for use in production enviroments.", "dev4press-updater"); ?>
            </td>
        </tr>
        <tr><th scope="row"><?php _e("Debug", "dev4press-updater"); ?></th>
            <td>
                <table cellpadding="0" cellspacing="0" class="previewtable">
                    <tr>
                        <td width="150"><?php _e("Set level", "dev4press-updater"); ?>:</td>
                        <td>
                            <select name="debug_level" id="debug_level"  style="width: 250px">
                                <option<?php echo $options["debug_level"] == "none" ? ' selected="selected"' : ''; ?> value="none"><?php _e("No debug", "dev4press-updater"); ?></option>
                                <option<?php echo $options["debug_level"] == "full" ? ' selected="selected"' : ''; ?> value="full"><?php _e("All requests and responses", "dev4press-updater"); ?></option>
                                <option<?php echo $options["debug_level"] == "requests" ? ' selected="selected"' : ''; ?> value="requests"><?php _e("Requests only", "dev4press-updater"); ?></option>
                                <option<?php echo $options["debug_level"] == "responses" ? ' selected="selected"' : ''; ?> value="responses"><?php _e("Responses only", "dev4press-updater"); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
                <div class="gdsr-table-split"></div>
                <?php _e("Debug info will be stored in debug.txt file in plugins folder.", "dev4press-updater"); ?>
            </td>
        </tr>
        <tr><th scope="row" style="border-bottom: none;"><?php _e("Integration", "dev4press-updater"); ?></th>
            <td style="border-bottom: none;">
                <input type="checkbox" name="managewp_support" id="managewp_support"<?php if ($options["managewp_support"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="managewp_support"><?php echo sprintf(__("Allow interaction with %s for notifications and updates.", "dev4press-updater"), '<a href="http://managewp.com/" target="_blank">ManageWP</a>'); ?></label>
                <div class="gdsr-table-split"></div>
                <input type="checkbox" name="right_now_active" id="right_now_active"<?php if ($options["right_now_active"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="right_now_active"><?php _e("Display update status in the admin dashboard Right Now widget.", "dev4press-updater"); ?></label>
                <br/>
                <input type="checkbox" name="adminbar_active" id="adminbar_active"<?php if ($options["adminbar_active"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="adminbar_active"><?php _e("Display notice in Adminbar when update is available.", "dev4press-updater"); ?></label>
                <br/>
                <input type="checkbox" name="admin_notice_active" id="admin_notice_active"<?php if ($options["admin_notice_active"] == 1) echo " checked"; ?> /><label style="margin-left: 5px;" for="admin_notice_active"><?php _e("Display admin notice on the top of each page when update is available.", "dev4press-updater"); ?></label>
            </td>
        </tr>
    </tbody></table>

    <input type="submit" class="button" value="<?php _e("Save Settings", "dev4press-updater"); ?>" name="dev4press_saving"/>
</form>
