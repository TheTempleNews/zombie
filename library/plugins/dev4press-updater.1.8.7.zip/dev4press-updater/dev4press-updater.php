<?php

/*
Plugin Name: Dev4Press Updater
Plugin URI: http://www.dev4press.com/auto-updater/
Description: Dev4Press Updater is a plugin for performing the updates of the Dev4Press Pro plugins and xScape Pro themes, including beta and nightly releases, directly from WordPress.
Version: 1.8.7
Author: Milan Petrovic
Author URI: http://www.dev4press.com/
Network: true

== Copyright ==
Copyright 2008 - 2012 Milan Petrovic (email: milan@gdragon.info)

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

$gddev4upd_dirname_basic = dirname(__FILE__);

require_once($gddev4upd_dirname_basic.'/code/defaults.php');
require_once($gddev4upd_dirname_basic.'/code/plugins.php');

define('DEV4UPDATER_WP_ADMIN', defined('WP_ADMIN') && WP_ADMIN);

class Dev4PressUpdater {
    var $wp_version;
    var $plugin_url;
    var $plugin_path;

    var $default_options;
    var $settings_names;
    var $updater_url;
    var $script = "";
    var $plugins;
    var $o;
    var $u;
    var $mwp;

    function __construct() {
        $this->plugins = new dev4UPDPlugins();

        $gdd = new dev4UPDDefaults();
        $this->default_options = $gdd->default_options;
        $this->settings_names = $gdd->settings_names;
        $this->updater_url = $gdd->updater_url;

        define('DEV4UPDATER_INSTALLED', $this->default_options['version']);
        define('DEV4UPDATER_VERSION', $this->default_options['version'].'_b'.($this->default_options['build'].'_pro'));

        $this->plugin_path_url();
        $this->install_plugin();
        $this->actions_filters();

        if ($this->get('managewp_support') == 1) {
            require_once(DEV4UPDATER_PATH.'code/mwp.php');
            $this->mwp = new d4pu_ManageWP();
        }
    }

    function plugin_path_url() {
        $this->plugin_url = WP_PLUGIN_URL.'/dev4press-updater/';
        $this->plugin_path = dirname(__FILE__).'/';

        define('DEV4UPDATER_URL', $this->plugin_url);
        define('DEV4UPDATER_PATH', $this->plugin_path);
    }

    function install_plugin() {
        global $wp_version;
        $this->wp_version = substr(str_replace('.', '', $wp_version), 0, 2);
        define('DEV4UPDATER_WPV', $this->wp_version);

        $this->o = get_site_option('dev4press-updater');
        $this->u = get_site_transient('dev4press_updater_response');

        $role = get_role('administrator');
        $role->add_cap('dev4press_updater');

        $installed = false;
        if (!is_array($this->o)) {
            update_site_option('dev4press-updater', $this->default_options);
            $this->o = get_option('dev4press-updater');
            $installed = true;
        }

        if ($this->o['build'] < $this->default_options['build'] || !$installed) {
            $this->o = $this->upgrade_settings($this->o, $this->default_options);

            $this->o['version'] = $this->default_options['version'];
            $this->o['date'] = $this->default_options['date'];
            $this->o['status'] = $this->default_options['status'];
            $this->o['build'] = $this->default_options['build'];
            $this->o['revision'] = $this->default_options['revision'];
            $this->o['edition'] = $this->default_options['edition'];

            update_site_option('dev4press-updater', $this->o);
        }

        if (!wp_next_scheduled('dev4press_update_check') && $this->o['dev4press_api_key'] != '') {
            wp_schedule_event($this->cron_time_day(), 'twicedaily', 'dev4press_update_check');
        }

        if ($this->o['dev4press_api_key'] == '') {
            dev4upd_remove_cron('dev4press_update_check');
        }

        if ($this->u === false && $this->o['dev4press_api_key'] != '') {
            wp_schedule_single_event(time() + 1, 'dev4press_update_check');
        }
    }

    function actions_filters() {
        add_action('dev4press_update_check', array(&$this, 'update_check'));

        if ($this->get('adminbar_active') == 1) {
            add_action('admin_bar_menu', array(&$this, 'admin_bar_notice'), 100);
            add_action('admin_head', array(&$this, 'admin_bar_icon'));
            add_action('wp_head', array(&$this, 'admin_bar_icon'));
        }

        add_action('init', array(&$this, 'init'));
    }

    function init() {
        require_once(DEV4UPDATER_PATH.'code/xscape.php');
    }

    function upgrade_settings($old, $new) {
        foreach ($new as $key => $value) {
            if (!isset($old[$key])) $old[$key] = $value;
        }

        $unset = Array();
        foreach ($old as $key => $value) {
            if (!isset($new[$key])) $unset[] = $key;
        }

        foreach ($unset as $key) {
            unset($old[$key]);
        }

        return $old;
    }

    function cron_time_day() {
        return mktime(0, 1, 2, date('m'), date('d') + 1, date('Y'));
    }

    function get($name) {
        return $this->o[$name];
    }

    function update_found() {
        if ($this->u != 'remote_error' && is_array($this->u['summary'])) {
            $total = $this->u['summary']['plugins'] + $this->u['summary']['themes'] + $this->u['summary']['xscape'];

            return $total > 0;
        } else {
            return false;
        }
    }

    public function admin_bar_icon() { ?>
        <style type="text/css">
            #wpadminbar .ab-top-menu > li.menupop.icon-d4pupd-toolbar > .ab-item {
                background-image: url('<?php echo plugins_url('dev4press-updater/gfx/menu.png'); ?>');
                background-repeat: no-repeat;
                background-position: 0.85em 50%;
                padding-left: 32px;
            }
        </style>
    <?php }

    function admin_bar_notice() {
        if (current_user_can('dev4press_updater')) {
            $menu_count = $this->menu_count(true);

            if ($menu_count != '') {
                global $wp_admin_bar;

                $update_title = 'Dev4Press <span title="Dev4Press '.__("Updates Available", "dev4press-updater").'">'.$menu_count.'</span>';

                $wp_admin_bar->add_menu(array(
                    'id' => 'dev4press-updater', 
                    'title' => $update_title, 
                    'href' => network_admin_url('admin.php?page=dev4press_updater'), 
                    'meta' => array('class' => 'icon-d4pupd-toolbar'))
                );

                $wp_admin_bar->add_menu(array(
                    'parent' => 'dev4press-updater', 
                    'id' => 'dev4press-updater-install', 
                    'title' => __("Install New", "dev4press-updater"), 
                    'href' => network_admin_url('admin.php?page=dev4press_installer'))
                );

                $wp_admin_bar->add_menu(array(
                    'parent' => 'dev4press-updater', 
                    'id' => 'dev4press-updater-check', 
                    'title' => __("Run Check", "dev4press-updater"), 
                    'href' => network_admin_url('admin.php?page=dev4press_updater&action=runcheck'))
                );

                $wp_admin_bar->add_menu(array(
                    'parent' => 'dev4press-updater', 
                    'id' => 'dev4press-updater-settings', 
                    'title' => __("Settings", "dev4press-updater"), 
                    'href' => network_admin_url('admin.php?page=dev4press_settings'))
                );
            }
        }
    }

    function update_check() {
        $dev4press_plugins = $this->get_plugins();
        $dev4press_themes = $this->get_themes();

        $update = new dev4Updater($dev4press_plugins, $dev4press_themes, $this->o['dev4press_api_key'], $this->o['update_status']);
        $response = $update->update($this->updater_url);

        $this->u = $response;
        $this->o['force_run_onload'] = 0;

        update_site_option('dev4press-updater', $this->o);
        set_site_transient('dev4press_updater_response', $response, 1209600);
    }

    function menu_count($admin_bar = false) {
        $to_add = '';
        $count = 0;
        if ($this->u != 'remote_error' && is_array($this->u['summary'])) {
            $count = $this->u['summary']['plugins'] + $this->u['summary']['core_themes'] + $this->u['summary']['themes'] + $this->u['summary']['xscape'];
        }
        if ($count > 0) {
            if ($admin_bar) {
                $css = 'background: none repeat scroll 0 0 #EEEEEE; border-radius: 10px 10px 10px 10px; color: #333333; display: inline; font-size: 10px; font-weight: bold; padding: 2px 5px; text-shadow: none;';
                $to_add = sprintf(' <span style="%s">%s</span>', $css, $count);
            } else {
                $to_add = sprintf('<span class="update-plugins count-%s"><span class="plugin-count">%s</span></span>', $count, $count);
            }
        }
        return $to_add;
    }

    function package_processor($box, $upd, $operation) {
        $mod = array();

        foreach ($box as $type => $files) {
            $processed = array();

            for ($i = 0; $i < count($files); $i++) {
                $_prod = $files[$i]['product'];

                if ($operation == 'new') {
                    foreach ($upd['install'][$type.'s'] as $product) {
                        if ($product->group == $_prod) {
                            $new = $files[$i];
                            $new['name'] = $product->name;
                            $new['version'] = $product->version;
                            $processed[] = $new;
                            break;
                        }
                    }
                } else {
                    $code = $type == 'xscape' ? $type : $type.'s';

                    foreach ($upd[$code] as $group => $data) {
                        foreach ($data as $status => $product) {
                            if (!isset($processed[$_prod]) && is_object($product) && isset($product->id) && $product->id == $files[$i]['id']) {
                                $new = $files[$i];
                                $name = $product->name;
                                if ($type == 'xscape') {
                                    $name = $_prod.' | '.$name;
                                }
                                $new['name'] = $name;
                                $new['version'] = $product->version;
                                $processed[$_prod] = $new;
                                break;
                            }
                        }
                    }
                }
            }

            $mod[$type] = array_values($processed);
        }

        return $mod;
    }

    function get_package_download_url($id, $api_key, $cat = 'plugin') {
        $file_name = $this->get_package_file_name($cat, $id);

        if ($file_name != '') {
            return 'http://cdnx.dev4press.com/free-download/'.$cat.'/'.$file_name;
        } else {
            if ($cat == 'core_theme') {
                $cat = 'theme';
            }

            return 'http://www.dev4press.com/download/'.$cat.'/'.$api_key.'/'.$id;
        }
    }

    function get_package_file_name($cat, $id) {
        $cat.= 's';

        if (isset($this->u[$cat]) && is_array($this->u[$cat]) && !empty($this->u[$cat])) {
            foreach ($this->u[$cat] as $name => $list) {
                foreach ($list as $key => $obj) {
                    if (is_object($obj) && isset($obj->id) && $obj->id == $id && $obj->edition == 'free') {
                        if (isset($obj->file_name)) {
                            return $obj->file_name;
                        }
                    }
                }
            }
        }

        return '';
    }

    function get_themes() {
        require_once(ABSPATH."wp-admin/includes/theme.php");
        $all_themes = get_themes();

        $dev4press_themes = array('pro' => array(), 'core' => array());
        foreach ($all_themes as $theme => $value) {
            if (strpos($value['Author'], 'http://www.dev4press.com/') !== false) {
                $tpl_theme = $this->get_settings_from_theme_info($value['Stylesheet']);
                $tpl_scape = $this->get_settings_from_xscape_info($value['Stylesheet']);

                $dev4press_themes[$tpl_theme['edition']][$value['Stylesheet']]['infos'] = $value;
                $dev4press_themes[$tpl_theme['edition']][$value['Stylesheet']]['settings'] = $tpl_theme;
                $dev4press_themes[$tpl_theme['edition']][$value['Stylesheet']]['xscape'] = $tpl_scape;
            }
        }

        return $dev4press_themes;
    }

    function get_plugins() {
        require_once(ABSPATH."wp-admin/includes/plugin.php");
        $all_plugins = get_plugins();

        $dev4press_plugins = array();
        foreach ($this->plugins->plugins as $plugin => $value) {
            if (isset($all_plugins[$plugin])) {
                $dev4press_plugins[$plugin]['data'] = $all_plugins[$plugin];
                $dev4press_plugins[$plugin]['infos'] = $value;
                $dev4press_plugins[$plugin]['settings'] = $this->get_settings($value['options'], false, '', $plugin, $all_plugins[$plugin], $value['method']);
            }
        }

        return $dev4press_plugins;
    }

    function get_settings_from_xscape_info($theme) {
        $theme_init_path = WP_CONTENT_DIR.'/themes/'.$theme.'/xscape/core/init.php';
        if (file_exists($theme_init_path)) {
            include($theme_init_path);

            $options = (array)$xscape_core;
            $options['product_id'] = 'xscape';
            $settings = array();
            foreach ($this->settings_names as $name) {
                if (isset($options[$name])) {
                    $settings[$name] = $options[$name];
                }
            }
            return $settings;
        } return array();
    }

    function get_settings_from_theme_info($theme) {
        $theme_init_path = WP_CONTENT_DIR.'/themes/'.$theme.'/theme/init.php';
        if (file_exists($theme_init_path)) {
            include($theme_init_path);

            $options = (array)$xscape_theme;
            $options['product_id'] = $theme;
            $settings = array();
            foreach ($this->settings_names as $name) {
                if (isset($options[$name])) {
                    $settings[$name] = $options[$name];
                }
            }
            return $settings;
        } else return $this->get_settings($theme.'_settings', true, $theme);
    }

    function get_settings($options, $theme = false, $product_id = '', $plugin = '', $wp_data = array(), $method = 'classic') {
        $_opt = $options;
        $settings = array();

        if ($options == '') {
            $name = explode('/', $plugin);

            $settings['version'] = $wp_data['Version'];
            $settings['build'] = intval(str_replace('.', '', $wp_data['Version'])) * 10;
            $settings['edition'] = 'free';
            $settings['product_id'] = $name[0];

            return $settings;
        }

        $options = get_option($options);
        if ($theme) {
            $options = (array)$options['theme_info'];
            $options['product_id'] = $product_id;
        }

        if ($method == 'classic') {
            foreach ($this->settings_names as $name) {
                if (isset($options[$name])) {
                    $settings[$name] = $options[$name];
                }
            }
        }

        if (!$theme) {
            $pp = explode('/', $plugin);
            $build_path = WP_PLUGIN_DIR.'/'.$pp[0].'/code/build.php';
            if (file_exists($build_path)) {
                include($build_path);

                if ($method == 'load') {
                    $settings = $plugin_options;
                } else if ($method == 'gdr2') {
                    $settings = (array)$options['__core__'];
                    $settings['build'] = $build;
                    $settings['product_id'] = $pp[0];
                    $settings['edition'] = 'pro';
                } else {
                    $settings['build'] = $build;
                    if (!isset($settings['product_id'])) {
                        $settings['product_id'] = $pp[0];
                        $settings['edition'] = 'pro';
                    }
                }
            }
        }

        return $settings;
    }
}

global $d4pu, $d4pu_admin;
$d4pu = new Dev4PressUpdater();

if (DEV4UPDATER_WP_ADMIN) {
    require_once($gddev4upd_dirname_basic.'/code/admin.php');

    $d4pu_admin = new d4PU_Admin();
}

function d4pu_run_update_check() {
    global $d4pu;
    $d4pu->update_check();
}

function dev4upd_get($name) {
    global $d4pu;
    return $d4pu->get($name);
}

?>